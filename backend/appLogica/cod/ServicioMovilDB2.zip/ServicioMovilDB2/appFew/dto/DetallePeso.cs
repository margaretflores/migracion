﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace appFew.dto
{
    public class DetallePeso
    {

        public double CantidadNeta { get; set; }

        public double Quintales { get; set; }

        public double Tara { get; set; }
    }
}