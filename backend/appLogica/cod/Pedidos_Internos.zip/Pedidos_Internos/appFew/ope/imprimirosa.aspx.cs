﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using appConstantes;
using System.Data;
using appFew.appServicio;
using appWcfService;
namespace appFew.ope
{
    public partial class imprimirosa : System.Web.UI.Page
    {
        #region Variables
        private static ParametrosFe _ParametrosIni;
        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;
        USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result Selectedrow = new USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result(); //Guarda el item seleccionado
        decimal idosa;
        #endregion

        #region Eventos
        protected void Page_Load(object sender, EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];

            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {

                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();

                    if (!Page.IsPostBack)
                    {
                        CargaDatosIniciales();
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void tipfolDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SetDataSourceDetalle(null);
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void seleccionarButton_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = pendientesGridView.SelectedRow;
                if (row != null)
                {
                    string corrLiq = row.Cells[1].Text;
                    GeneraOrdenTrabajo(corrLiq);
                    //LENAR TABPAGES
                    //List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> detConsumo = OsasPendientes;
                    //if (detConsumo != null && detConsumo[0].OSAROW != -1)
                    //{
                    //    Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                    //}
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        //private void GeneraOrdenTrabajo(string folio)
        //{
        //    IappServiceClient clt = null;

        //    ORDENTRABAJO dtoOT = new ORDENTRABAJO();
        //    try
        //    {
        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.GENERA_ORDEN_TRABAJO;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(folio);

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {
        //            if (resultado.VALSAL[0].Equals("1")) //encontrado
        //            {
        //                dtoOT.OSASFOLI = folio;
        //                dtoOT.datpart = Funciones.Deserialize<List<PRPART>>(resultado.VALSAL[1]);
        //                dtoOT.obsepart = Funciones.Deserialize<List<PRPAOB>>(resultado.VALSAL[2]);
        //                dtoOT.asigpart = Funciones.Deserialize<List<PRASIG>>(resultado.VALSAL[3]);
        //                dtoOT.reqmat = Funciones.Deserialize<List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result>>(resultado.VALSAL[4]);
        //                HttpContext.Current.Session[Constantes.NOMBRE_SESION_ORDEN_TRABAJO] = dtoOT;

        //                string tempscript = "javascript:window.open('../ope/formatodoc2.aspx')";
        //                ScriptManager.RegisterStartupScript(up, up.GetType(), "OrdenTrabajo", tempscript, true);
        //            }
        //            else
        //            {
        //                MostrarMensaje(resultado.MENERR);
        //            }
        //        }
        //        else
        //        {

        //            MostrarMensaje(resultado.MENERR);
        //            //ErrorLabel.Font.Bold = true;
        //            //ErrorLabel.Text = resultado.MENERR;
        //        }
        //        //EstadoFinalBotonesNavegacionAsignacion();
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}

        private void GeneraOrdenTrabajo(string folio)
        {
            IappServiceClient clt = null;

            ORDENTRABAJO dtoOT = new ORDENTRABAJO();
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_ORDEN_TRABAJO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        dtoOT.OSASFOLI = folio;
                        dtoOT.datpart = Funciones.Deserialize<List<PRPART>>(resultado.VALSAL[1]);
                        dtoOT.obsepart = Funciones.Deserialize<List<PRPAOB>>(resultado.VALSAL[2]);
                        dtoOT.asigpart = Funciones.Deserialize<List<PRASIG>>(resultado.VALSAL[3]);
                        dtoOT.reqmat = Funciones.Deserialize<List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result>>(resultado.VALSAL[4]);
                        if (folio.Substring(0, 1) == "5")
                        {
                            dtoOT.maqtint = Funciones.Deserialize<List<PRTMXR>>(resultado.VALSAL[5]);
                        }
                        else
                        {
                            dtoOT.maqtint = null;
                        }
                        dtoOT.cabosa = Funciones.Deserialize<PECAOS>(resultado.VALSAL[6]);
                        HttpContext.Current.Session[Constantes.NOMBRE_SESION_ORDEN_TRABAJO] = dtoOT;

                        string tempscript = "javascript:window.open('../ope/formatodoc2.aspx')";
                        ScriptManager.RegisterStartupScript(up, up.GetType(), "OrdenTrabajo", tempscript, true);
                    }
                    else
                    {
                        MostrarMensaje(resultado.MENERR);
                    }
                }
                else
                {

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private bool genera_pedido(PECAOS objpecaos)
        {
            IappServiceClient clt = null;
            bool result = false;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_PEDIDO_INTERNO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(objpecaos));
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0] != "0")
                    {
                        idosa = Decimal.Parse(resultado.VALSAL[0]);
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    result = false;
                }
                result = resultado.ESTOPE;

                return result;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return result;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        protected void ActualizarButton_Click(object sender, EventArgs e)
        {
            SetDataSourceDetalle(null);
            CargaOsasEmitidas();
        }

        //Grillas
        protected void pendientesGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }
        protected void pendientesGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (pendientesGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = pendientesGridView.Rows[pendientesGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = pendientesGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void pendientesGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                MuestraDetalleOsa();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void pendientesGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(pendientesGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";


                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[2].Text = ConsumosExamen.Sum(x => x.MOVMCANT).ToString(Constantes.FORMATO_IMPORTE);
            //    e.Row.Cells[3].Text = ConsumosExamen.Sum(x => x.PORCENTAJE).ToString(Constantes.FORMATO_DECIMAL_0 + "1");
            //}
        }
        protected void detalleGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }
        protected void detalleGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(detalleGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[5].Text = "";

                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void buscaButton_Click(object sender, EventArgs e)
        {
            try
            {
                //if (buscarTextBox.Text.Trim().ToString() == "")
                //{
                //    CargaOsasEmitidas();
                //}
                //else
                //{
                //    buscarosa(tipfolDropDownList.SelectedValue.ToString(), buscarTextBox.Text.Trim().ToString());
                //}
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        //Ventana Modal
        protected void maceptarbutton_Click(object sender, EventArgs e)
        {
            //Obtiene el item selecconado y llama el metodo para mostrar el detalle del item
            GridViewRow row = pendientesGridView.SelectedRow;
            if (row != null)
            {
                string corrLiq = row.Cells[0].Text;

                List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> detConsumo = OsasPendientes;

                if (detConsumo != null && detConsumo[0].OSAROW != -1)
                {
                    //Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                    //PECAOS osa = new PECAOS();
                    //osa.CAOSIDCO = Selectedrow.CAOSIDCO;
                    //osa.CAOSIDES = 3;
                    //osa.CAOSUSCR = Selectedrow.OSASRESP;
                    //osa.CAOSFOLI = Selectedrow.OSASFOLI;
                    //osa.CAOSPRIO = decimal.Parse(Selectedrow.OSAROW.ToString());
                    //osa.CAOSEPRI = Selectedrow.CAOSPRIO;
                    //genera_pedido(osa);
                    //if (idosa != 0)
                    //{
                    //    Selectedrow.CAOSIDCO = osa.CAOSIDCO;
                    //}

                    ReabreOsa(DetalleOsaPendiente);

                    //List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> DetalleOsa = DetalleOsaPendiente;
                    //List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> lista = new List<USP_OBTIENE_DETALLE_OSA_Result>();

                    //if (DetalleOsa.Count != 0)
                    //{
                    //    foreach (var item in DetalleOsa)
                    //    {
                    //        USP_OBTIENE_DETALLE_OSA_Result obj = new USP_OBTIENE_DETALLE_OSA_Result();
                    //        obj.DEOSIDDO = item.DEOSIDDO;
                    //        obj.DEOSIDCO = item.DEOSIDCO;
                    //        lista.Add(obj);
                    //    }
                    //    cambiaestadoBODP(lista, 3);
                    //}
                    CargaOsasEmitidas();
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }

        protected void mcancelarbutton_Click(object sender, EventArgs e)
        {

        }
        protected void ReabrirButton_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = pendientesGridView.SelectedRow;
                if (row != null)
                {
                    string corrLiq = row.Cells[0].Text;
                    //LENAR TABPAGES
                    List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> detConsumo = OsasPendientes;

                    if (detConsumo != null && detConsumo[0].OSAROW != -1)
                    {
                        Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                        if (Selectedrow.CAOSIDES == 4 || Selectedrow.CAOSIDES == 5)
                        {
                            mensajelabel.Text = "¿Desea Reabrir esta OSA? Se actualizará su estado a 'En Preparación'";
                            mensajemodal.Show();
                        }
                        else
                        {
                            MostrarMensaje("No es posible Reabrir este Pedido");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        #endregion

        #region Metodos

        private void CargaDatosIniciales()
        {
            InicializaDatos();
            CargaFoliosUsuario();
            CargaOsasEmitidas();
        }

        private void InicializaDatos()
        {
            //consumos
            SetDataSourceOsas(null);

            //asignacion
            SetDataSourceDetalle(null);
        }

        public void CargaFoliosUsuario()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_TIPOS_FOLIO_USUARIO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(_ParametrosIni.Usuario);
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        var firstitem = tipfolDropDownList.Items[0];
                        tipfolDropDownList.Items.Clear();
                        tipfolDropDownList.Items.Add(firstitem);

                        List<PEUSTF> datos = Funciones.Deserialize<List<PEUSTF>>(resultado.VALSAL[1]);
                        foreach (PEUSTF item in datos)
                        {
                            tipfolDropDownList.Items.Add(new ListItem(item.PETIFO.TIFODESC, item.PETIFO.TIFOCOFO.ToString()));
                        }
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceOsas(List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> _listaConsumos)
        {
            bool limpiaDet = false;
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtienePendientesDefault();
                limpiaDet = true;
            }

            OsasPendientes = _listaConsumos;
            pendientesGridView.DataSource = OsasPendientes;
            pendientesGridView.DataBind();
            if (pendientesGridView.SelectedIndex == -1 || limpiaDet)
            {
                SetDataSourceDetalle(null);
            }
        }

        private void CargaOsasEmitidas()
        {
            IappServiceClient clt = null;

            try
            {
                if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
                {
                    SetDataSourceOsas(null);

                    return;
                }
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_OSAS_PENDIENTES_IMPRIMIR;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado
                parEnt.Add(buscarTextBox.Text.Trim());

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceOsas(datos);
                    }
                    else
                    {
                        SetDataSourceOsas(null);
                    }

                }
                else
                {
                    SetDataSourceOsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionConsumo();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
            }

            DetalleOsaPendiente = _listaAsignacion;
            detalleGridView.DataSource = DetalleOsaPendiente;
            detalleGridView.DataBind();
        }

        private void MuestraDetalleOsa()
        {
            //Obtiene el item selecconado y llama el metodo para mostrar el detalle del item
            GridViewRow row = pendientesGridView.SelectedRow;

            if (row != null)
            {
                string corrLiq = row.Cells[0].Text;
                //LENAR TABPAGES
                List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> detConsumo = OsasPendientes;

                if (detConsumo != null && detConsumo[0].OSAROW != -1)
                {
                    Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                    CargaDetalleOsa(Selectedrow.OSASFOLI.ToString());
                    //posOsaTextBox.Text = consumo.OSAROW.ToString();
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }

        private void CargaDetalleOsa(string folio)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSAS_IMPRIMIR;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }

        //Default
        private List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> ObtienePendientesDefault()
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result>();
            datos.Add(new USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result() { OSAROW = -1 });
            return datos;
        }

        private List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result() { OSASSECU = -1 });
            return datos;
        }

        private List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> OsasPendientes
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSAS_IMPRIMIR] as List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtienePendientesDefault();

                    OsasPendientes = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSAS_IMPRIMIR] = value;
            }
        }

        private List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_IMPRIMIR] as List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_IMPRIMIR] = value;
            }
        }

        private void buscarosa(string folio, string busqueda)
        {

            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.BUSCA_OSAS_PENDIENTES_PLANTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);
                parEnt.Add(busqueda);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result> listabusqueda = Funciones.Deserialize<List<USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result>>(resultado.VALSAL[1]);
                        List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> listdatos = new List<USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result>();
                        foreach (var item in listabusqueda)
                        {
                            USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result obj = new USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result();
                            obj.OSAROW = item.OSAROW;
                            obj.OSASCIA = item.OSASCIA;
                            obj.OSASFOLI = item.OSASFOLI;
                            obj.PARTFEEF = item.PARTFEEF;
                            obj.OSASFEEM = item.OSASFEEM;
                            obj.OSASRESP = item.OSASRESP;
                            obj.CAOSIDCO = item.CAOSIDCO;
                            obj.CAOSPRIO = item.CAOSPRIO;
                            obj.CAOSIDES = item.CAOSIDES;
                            obj.CAOSUSPR = item.CAOSUSPR;
                            listdatos.Add(obj);
                        }

                        SetDataSourceOsas(listdatos);
                    }
                    else
                    {
                        SetDataSourceOsas(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void ReabreOsa(List<USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> detalle)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.REABRE_OSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(detalle));
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    //Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] = detalle;
                    //Response.Redirect("../ope/trabajar_item.aspx");
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void cambiaestadoBODP(List<USP_OBTIENE_DETALLE_OSA_Result> iddo, decimal estado)
        {
            IappServiceClient clt = null;
            try
            {

                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.CAMBIA_ESTADO_BODP;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(iddo));
                parEnt.Add(estado.ToString());
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {

                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        #endregion

    }
}
