﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Diagnostics;
using System.IO;
using System.Globalization;
using System.Threading;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Linq;

using System.Drawing;
using System.Web.Script.Serialization;

using Microsoft.Reporting.WebForms;
using System.Web.Services;

using appFew.appServicio;
using appWcfService;
using appConstantes;

namespace appFew.ope
{
    public partial class priorizar : System.Web.UI.Page
    {
        private static ParametrosFe _ParametrosIni;

        #region Variables

        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;

        #endregion

        #region Eventos

        protected void Page_Load(object sender, System.EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];

            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {

                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();

                    if (!Page.IsPostBack)
                    {
                        CargaDatosIniciales();
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void pendientesGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }
        protected void detalleGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
            pendientesGridView.HeaderRow.Visible = false;
        }
        protected void pendientesGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (pendientesGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = pendientesGridView.Rows[pendientesGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = pendientesGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void pendientesGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MuestraDetalleOsa();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pendientesGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(pendientesGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[2].Text = ConsumosExamen.Sum(x => x.MOVMCANT).ToString(Constantes.FORMATO_IMPORTE);
            //    e.Row.Cells[3].Text = ConsumosExamen.Sum(x => x.PORCENTAJE).ToString(Constantes.FORMATO_DECIMAL_0 + "1");
            //}
        }
        protected void detalleGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(detalleGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void imprimirButton_Click(object sender, EventArgs e)
        {
            try
            {
                //string tempabc = "javascript:window.open('../exca/formatodoc2.aspx')";
                //ScriptManager.RegisterStartupScript(up, up.GetType(), "ExamenCalidad", tempabc, true);
                //Response.Redirect("../exca/formatodoc2.aspx");
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void tipfolDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SetDataSourceDetalle(null);
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void moverButton_Click(object sender, EventArgs e)
        {
            try
            {
                USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result seleccionado = obtenerobjlista();
                int num_prio = Int32.Parse(posOsaTextBox.Text.ToString());
                string usuario = _ParametrosIni.Usuario.ToString();
                usuario = usuario.Substring(4);
                if (seleccionado != null )
                {
                    if (Double.Parse(posOsaTextBox.Text) > 0)
                    {
                        if (seleccionado.OSASRESP.Equals(usuario) || superus())
                        {
                            if (seleccionado.OSAROW != num_prio)
                            {
                                if (Int32.Parse(posOsaTextBox.Text.ToString()) < seleccionado.OSAROW)
                                {
                                    int ultimo = ultimo_prio(seleccionado, num_prio);
                                    if (ultimo == 0)
                                    {
                                        sube_prio(seleccionado, num_prio);
                                    }
                                    else
                                    {
                                        //MostrarMensaje("No es posible priorizar sobre la OSA N° " + ultimo + ".");
                                        MostrarMensaje("No es posible priorizar sobre la OSA con Prioridad N° " + ultimo + ".");
                                    }
                                }
                                else
                                {
                                    baja_prio(seleccionado, num_prio);
                                }
                            }
                            else
                            {
                                MostrarMensaje("No se ha cambiado la prioridad de la OSA.");
                            }
                        }
                        else
                        {
                            MostrarMensaje("No puede cambiar la prioridad de esta OSA.");
                        }
                    }
                    else
                    {
                        MostrarMensaje("La prioridad debe ser mayor a 0.");
                    }
                }
                else
                {
                    MostrarMensaje("Debe seleccionar un pedido.");
                }
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        #endregion

        #region Metodos
        private void CargaDatosIniciales()
        {
            InicializaDatos();
            CargaFoliosUsuario();
            CargaOsasEmitidas();
        }
        private void InicializaDatos()
        {
            //consumos
            SetDataSourceOsas(null);

            //asignacion
            SetDataSourceDetalle(null);
        }
        public void CargaFoliosUsuario()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_TIPOS_FOLIO_USUARIO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(_ParametrosIni.Usuario);
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        var firstitem = tipfolDropDownList.Items[0];
                        tipfolDropDownList.Items.Clear();
                        tipfolDropDownList.Items.Add(firstitem);

                        datos = Funciones.Deserialize<List<PEUSTF>>(resultado.VALSAL[1]);
                        foreach (PEUSTF item in datos)
                        {
                            tipfolDropDownList.Items.Add(new ListItem(item.PETIFO.TIFODESC, item.PETIFO.TIFOCOFO.ToString()));
                        }
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void MuestraDetalleOsa()
        {
            GridViewRow row = pendientesGridView.SelectedRow;

            if (row != null)
            {
                string corrLiq = row.Cells[0].Text;
                //LENAR TABPAGES
                List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> detConsumo = OsasPendientes;

                if (detConsumo != null && detConsumo[0].OSAROW != -1)
                {
                    USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result consumo = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));

                    CargaDetalleOsa(consumo.OSASFOLI.ToString());
                    posOsaTextBox.Text = consumo.OSAROW.ToString();
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }
        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }
        protected void buscarButton_Click(object sender, EventArgs e)
        {
            CargaOsasEmitidas();
        }
        private void CargaOsasEmitidas()
        {
            IappServiceClient clt = null;

            try
            {
                if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
                {
                    SetDataSourceOsas(null);

                    return;
                }
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_OSAS_EMITIDAS_PRIORIZAR;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>>(resultado.VALSAL[1]);

                        SetDataSourceOsas(datos);
                    }
                    else
                    {
                        SetDataSourceOsas(null);
                    }

                }
                else
                {
                    SetDataSourceOsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionConsumo();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void CargaDetalleOsa(string folio)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void SetDataSourceOsas(List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> _listaConsumos)
        {
            bool limpiaDet = false;
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtienePendientesDefault();
                limpiaDet = true;
            }

            OsasPendientes = _listaConsumos;
            pendientesGridView.DataSource = OsasPendientes;
            pendientesGridView.DataBind();
            if (pendientesGridView.SelectedIndex == -1 || limpiaDet)
            {
                SetDataSourceDetalle(null);
            }
        }
        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
            }

            DetalleOsaPendiente = _listaAsignacion;
            detalleGridView.DataSource = DetalleOsaPendiente;
            detalleGridView.DataBind();
        }
        private List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> ObtienePendientesDefault()
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>();
            datos.Add(new USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result() { OSAROW = -1 });
            return datos;
        }
        private List<USP_OBTIENE_DETALLE_OSA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_Result() { OSASSECU = -1 });
            return datos;
        }
        private List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> OsasPendientes
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_EMITIDAS_PRIORIZA] as List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtienePendientesDefault();

                    OsasPendientes = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_EMITIDAS_PRIORIZA] = value;
            }
        }
        private List<USP_OBTIENE_DETALLE_OSA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_DETALLE_OSA] as List<USP_OBTIENE_DETALLE_OSA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_DETALLE_OSA] = value;
            }
        }
        protected void sube_prio(USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result Seleccionado, int num_prio)
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> Listgrilla = OsasPendientes;
            List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> Listprioridad = new List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>();
            try
            {
                int count = 1;
                foreach (var item in Listgrilla)
                {
                    if (item != Seleccionado)
                    {
                        if (count != num_prio)
                        {
                            item.OSAROW = count;
                            Listprioridad.Add(item);
                        }
                        else
                        {
                            Seleccionado.OSAROW = count;
                            Seleccionado.CAOSPRIO = 1;

                            Listprioridad.Add(Seleccionado);
                            count++;
                            item.OSAROW = count;
                            Listprioridad.Add(item);
                        }
                        count++;
                    }
                    else
                        break;
                }
                List<appWcfService.PECAOS> listprio = convertPecaos(Listprioridad);
                if (listprio != null)//genera pedido interno en pecaos
                {
                    string h = _ParametrosIni.Usuario.ToString();
                    h = h.Substring(4);
                    prioriza(listprio, h);
                    //MostrarMensaje("generado");

                }
                else
                    MostrarMensaje(_ParametrosIni.ErrorGenerico("No se pudo realizar la priorización."));
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected void baja_prio(USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result Seleccionado, int num_prio)
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> Listgrilla = OsasPendientes;
            List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> Listprioridad = new List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>();
            try
            {
                int count = 1;
                foreach (var item in Listgrilla)
                {
                    if (item != Seleccionado)
                    {
                        item.OSAROW = count;
                        Listprioridad.Add(item);
                        count++;
                    }
                    if (count == num_prio)
                    {
                        Seleccionado.OSAROW = count;
                        Seleccionado.CAOSPRIO = 1;
                        Listprioridad.Add(Seleccionado);
                        break;
                    }
                }
                List<appWcfService.PECAOS> listprio = convertPecaos(Listprioridad);
                if (listprio != null)//genera pedido interno en pecaos
                {
                    string h = _ParametrosIni.Usuario.ToString();
                    h = h.Substring(4);
                    prioriza(listprio, h);
                    //MostrarMensaje("generado");

                }
                else
                    MostrarMensaje(_ParametrosIni.ErrorGenerico("No se pudo realizar la priorización."));
                //baja prioridad
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }
        protected int ultimo_prio(USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result seleccionado, int num_prio)
        {
            int ultimoprio = 0;
            try
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> grilla = OsasPendientes;

                int count = 1;

                foreach (var item in grilla)
                {
                    if (count >= num_prio && count < seleccionado.OSAROW)
                    {
                        if (item.CAOSUSPR != null)
                        {
                            ultimoprio = count;
                        }
                    }
                    if (item == seleccionado)
                    {
                        break;
                    }
                    count++;
                }
                return ultimoprio;
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return ultimoprio;
            }
        }
        protected USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result obtenerobjlista()
        {
            try
            {
                GridViewRow row = pendientesGridView.SelectedRow;

                if (row != null)
                {
                    string corrLiq = row.Cells[0].Text;
                    //LENAR TABPAGES
                    List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> detConsumo = OsasPendientes;

                    if (detConsumo != null && detConsumo[0].OSAROW != -1)
                    {
                        USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result consumo = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                        return consumo;
                    }
                    return null;
                }
                return null;
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return null;
            }
        }
        protected List<appWcfService.PECAOS> convertPecaos(List<USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> listprio)
        {
            try
            {
                List<PECAOS> listaprio = new List<PECAOS>();
                foreach (var item in listprio)
                {
                    PECAOS osa = new PECAOS();
                    osa.CAOSIDCO = item.CAOSIDCO;
                    osa.CAOSIDES = 2;
                    osa.CAOSUSCR = item.OSASRESP;
                    osa.CAOSFOLI = item.OSASFOLI;
                    osa.CAOSPRIO = item.OSAROW;
                    osa.CAOSEPRI = item.CAOSPRIO;

                    listaprio.Add(osa);
                }
                if (genera_pedido(listaprio))
                {
                    return listaprio;
                }
                else
                    return null;
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return null;
            }
        }
        private bool genera_pedido(List<appWcfService.PECAOS> lista)
        {
            IappServiceClient clt = null;
            bool result = false;
            string anterior = "";

            try
            {
                foreach (var item in lista)
                {
                    if(!item.CAOSFOLI.ToString().Equals(anterior))
                    {
                        anterior = item.CAOSFOLI.ToString();
                        RESOPE resultado;
                        clt = _ParametrosIni.IniciaNuevoCliente();

                        //codigo de operacion
                        PAROPE argumentos = new PAROPE();
                        argumentos.CODOPE = CodigoOperacion.GENERA_PEDIDO_INTERNO;
                        //asigna parametros entrada en orden
                        List<string> parEnt = new List<string>();
                        parEnt.Add(Utils.Serialize(item));
                        parEnt.Add(_ParametrosIni.Usuario);

                        argumentos.VALENT = parEnt.ToArray();
                        resultado = clt.EjecutaOperacion(argumentos);
                        if (resultado.ESTOPE)
                        {
                            if (resultado.VALSAL[0] != "0")
                            {
                                item.CAOSIDCO = Decimal.Parse(resultado.VALSAL[0]);
                            }
                        }
                        else
                        {
                            MostrarMensaje(resultado.MENERR);
                            result = false;
                            break;
                            //ErrorLabel.Font.Bold = true;
                            //ErrorLabel.Text = resultado.MENERR;
                        }
                        result = resultado.ESTOPE;
                    }
                }
                return result;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return result;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        public bool prioriza(List<appWcfService.PECAOS> lista, string usuario)
        {
            bool resultadoOpe;
            IappServiceClient clt = null;
            resultadoOpe = false;
            try
            {
                RESOPE resultado; //Resultado de Operacion
                clt = _ParametrosIni.IniciaNuevoCliente();
                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GUARDA_PRIORIDAD;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(lista));
                parEnt.Add(usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);

                if (resultado.ESTOPE)
                {
                    MostrarMensaje("Se priorizó Correctamente su registro seleccionado.");
                }
                else
                {
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                    MostrarMensaje(resultado.MENERR);
                }

            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
            return resultadoOpe;
        }

        private List<PEUSTF> datos
        {
            get
            {
                List<PEUSTF> dt = HttpContext.Current.Session[Constantes.TIPO_FOLIO] as List<PEUSTF>;
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.TIPO_FOLIO] = value;
            }
        }

        private bool superus()
        {
            decimal value = 0;
            switch (tipfolDropDownList.SelectedValue)
            {
                case "W":
                    value = 3;
                    break;
                case "Z":
                    value = 4;
                    break;
                case "5":
                    value = 1;
                    break;
                case "9":
                case "8":
                case "89":
                    value = 2;
                    break;
                default:
                    value = 0;
                    break;
            }
            if (value != 0)
            {
                foreach (var item in datos)
                {
                    if (value == item.USTFIDTF)
                    {
                        return item.USTFSUUS;
                    }
                }
            }
            return false;
        }
        #endregion

        protected void posOsaTextBox_TextChanged(object sender, EventArgs e)
        {
            //if (Double.Parse(posOsaTextBox.Text) <= 0)
            //{
            //    USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result seleccionado = obtenerobjlista();
            //    posOsaTextBox.Text = seleccionado.OSAROW.ToString();
            //}
        }
    }
}