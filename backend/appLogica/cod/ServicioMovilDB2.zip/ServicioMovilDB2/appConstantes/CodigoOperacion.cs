﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace appConstantes
{
    public class CodigoOperacion
    {
        //public const string VALIDA_USUARIO = "COM001";
        #region Usuarios
        public const string VALIDA_USUARIO = "US001";
        public const string CAMBIAR_PASSWORD = "US002";
        #endregion
        
        public const string MOSTRAR_PEDIDOS_APP = "SPN003";

    }

}
