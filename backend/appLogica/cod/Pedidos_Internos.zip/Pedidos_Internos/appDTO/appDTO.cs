﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace appWcfService
{
    public class Global
    {
        //public string Usuario{get; set; }
        public static string Usuario = "EJEMPLO6";
    }
    public class PECAPE
    {
        public decimal CAPEIDCP { get; set; }
        public string CAPESERI { get; set; }
        public decimal CAPENUME { get; set; }
        public string CAPEIDCL { get; set; }
        public System.DateTime CAPEFECH { get; set; }
        public string CAPEDIRE { get; set; }
        public decimal CAPEIDES { get; set; }
        public decimal CAPEEPRI { get; set; }
        public decimal CAPEPRIO { get; set; }
        public Nullable<System.DateTime> CAPEFEPR { get; set; }
        public string CAPEUSPR { get; set; }
        public string CAPENOTI { get; set; }
        public string CAPENOTG { get; set; }
        public string CAPEUSCR { get; set; }
        public System.DateTime CAPEFECR { get; set; }
        public string CAPEUSMO { get; set; }
        public Nullable<System.DateTime> CAPEFEMO { get; set; }

        public string CAPEUSEM { get; set; }
        public Nullable<System.DateTime> CAPEFHEM { get; set; }
        public string CAPEUSFP { get; set; }
        public Nullable<System.DateTime> CAPEFHFP { get; set; }
        public string CAPEUSIP { get; set; }
        public Nullable<System.DateTime> CAPEFHIP { get; set; }
        public string CAPEUSAP { get; set; }
        public Nullable<System.DateTime> CAPEFEAP { get; set; }
        //public  PEESTA PEESTA { get; set; }
        public TCLIE TCLIE { get; set; }
        //public virtual ICollection<PEPEPG> PEPEPG { get; set; }
        //[System.Diagnostics.CodeAnalysis.SuppressMessage("Microsoft.Usage", "CA2227:CollectionPropertiesShouldBeReadOnly")]
        //public virtual ICollection<PEDEPE> PEDEPE { get; set; }

        public bool CAPECHECK { get; set; } //Check para anular el pedido 

        public string CAPENUMC
        {
            get
            {
                return CAPENUME.ToString().Trim().PadLeft(7, '0');
            }
            //ejemplo
        }
        public string CAPEESTA
        {
            get
            {
                return CAPEIDES.ToString().Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Espera de aprobación").Replace("5", "Completado").Replace("9", "Anulado");
            }
            //ejemplo
        }
    }
    public class TCLIE
    {
        public string CLICVE { get; set; }
        public string CLINOM { get; set; }
        public string CLIABR { get; set; }
        public string CLIDIR { get; set; }
        public string CLICPO { get; set; }
        public string CLIDIS { get; set; }
        public string CLIPRO { get; set; }
        public string CLIDPT { get; set; }
        public string CLIPAI { get; set; }
        public string CLITE1 { get; set; }
        public string CLITE2 { get; set; }
        public string CLITE3 { get; set; }
        public string CLITE4 { get; set; }
        public string CLIRUC { get; set; }
        public string CLIRF1 { get; set; }
        public string CLIRF2 { get; set; }
        public string CLIRF3 { get; set; }
        public string CLIVEN { get; set; }
        public string CLICOB { get; set; }
        public string CLIZON { get; set; }
        public string CLISIT { get; set; }
        public decimal CLILCR { get; set; }
        public decimal CLISAL { get; set; }
        public string CLISCR { get; set; }
        public string CPACVE { get; set; }
        public decimal CLDSCT { get; set; }
        public string CLPREC { get; set; }
        public string CLCNOM { get; set; }
        public string CLCPUE { get; set; }
        public string CLMAIL { get; set; }
        public string CLTIDE { get; set; }
        public string CLNIDE { get; set; }

    }
    public class I1DD20A
    {
        public string ARTX0 { get; set; }
        public decimal ARTCIA { get; set; }
        public string ARTCITEM { get; set; }
        public string ARTDES { get; set; }
        public string ARTMED { get; set; }
        public string ARTGRINV { get; set; }
        public string ARTGIRO { get; set; }
        public string ARTGRCOM { get; set; }
        public string ARTCCOMP { get; set; }
        public decimal ARTCCONS { get; set; }
        public decimal ARTCANA1 { get; set; }
        public decimal ARTCANA2 { get; set; }
        public string ARTCLINV { get; set; }
        public string ARTCIMP1 { get; set; }
        public string ARTCIMP2 { get; set; }
        public string ARTCIMP3 { get; set; }
        public string ARTCPLTR { get; set; }
        public string ARTUPLTR { get; set; }
        public decimal ARTSTSEG { get; set; }
        public decimal ARTPREOR { get; set; }
        public decimal ARTTLOTE { get; set; }
        public decimal ARTSTMAX { get; set; }
        public decimal ARTLDREV { get; set; }
        public decimal ARTFUREV { get; set; }
        public decimal ARTTREXT { get; set; }
        public string ARTTHIST { get; set; }
        public string ARTTPROM { get; set; }
        public decimal ARTPMVL1 { get; set; }
        public decimal ARTPMVL2 { get; set; }
        public decimal ARTLDCNT { get; set; }
        public decimal ARTFUCNT { get; set; }
        public decimal ARTSTOCK { get; set; }
        public decimal ARTSTANT { get; set; }
        public decimal ARTCANOR { get; set; }
        public decimal ARTCANRE { get; set; }
        public decimal ARTPSALM { get; set; }
        public decimal ARTAASAN { get; set; }
        public decimal ARTSTVA1 { get; set; }
        public decimal ARTCOSU1 { get; set; }
        public decimal ARTCOSU2 { get; set; }
        public string ARTTCOSR { get; set; }
        public decimal ARTCOUM1 { get; set; }
        public decimal ARTCOUM2 { get; set; }
        public string ARTTMAT { get; set; }
        public decimal ARTPREU1 { get; set; }
        public decimal ARTPREU2 { get; set; }
        public string ARTCDSRC { get; set; }
        public decimal ARTSTVA2 { get; set; }
        public string ARTX1 { get; set; }
        public decimal ARTFUSAL { get; set; }
        public decimal ARTFUENT { get; set; }
        public decimal ARTFUREQ { get; set; }
        public decimal ARTFUOC { get; set; }
        public decimal ARTFALTA { get; set; }
        public decimal ARTFBAJA { get; set; }
        public decimal ARTUPTRN { get; set; }
        public string ARTCACT { get; set; }
        public decimal ARTAASAE { get; set; }
        public decimal ARTUPROV { get; set; }
        public string ARTCMON { get; set; }
        public string ARTMEDA { get; set; }
        public decimal ARTEQMED { get; set; }
        public string ARTUBI { get; set; }
        public decimal ARTSTOCM { get; set; }
        public decimal ARTCANOM { get; set; }
        public decimal ARTCANRM { get; set; }
        public string ARTACTEM { get; set; }
        public string ARTACTOM { get; set; }
        public string ARTACTRM { get; set; }
        public decimal ARTCRSG { get; set; }
        public decimal ARTNRELM { get; set; }
        public decimal ARTNRELD { get; set; }
        public decimal ARTNRELH { get; set; }
        public string ARTFCTL { get; set; }
    }
    public partial class PEBOLS
    {
        public decimal BOLSIDBO { get; set; }
        public string BOLSCOAR { get; set; }
        public decimal BOLSIDTC { get; set; }
        public string BOLSCOEM { get; set; }
        public string BOLSCOCA { get; set; }
        public decimal BOLSESTA { get; set; }
        public string BOLSUSCR { get; set; }
        public System.DateTime BOLSFECR { get; set; }
        public string BOLSUSMO { get; set; }
        public Nullable<System.DateTime> BOLSFEMO { get; set; }
        public Nullable<decimal> BOLSCANT { get; set; }
        public Nullable<decimal> BOLSPESO { get; set; }

    }
    public class PEDEPE
    {
        public decimal DEPEIDDP { get; set; }
        public decimal DEPEIDCP { get; set; }
        public string DEPECOAR { get; set; }
        public string DEPEPART { get; set; }
        public string DEPECONT { get; set; }
        public decimal DEPEALMA { get; set; }
        public decimal DEPECASO { get; set; }
        public decimal DEPEPESO { get; set; }
        public decimal DEPECAAT { get; set; }
        public decimal DEPEPEAT { get; set; }
        public decimal DEPEPERE { get; set; }
        public decimal DEPETADE { get; set; }
        public decimal DEPEPEBR { get; set; }
        public Nullable<decimal> DEPESTOC { get; set; }
        public decimal DEPEESTA { get; set; }
        public decimal DEPEDISP { get; set; }
        public decimal DEPENUBU { get; set; }
        public string DEPEUSCR { get; set; }
        public System.DateTime DEPEFECR { get; set; }
        public string DEPEUSMO { get; set; }
        public Nullable<System.DateTime> DEPEFEMO { get; set; }
        public string DEPEDSAR { get; set; }
        public int DEPESERS { get; set; }
        public decimal DEPESECR { get; set; }



        public virtual I1DD20A I1DD20A { get; set; }
        //public virtual ICollection<PEBODP> PEBODP { get; set; }
        public virtual PECAPE PECAPE { get; set; }
        //public virtual ICollection<PEDPDG> PEDPDG { get; set; }
        //public virtual ICollection<PEHIMO> PEHIMO { get; set; }

        public bool CHECKSEL { get; set; }
        public bool CHECKDEL { get; set; }

    }
    public partial class PEBODP
    {
        public decimal BODPIDDE { get; set; }
        public Nullable<decimal> BODPIDBO { get; set; }
        public Nullable<decimal> BODPIDDP { get; set; }
        public decimal BODPALMA { get; set; }
        public string BODPPART { get; set; }
        public string BODPCOAR { get; set; }
        public decimal BODPCANT { get; set; }
        public decimal BODPPESO { get; set; }
        public decimal BODPPERE { get; set; }
        public decimal BODPDIFE { get; set; }
        public Nullable<decimal> BODPIDDO { get; set; }
        public decimal BODPSTCE { get; set; }
        public decimal BODPINBO { get; set; }
        public decimal BODPTADE { get; set; }
        public decimal BODPPEBR { get; set; }
        public decimal BODPESTA { get; set; }
        public string BODPUSCR { get; set; }
        public System.DateTime BODPFECR { get; set; }
        public string BODPUSMO { get; set; }
        public Nullable<System.DateTime> BODPFEMO { get; set; }
        public decimal BODPSECR { get; set; }
        public decimal BODPTAUN { get; set; }

        public  PEBOLS PEBOLS { get; set; }
        public virtual PEDEOS PEDEOS { get; set; }
        public virtual PEDEPE PEDEPE { get; set; }

    }
    public partial class PEDPDG
    {
        public decimal DPDGIDDD { get; set; }
        public decimal DPDGIDDP { get; set; }
        public decimal DPDGIDDG { get; set; }
        public string DPDGUSCR { get; set; }
        public System.DateTime DPDGFECR { get; set; }
        public string DPDGUSMO { get; set; }
        public Nullable<System.DateTime> DEPDGFEMO { get; set; }

        public virtual PEDEPE PEDEPE { get; set; }
    }
    public partial class PEHIMO
    {
        public decimal HIMOIDIM { get; set; }
        public string HIMOCOAR { get; set; }
        public Nullable<decimal> HIMOIDDO { get; set; }
        public Nullable<decimal> HIMOIDDP { get; set; }
        public decimal HIMOIDBO { get; set; }
        public System.DateTime HIMOFECH { get; set; }
        public Nullable<decimal> HIMOCANT { get; set; }
        public decimal HIMOPESO { get; set; }
        public string HIMOUSCR { get; set; }
        public System.DateTime HIMOFECR { get; set; }
        public string HIMOUSMO { get; set; }
        public Nullable<System.DateTime> HIMOFEMO { get; set; }

        public virtual PEBOLS PEBOLS { get; set; }
        //public virtual PEDEOS PEDEOS { get; set; }
        public virtual PEDEPE PEDEPE { get; set; }
    }
    public partial class PEESTA
    {
        public decimal ESTAIDES { get; set; }
        public string ESTADESC { get; set; }
        public string ESTAUSCR { get; set; }
        public System.DateTime ESTAFECR { get; set; }
        public string ESTAUSMO { get; set; }
        public Nullable<System.DateTime> ESTAFEMO { get; set; }

        //public virtual ICollection<PECAOS> PECAOS { get; set; }
        //public virtual ICollection<PECAPE> PECAPE { get; set; }
    }
    public class PEPASI
    {
        public decimal PASIIDPA { get; set; }
        public decimal PASIESTA { get; set; }
        public string PASIUSCR { get; set; }
        public System.DateTime PASIFECR { get; set; }
        public string PASIUSMO { get; set; }
        public Nullable<System.DateTime> PASIFEMO { get; set; }

        //public  PECOLU PECOLU { get; set; }
        //public  PENIVE PENIVE { get; set; }

    }
    public class PECASI
    {
        public string CASICOCA { get; set; }
        public decimal CASIIDPA { get; set; }
        public string CASIIDNI { get; set; }
        public decimal CASIIDCO { get; set; }
        public Nullable<decimal> CASICAPA { get; set; }
        public decimal CASIESTA { get; set; }
        public Nullable<decimal> CASIALTU { get; set; }
        public Nullable<decimal> CASILARG { get; set; }
        public Nullable<decimal> CASIANCH { get; set; }
        public string CASIUSCR { get; set; }
        public System.DateTime CASIFECR { get; set; }
        public string CASIUSMO { get; set; }
        public Nullable<System.DateTime> CASIFEMO { get; set; }

        //public virtual ICollection<PEBOLS> PEBOLS { get; set; }    
        //public virtual ICollection<PEHIBO> PEHIBO { get; set; }
        //public virtual PECOLU PECOLU { get; set; }
        //public virtual PENIVE PENIVE { get; set; }
    }
    public partial class PENIVE
    {
        public string NIVEIDNI { get; set; }
        public decimal NIVEIDPA { get; set; }
        public decimal NIVEESTA { get; set; }
        public string NIVEUSCR { get; set; }
        public System.DateTime NIVEFECR { get; set; }
        public string NIVEUSMO { get; set; }
        public Nullable<System.DateTime> NIVEFEMO { get; set; }

        //public virtual ICollection<PECASI> PECASI { get; set; }
        //public virtual PEPASI PEPASI { get; set; }
    }
    public class PECOLU
    {
        public decimal COLUIDCO { get; set; }
        public decimal COLUIDPA { get; set; }
        public decimal COLUESTA { get; set; }
        public string COLUUSCR { get; set; }
        public System.DateTime COLUFECR { get; set; }
        public string COLUUSMO { get; set; }
        public Nullable<System.DateTime> COLUFEMO { get; set; }

        //public virtual ICollection<PECASI> PECASI { get; set; }
        //public virtual PEPASI PEPASI { get; set; }
    }
    //
    public class PEPARM
    {
        public decimal PARMIDPA { get; set; }
        public string PARMDSPA { get; set; }
        public string PARMVAPA { get; set; }
    }
    public class CSALES
    {
        public decimal ALESCIA { get; set; }
        public string ALESESTA { get; set; }
        public decimal ALESALMA { get; set; }
        public string ALESDESC { get; set; }
        public string ALESPROP { get; set; }
        public string ALESSTAT { get; set; }
        public string ALESFLG1 { get; set; }
        public string ALESFLG2 { get; set; }
        public string ALESFLG3 { get; set; }
    }
    public class FCTIEM
    {
        public decimal TIEMCIA { get; set; }
        public string TIEMCOTE { get; set; }
        public string TIEMDETE { get; set; }
        public string TIEMTIPO { get; set; }
        public decimal TIEMLARG { get; set; }
        public decimal TIEMANCH { get; set; }
        public decimal TIEMALTU { get; set; }
        public decimal TIEMTIES { get; set; }
        public decimal TIEMTARA { get; set; }
        public decimal TIEMACON { get; set; }
        public string TIEMARTI { get; set; }

        public GMCAEM GMCAEM { get; set; }
    }
    public class GMCAEM
    {
        public decimal CAEMCIA { get; set; }
        public string CAEMCOEM { get; set; }
        public System.DateTime CAEMFECH { get; set; }
        public decimal CAEMTURN { get; set; }
        public decimal CAEMPNTO { get; set; }
        public decimal CAEMDTTO { get; set; }
        public decimal CAEMDEEM { get; set; }
        public decimal CAEMACTO { get; set; }
        public decimal CAEMPBTO { get; set; }
        public decimal CAEMCAIT { get; set; }
        public string CAEMTIEM { get; set; }
        public string CAEMNPED { get; set; }
        public string CAEMDESP { get; set; }
        public string CAEMNNDC { get; set; }
        public decimal CAEMALMA { get; set; }
        public string CAEMPART { get; set; }
        public string CAEMMSPA { get; set; }
        public string CAEMESEM { get; set; }
        public string CAEMESRE { get; set; }
        public string CAEMUSER { get; set; }
        public string CAEMRESP { get; set; }
        public string CAEMUBIC { get; set; }

        public FCTIEM FCTIEM { get; set; }
    }
    public class GMDEEM
    {
        public decimal DEEMCIA { get; set; }
        public string DEEMCOEM { get; set; }
        public decimal DEEMSECU { get; set; }
        public System.DateTime DEEMFECH { get; set; }
        public System.DateTime DEEMHORA { get; set; }
        public string DEEMPART { get; set; }
        public string DEEMARTI { get; set; }
        public decimal DEEMALMA { get; set; }
        public decimal DEEMCANT { get; set; }
        public string DEEMTIPE { get; set; }
        public decimal DEEMPNET { get; set; }
        public decimal DEEMDEST { get; set; }
        public decimal DEEMACON { get; set; }
        public string DEEMUSER { get; set; }
        public string DEEMESTA { get; set; }
        public decimal DEEMCAST { get; set; }
        public decimal DEEMPEST { get; set; }
        public decimal DEEMSTCE { get; set; }
        public decimal DEEMESBO { get; set; }
    }
    public class I1DD41A
    {
        public decimal LOTCIA { get; set; }
        public string LOTITEM { get; set; }
        public string LOTPARTI { get; set; }
        public decimal LOTALM { get; set; }
        public decimal LOTSTOCK { get; set; }
        public decimal LOTCANOR { get; set; }
        public decimal LOTCANRE { get; set; }
        public decimal LOTFDOCU { get; set; }
        public decimal LOTSALPA { get; set; }
        public string LOTX0 { get; set; }
        public string LOTSTPAR { get; set; }
        public string LOTUBIFI { get; set; }
        public decimal LOTCAUNI { get; set; }
    }
    public class PECAOS
    {
        public decimal CAOSIDCO { get; set; }
        public string CAOSFOLI { get; set; }
        public decimal CAOSIDES { get; set; }
        public decimal CAOSEPRI { get; set; }
        public Nullable<System.DateTime> CAOSFEPR { get; set; }
        public string CAOSUSPR { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSNUBU { get; set; }
        public string CAOSUSCR { get; set; }
        public System.DateTime CAOSFECR { get; set; }
        public string CAOSUSMO { get; set; }
        public Nullable<System.DateTime> CAOSFEMO { get; set; }
        public string CAOSUSIP { get; set; }
        public Nullable<System.DateTime> CAOSFHIP { get; set; }
        public string CAOSUSFP { get; set; }
        public Nullable<System.DateTime> CAOSFHFP { get; set; }
        public string CAOSUSAP { get; set; }
        public Nullable<System.DateTime> CAOSFEAP { get; set; }
        public decimal CAOSEXTO { get; set; }
        public string CAOSNOTA { get; set; }

        //public virtual PEESTA PEESTA { get; set; }
        //public virtual PEDEOS PEDEOS { get; set; }
    }
    public class PEDEOS
    {
        public decimal DEOSIDDO { get; set; }
        public decimal DEOSIDCO { get; set; }
        public decimal DEOSSECU { get; set; }
        public string DEOSFOLI { get; set; }
        public decimal DEOSPESO { get; set; }
        public decimal DEOSPEAT { get; set; }
        public decimal DEOSCAAT { get; set; }
        public decimal DEOSPERE { get; set; }
        public Nullable<decimal> DEOSSTOC { get; set; }
        public decimal DEOSESTA { get; set; }
        public string DEOSUSCR { get; set; }
        public System.DateTime DEOSFECR { get; set; }
        public string DEOSUSMO { get; set; }
        public Nullable<System.DateTime> DEOSFEMO { get; set; }
        public decimal DEOSTADE { get; set; }
        public decimal DEOSPEBR { get; set; }
        public string DEOSPART { get; set; }
        public string DEOSCOAR { get; set; }
        public decimal DEOSALMA { get; set; }
        public decimal DEOSPEOR { get; set; }
        public decimal DEOSCAOR { get; set; }
        public decimal DEOSESPA { get; set; }
        public PEBODP PEBODP { get; set; }
        public PECAOS PECAOS { get; set; }
        public PEHIMO PEHIMO { get; set; }
        public decimal DEOSSECR { get; set; }
    }
    public class PEPEPG
    {
        public decimal PEPGIDPP { get; set; }
        public decimal PEPGIDCP { get; set; }
        public decimal PEPGIDPG { get; set; }
        public string PEPGUSCR { get; set; }
        public System.DateTime PEPGFECR { get; set; }
        public string PEPGUSMO { get; set; }
        public Nullable<System.DateTime> PEPGFEMO { get; set; }

        public virtual PECAPE PECAPE { get; set; }
    }
    public class PETMKB
    {
        public decimal TMKBIDTM { get; set; }
        public string TMKBDESC { get; set; }
        public string TMKBUSCR { get; set; }
        public System.DateTime TMKBFECR { get; set; }
        public string TMKBUSMO { get; set; }
        public Nullable<System.DateTime> TMKBFEMO { get; set; }
        public string TMKBSIGN { get; set; }
        public virtual PEKABO PEKABO { get; set; }
    }
    public class PEKABO
    {
        public decimal KABOIDKB { get; set; }
        public decimal KABOIDBO { get; set; }
        public decimal KABOIDTM { get; set; }
        public System.DateTime KABOFECH { get; set; }
        public decimal KABOCANT { get; set; }
        public decimal KABOPESO { get; set; }
        public Nullable<decimal> KABOIDDP { get; set; }
        public Nullable<decimal> KABOIDDO { get; set; }
        public string KABOUSCR { get; set; }
        public System.DateTime KABOFECR { get; set; }
        public string KABOUSMO { get; set; }
        public Nullable<System.DateTime> KABOFEMO { get; set; }
        public string KABOPART { get; set; }
        public string KABOITEM { get; set; }
        public decimal KABOTARA { get; set; }
        public decimal KABOPEBR { get; set; }
        public decimal KABOALMA { get; set; }

        public virtual PEBOLS PEBOLS { get; set; }
        public virtual PETMKB PETMKB { get; set; }
    }
    public class PRCALI
    {
        public decimal CALICIA { get; set; }
        public string CALICODI { get; set; }
        public string CALIGRUP { get; set; }
        public string CALISIGL { get; set; }
        public string CALIDEAB { get; set; }
        public string CALICOMP { get; set; }
        public string CALIABRE { get; set; }
        public string CALIFLCB { get; set; }
        public string CALIFLNT { get; set; }
        public string CALIBASE { get; set; }
        public string CALIFLLF { get; set; }
        public string CALIFICA { get; set; }
        public decimal CALIMIST { get; set; }
        public decimal CALILOST { get; set; }
        public decimal CALIREF0 { get; set; }
        public decimal CALIREW0 { get; set; }
        public decimal CALIRES0 { get; set; }
        public decimal CALIRET0 { get; set; }
        public decimal CALIREH0 { get; set; }
        public string CALISTAT { get; set; }
        public string CALIFDES { get; set; }
    }
    public class PROSAS
    {
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public decimal OSASSECU { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASALMA { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal OSASCAEN { get; set; }
        public System.DateTime OSASFEAT { get; set; }
        public string OSASREEN { get; set; }
        public decimal OSASCCOS { get; set; }
        public string OSASDUEÑ { get; set; }
        public string OSASSTOS { get; set; }
        public decimal OSASUNID { get; set; }
        public string OSASFILL { get; set; }
        public string OSASFORZ { get; set; }
        public string OSASSTAT { get; set; }
    }
    public class PRPART
    {
        public decimal PARTCIA { get; set; }
        public string PARTNUPA { get; set; }
        public string PARTPLTA { get; set; }
        public string PARTARTI { get; set; }
        public decimal PARTCAPR { get; set; }
        public decimal PARTCAFA { get; set; }
        public decimal PARTCAMP { get; set; }
        public System.DateTime PARTFEEM { get; set; }
        public System.DateTime PARTFEIA { get; set; }
        public System.DateTime PARTFEEF { get; set; }
        public System.DateTime PARTFECS { get; set; }
        public System.DateTime PARTFEST { get; set; }
        public string PARTSTPR { get; set; }
        public decimal PARTREND { get; set; }
        public decimal PARTGRCA { get; set; }
        public string PARTTTR1 { get; set; }
        public decimal PARTTOR1 { get; set; }
        public string PARTTTR2 { get; set; }
        public decimal PARTTOR2 { get; set; }
        public string PARTTTR3 { get; set; }
        public decimal PARTTOR3 { get; set; }
        public string PARTVAPO { get; set; }
        public string PARTSPLC { get; set; }
        public string PARTPRFN { get; set; }
        public string PARTFANT { get; set; }
        public string PARTSERV { get; set; }
        public string PARTPROC { get; set; }
        public decimal PARTPESO { get; set; }
        public decimal PARTLONG { get; set; }
        public string PARTTPOV { get; set; }
        public string PARTEMBO { get; set; }
        public string PARTETIQ { get; set; }
        public string PARTCOLO { get; set; }
        public string PARTCOIN { get; set; }
        public string PARTSTAT { get; set; }
        public string TGRCDESC { get; set; }
        public string PARTTPOVD { get; set; }
        public string PARTEMBOD { get; set; }
        public string PARTETIQD { get; set; }
    }
    public class VSED00A
    {
        public decimal CVTCCIA { get; set; }
        public string CVTCNUCO { get; set; }
        public string CVTCEMBA { get; set; }
        public string CVTCTCON { get; set; }
        public decimal CVTCSECU { get; set; }
        public string CVTCCDCL { get; set; }
        public decimal CVTCIFOB { get; set; }
        public decimal CVTCIFLE { get; set; }
        public decimal CVTCISEG { get; set; }
        public decimal CVTCITOT { get; set; }
        public string CVTCREFE { get; set; }
        public string CVTCMTRA { get; set; }
        public string CVTCCLFA { get; set; }
        public decimal CVTCCDIR { get; set; }
        public decimal CVTCFEMO { get; set; }
        public decimal CVTCFEMM { get; set; }
        public decimal CVTCFERL { get; set; }
        public string CVTCMPAG { get; set; }
        public string CVTCCONF { get; set; }
        public decimal CVTCFING { get; set; }
        public decimal CVTCOPFI { get; set; }
        public string CVTCEMPA { get; set; }
        public decimal CVTCFACT { get; set; }
        public decimal CVTCCTOT { get; set; }
        public string CVTC1 { get; set; }
        public string CVTCTPCO { get; set; }
        public string CVTCPECO { get; set; }
        public string CVTCPUDE { get; set; }
        public string CVTCCCOM { get; set; }
        public decimal CVTCPCOM { get; set; }
        public decimal CVTCIDIO { get; set; }
        public string CVTC2 { get; set; }
        public string CVTCLIPR { get; set; }
        public decimal CVTCIARA { get; set; }
        public string CVTCTPMO { get; set; }
        public string CVTCBANC { get; set; }
        public decimal CVTCVACC { get; set; }
        public decimal CVTCPCON { get; set; }
        public decimal CVTCTPCA { get; set; }
        public string CVTCAGVE { get; set; }
        public decimal CVTCNDET { get; set; }
        public string CVTCTPEM { get; set; }
        public string CVTCSTAT { get; set; }
    }
    public class VSED02A
    {
        public decimal CVTDCIA { get; set; }
        public string CVTDNUCO { get; set; }
        public string CVTDEMBA { get; set; }
        public string CVTDTCON { get; set; }
        public decimal CVTDSECU { get; set; }
        public string CVTDCOCL { get; set; }
        public string CVTDARTI { get; set; }
        public decimal CVTDPRUN { get; set; }
        public string CVTDCALV { get; set; }
        public decimal CVTDCANT { get; set; }
        public decimal CVTDIMDE { get; set; }
        public decimal CVTDSAPE { get; set; }
        public string CVTDVIA { get; set; }
        public string CVTDCDAD { get; set; }
        public string CVTDTEÑI { get; set; }
        public string CVTDMEZC { get; set; }
        public string CVTDTPFE { get; set; }
        public string CVTDSTPR { get; set; }
        public string CVTDFANT { get; set; }
        public decimal CVTDFECO { get; set; }
        public decimal CVTDFEMO { get; set; }
        public decimal CVTDFERL { get; set; }
        public string CVTDTTZ1 { get; set; }
        public decimal CVTDTOR1 { get; set; }
        public string CVTDTTZ2 { get; set; }
        public decimal CVTDTOR2 { get; set; }
        public string CVTDVAPO { get; set; }
        public decimal CVTDPESO { get; set; }
        public decimal CVTDLONG { get; set; }
        public decimal CVTDTPOE { get; set; }
        public string CVTDETIQ { get; set; }
        public string CVTDACAB { get; set; }
        public string CVTDSTAT { get; set; }
    }
    public class PETIFO
    {
        public decimal TIFOIDTF { get; set; }
        public string TIFOCOFO { get; set; }
        public string TIFODESC { get; set; }
        public string TIFOUSCR { get; set; }
        public System.DateTime TIFOFECR { get; set; }
        public string TIFOUSMO { get; set; }
        public Nullable<System.DateTime> TIFOFEMO { get; set; }
        //public virtual PEUSTF PEUSTF { get; set; }
    }
    public class PEUSTF
    {
        public decimal USTFIDUF { get; set; }
        public string USTFUSUA { get; set; }
        public decimal USTFIDTF { get; set; }
        public bool USTFSUUS { get; set; }
        public string USTFUSCR { get; set; }
        public System.DateTime USTFFECR { get; set; }
        public string USTFUSMO { get; set; }
        public Nullable<System.DateTime> USTFFEMO { get; set; }

        public virtual PETIFO PETIFO { get; set; }
    }
    //STORED PROCEDURES
    public class USP_OBTIENE_OSAS_PENDIENTES_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string PARTSTPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "E. Parcial").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }
    }
    public class USP_OBTIENE_DETALLE_OSA_Result
    {
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public decimal OSASSECU { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASALMA { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal OSASCAEN { get; set; }
        public System.DateTime OSASFEAT { get; set; }
        public string OSASREEN { get; set; }
        public decimal OSASCCOS { get; set; }
        public string OSASDUEÑ { get; set; }
        public string OSASSTOS { get; set; }
        public decimal OSASUNID { get; set; }
        public string OSASFILL { get; set; }
        public string OSASFORZ { get; set; }
        public string OSASSTAT { get; set; }
        public decimal DEOSIDDO { get; set; }
        public decimal DEOSIDCO { get; set; }
        public decimal DEOSPEAT { get; set; }
        public decimal DEOSCAAT { get; set; }
        public decimal DEOSPERE { get; set; }
        public decimal DEOSSTOC { get; set; }
        public decimal DEOSESPA { get; set; }
        public decimal DEOSESTA { get; set; }
        public string PARTSTPR { get; set; }
        public decimal DEOSSECR { get; set; }
    }

    public class USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result
    {
        public Nullable<decimal> DEOSIDDO { get; set; }
        public decimal BOLSIDBO { get; set; }
        public string BOLSCOEM { get; set; }
        public string BOLSCOCA { get; set; }
        public string BOLSARTI { get; set; }
        public string BOLSPART { get; set; }
        public decimal BOLSALMA { get; set; }
        public decimal BOLSCANT { get; set; }
        public decimal BOLSPESO { get; set; }
        public decimal BODPIDDE { get; set; }
        public decimal BODPIDBO { get; set; }
        public decimal BODPIDDO { get; set; }
        public decimal BODPCANT { get; set; }
        public decimal BODPPESO { get; set; }
        public decimal TIEMTARA { get; set; }
        public decimal UNIDTARA { get; set; }
        public decimal BODPPERE { get; set; }
        public decimal BODPSTCE { get; set; }
        public decimal BODPINBO { get; set; }
        public decimal BODPTADE { get; set; }
        public decimal BODPPEBR { get; set; }
        public decimal BODPDIFE { get; set; }
        public decimal BODPESTA { get; set; }
        public decimal BODPSECR { get; set; }
        public decimal BODPTAUN { get; set; }

    }

    public class USP_OBTIENE_BOLSA_OSA_Result
    {
        public decimal DEOSIDDO { get; set; }
        public decimal BOLSIDBO { get; set; }
        public string BOLSCOEM { get; set; }
        //public string BOLSCOCA { get; set; }
        public string BOLSARTI { get; set; }
        public string BOLSPART { get; set; }
        public decimal BOLSALMA { get; set; }
        public decimal BOLSCANT { get; set; }
        public decimal BOLSPESO { get; set; }
        public decimal TIEMTARA { get; set; }
        public decimal UNIDTARA { get; set; }
    }

    public class USP_OBTIENE_BOLSA_UBICACION_Result
    {
        public string CAEMCOEM { get; set; }
        public string CAEMNPED { get; set; }
        public string MCSICL { get; set; }
        public string CAEMPART { get; set; }
        public System.DateTime CAEMFECH { get; set; }
        public Nullable<decimal> CAEMCAIT { get; set; }
        public Nullable<decimal> CAEMPNTO { get; set; }
        public Nullable<decimal> CAEMPBTO { get; set; }
    }
    public class USP_OBTIENE_DETALLE_BOLSA_Result
    {
        public string CAEMCOEM { get; set; }
        public decimal CAEMALMA { get; set; }
        public string DEEMPART { get; set; }
        public string DEEMARTI { get; set; }
        public decimal DEEMCANT { get; set; }
        public decimal DEEMPBRU { get; set; }
        public decimal DEEMDEST { get; set; }
        public Nullable<decimal> DEEMNETO { get; set; }
    }

    public class USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public Nullable<decimal> CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string OSASPADE { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }
    }

    public class USP_BUSCA_OSAS_PENDIENTES_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string PARTSTPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }

    }
    public class USP_OBTIENE_OSAS_PENDIENTES_WEB_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }
    }

    public class USP_OBTIENE_UBICACIONES_Result
    {
        public string UBICCOCA { get; set; }
        public int UBICCANT { get; set; }
    }

    public class USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Parcial").Replace("5", "Completado");
            }

        }
        public string OSASPADE { get; set; }
    }

    public class PRPAOB
    {
        public decimal PAOBCIA { get; set; }
        public string PAOBNUPA { get; set; }
        public decimal PAOBSECU { get; set; }
        public string PAOBOBSE { get; set; }
    }

    public class PRASIG
    {
        public int ASIGROW { get; set; }
        public string ASIGNUPE { get; set; }
        public string ASIGTIPE { get; set; }
        public decimal ASIGCLIE { get; set; }
        public string MCSICL { get; set; }
        public decimal ASIGCAPR { get; set; }
        public decimal ASIGALIN { get; set; }
        public DateTime ASIGFERQ { get; set; }
        public string ASIGSTAT { get; set; }
    }

    public class USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result
    {
        public string OSASFOLI { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public decimal OSASCAEN { get; set; }
        public string COINGRCO { get; set; }
        public DateTime OSASFEAT { get; set; }
        public string PARTARTI { get; set; }
        public string CALIDEAB { get; set; }
        public string CALICOMP { get; set; }

    }

    public class ORDENTRABAJO
    {
        public string OSASFOLI { get; set; }
        public List<PRPART> datpart { get; set; }
        public List<PRASIG> asigpart { get; set; }
        public List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result> reqmat { get; set; }
        public List<PRPAOB> obsepart { get; set; }
        public List<PRTMXR> maqtint { get; set; }

        public PECAOS cabosa { get; set; }

    }

    public class USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }


    }
    public class USP_OBTIENE_DETALLE_OSA_PLANTA_Result
    {
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public decimal OSASSECU { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASALMA { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal OSASCAEN { get; set; }
        public System.DateTime OSASFEAT { get; set; }
        public string OSASREEN { get; set; }
        public decimal OSASCCOS { get; set; }
        public string OSASDUEÑ { get; set; }
        public string OSASSTOS { get; set; }
        public decimal OSASUNID { get; set; }
        public string OSASFILL { get; set; }
        public string OSASFORZ { get; set; }
        public string OSASSTAT { get; set; }
        public decimal DEOSIDDO { get; set; }
        public decimal DEOSIDCO { get; set; }
        public decimal DEOSPEAT { get; set; }
        public decimal DEOSCAAT { get; set; }
        public decimal DEOSPERE { get; set; }
        public decimal DEOSSTOC { get; set; }
        public decimal DEOSESPA { get; set; }
        public decimal DEOSPEOR { get; set; }
        public Nullable<decimal> DEOSCAOR { get; set; }
        public decimal DEOSESTA { get; set; }
        public decimal DEOSSECR { get; set; }
    }

    public class USP_OBTIENE_OSAS_PENDIENTES_2_Result
    {
        public long OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string PARTSTPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Recepción").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }
    }
    public class USP_OBTIENE_OSAS_PLANTA_REABRIR_Result
    {
        public Nullable<long> OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Recepción").Replace("5", "Completada").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }
    }
    public class USP_BUSCA_OSAS_REABRIR_PLANTA_Result
    {
        public Nullable<long> OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Parcial").Replace("5", "Completada").Replace("6", "Parcial").Replace("7", "Terminada");
            }

        }
    }
    public class USP_OBTIENE_DETALLE_OSA_REABRIR_Result
    {
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public decimal OSASSECU { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASALMA { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal OSASCAEN { get; set; }
        public System.DateTime OSASFEAT { get; set; }
        public string OSASREEN { get; set; }
        public decimal OSASCCOS { get; set; }
        public string OSASDUEÑ { get; set; }
        public string OSASSTOS { get; set; }
        public decimal OSASUNID { get; set; }
        public string OSASFILL { get; set; }
        public string OSASFORZ { get; set; }
        public string OSASSTAT { get; set; }
        public decimal DEOSIDDO { get; set; }
        public decimal DEOSIDCO { get; set; }
        public decimal DEOSPEAT { get; set; }
        public decimal DEOSCAAT { get; set; }
        public decimal DEOSPERE { get; set; }
        public Nullable<decimal> DEOSSTOC { get; set; }
        public decimal DEOSESPA { get; set; }
        public decimal DEOSPEOR { get; set; }
        public decimal DEOSCAOR { get; set; }
        public decimal DEOSESTA { get; set; }
        public decimal DEOSSECR { get; set; }

    }
    public  class USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result
    {
        public Nullable<long> OSAROW { get; set; }
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public Nullable<System.DateTime> PARTFEEF { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal CAOSIDCO { get; set; }
        public decimal CAOSPRIO { get; set; }
        public decimal CAOSIDES { get; set; }
        public string CAOSUSPR { get; set; }
        public string CAOSNOTA { get; set; }
        public string CAOSESTA
        {
            get
            {
                return CAOSIDES.ToString().Replace("0", "").Replace("1", "Creado").Replace("2", "Emitido").Replace("3", "En preparación").Replace("4", "Parcial").Replace("5", "Completada").Replace("6", "Parcial").Replace("7", "Terminado");
            }

        }

    }
    public  class USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result
    {
        public decimal OSASCIA { get; set; }
        public string OSASFOLI { get; set; }
        public decimal OSASSECU { get; set; }
        public string OSASARTI { get; set; }
        public string OSASPAOR { get; set; }
        public decimal OSASALMA { get; set; }
        public decimal OSASCASO { get; set; }
        public string OSASPADE { get; set; }
        public System.DateTime OSASFEEM { get; set; }
        public string OSASRESP { get; set; }
        public decimal OSASCAEN { get; set; }
        public System.DateTime OSASFEAT { get; set; }
        public string OSASREEN { get; set; }
        public decimal OSASCCOS { get; set; }
        public string OSASDUEÑ { get; set; }
        public string OSASSTOS { get; set; }
        public decimal OSASUNID { get; set; }
        public string OSASFILL { get; set; }
        public string OSASFORZ { get; set; }
        public string OSASSTAT { get; set; }
        public decimal DEOSIDDO { get; set; }
        public decimal DEOSIDCO { get; set; }
        public decimal DEOSPEAT { get; set; }
        public decimal DEOSCAAT { get; set; }
        public decimal DEOSPERE { get; set; }
        public Nullable<decimal> DEOSSTOC { get; set; }
        public decimal DEOSESPA { get; set; }
        public decimal DEOSPEOR { get; set; }
        public decimal DEOSCAOR { get; set; }
        public decimal DEOSESTA { get; set; }
        public decimal DEOSSECR { get; set; }
    }

    public class USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result
    {
        public Nullable<decimal> DEOSIDDO { get; set; }
        public Nullable<decimal> BOLSIDBO { get; set; }
        public string BOLSCOEM { get; set; }
        public string BOLSCOCA { get; set; }
        public string BOLSARTI { get; set; }
        public string BOLSPART { get; set; }
        public Nullable<decimal> BOLSALMA { get; set; }
        public Nullable<decimal> BOLSCANT { get; set; }
        public Nullable<decimal> BOLSPESO { get; set; }
        public decimal BODPIDDE { get; set; }
        public Nullable<decimal> BODPIDBO { get; set; }
        public Nullable<decimal> BODPIDDO { get; set; }
        public decimal BODPCANT { get; set; }
        public decimal BODPPESO { get; set; }
        public Nullable<decimal> TIEMTARA { get; set; }
        public Nullable<decimal> UNIDTARA { get; set; }
        public decimal BODPPERE { get; set; }
        public decimal BODPSTCE { get; set; }
        public decimal BODPINBO { get; set; }
        public decimal BODPTADE { get; set; }
        public decimal BODPPEBR { get; set; }
        public decimal BODPDIFE { get; set; }
        public decimal BODPESTA { get; set; }
        public decimal BODPSECR { get; set; }
        public decimal BODPTAUN { get; set; }
    }

    public class PRTMXR
    {
        public decimal TMXRSECU { get; set; }
        public string TMXRMAQU { get; set; }
        public string MAQUMAQU { get; set; }
    }

}

