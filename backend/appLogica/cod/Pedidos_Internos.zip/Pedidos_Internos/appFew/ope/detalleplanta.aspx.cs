﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using appConstantes;
using System.Data;
using appFew.appServicio;
using appWcfService;
using System.Threading.Tasks;

namespace appFew.ope
{
    public partial class detalleplanta : System.Web.UI.Page
    {
        #region Variables
        private static ParametrosFe _ParametrosIni;
        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;
        List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> listaosas = new List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
        #endregion

        #region Eventos
        protected void Page_Load(object sender, EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];

            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {
                try
                {
                    if (!Page.IsPostBack)
                    {
                        if (Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION] != null)
                        {
                            listaosas = (List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>)Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION];
                            if (listaosas.Count > 0)
                            {
                                CargaDetalleOsas(listaosas);
                            }
                            //Session.Remove(Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void DetallesosaGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void DetallesosaGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(DetallesosaGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void confirmarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                if (DetalleOsaPendiente[0].OSASSECU != -1)
                {
                    mensajelabel.Text = "¿Está seguro que desea Confirmar?";
                    mensajemodal.Show();
                }
                else
                {
                    MostrarMensaje("No es posible confirmar esta OSA, No tiene un detalle válido");
                }
            }
            catch (Exception ex)
            {

                MostrarMensaje(ex.Message);
            }
        }

        protected void maceptarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                if (DetalleOsaPendiente.Count > 0 && DetalleOsaPendiente[0].OSASSECU != -1)
                {
                    ApruebaOsasPlanta(DetalleOsaPendiente);
                    Response.Redirect("../ope/recepcion.aspx");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        private void espera()
        {
            System.Threading.Thread.Sleep(6000);
            string mensaje = "hola";
            ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + mensaje.Replace(" < br > ", " - ") + "');window.location ='../ope/recepcion.aspx';", true);
            //Response.Redirect("../ope/recepcion.aspx");
        }
        protected void mcancelarbutton_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Metodos
        private void CargaDetalleOsas(List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> Listafolios)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA_PLANTA_LISTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(Listafolios));

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>>(resultado.VALSAL[1]);
                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }
                }
                else
                {
                    SetDataSourceDetalle(null);
                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
            }

            DetalleOsaPendiente = _listaAsignacion;
            DetallesosaGridView.DataSource = DetalleOsaPendiente;
            DetallesosaGridView.DataBind();
        }
        private List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_PLANTA_Result() { OSASSECU = -1 });
            return datos;
        }

        private List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_PLANTA] as List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_PLANTA] = value;
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }
        private void ApruebaOsasPlanta(List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> ListaOsas)
        {
            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.APRUEBA_OSAS_PLANTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(ListaOsas));
                parEnt.Add(_ParametrosIni.Usuario);


                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "$alert('Se ha confirmado satisfactoriamente.');window.location ='../ope/recepcion.aspx';", true);
                }
                else
                {
                    ScriptManager.RegisterStartupScript(this, this.GetType(), "alert", "alert('" + resultado.MENERR.Replace(" < br > ", " - ") + "');window.location ='../ope/recepcion.aspx';", true);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        #endregion

    }
}