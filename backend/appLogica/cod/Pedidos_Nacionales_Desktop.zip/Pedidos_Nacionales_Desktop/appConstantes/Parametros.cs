﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace appConstantes
{
    public class Parametros
    {
        public const string ULTIMA_FECHA_GENERACION_CARGA = "PULGEC";
    }
}
