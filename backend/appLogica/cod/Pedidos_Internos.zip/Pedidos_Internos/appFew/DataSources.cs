﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

using appWcfService;

namespace appFew
{
    public class DSFromDTO
    {
        public List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result> GetDSREQMAT()
        {
            return new List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result>();
        }

        public List<PRASIG> GetDSPRASIG()
        {
            return new List<PRASIG>();
        }

        public List<PRPAOB> GetDSPRPAOB()
        {
            return new List<PRPAOB>();
        }

        public List<PRPART> GetDSPRPART()
        {
            return new List<PRPART>();
        }
        public List<PRTMXR> GetPRTMXR()
        {
            return new List<PRTMXR>();
        }
    }
}