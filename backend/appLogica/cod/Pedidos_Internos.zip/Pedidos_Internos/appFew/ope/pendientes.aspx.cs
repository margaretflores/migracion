﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

using appConstantes;
using System.Data;
using appFew.appServicio;
using appWcfService;

namespace appFew.ope
{
    public partial class pendientes : System.Web.UI.Page
    {
        #region Variables
        private static ParametrosFe _ParametrosIni;
        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;
        USP_OBTIENE_OSAS_PENDIENTES_Result Selectedrow = new USP_OBTIENE_OSAS_PENDIENTES_Result(); //Guarda el item seleccionado
        decimal idosa;
        #endregion

        #region Eventos
        protected void Page_Load(object sender, EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];
            MaintainScrollPositionOnPostBack = true;
            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {

                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();
                    if (!Page.IsPostBack)
                    {
                        Listosas = null;
                        string folio = HttpContext.Current.Session[Constantes.FOLIO_SELECCIONADO] as string;
                        if (folio == null)
                        {
                            CargaDatosIniciales();
                        }
                        else
                        {
                            CargaFoliosUsuario();
                            tipfolDropDownList.SelectedValue = folio;
                            BuscaOsasPartida();
                        }
                        VerificaAccesoSoloLectura();
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void tipfolDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SetDataSourceDetalle(null);
                PartidabaseTextBox.Text = "";
                BuscaOsasPartida();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void seleccionarButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (Listosas.Count > 0)
                {
                    GridViewRow row = pendientesGridView.SelectedRow;
                    if (row != null)
                    {
                        string corrLiq = row.Cells[0].Text;
                        //LENAR TABPAGES
                        List<USP_OBTIENE_OSAS_PENDIENTES_Result> detConsumo = OsasPendientesBusqueda;

                        if (detConsumo != null && detConsumo[0].OSAROW != -1)
                        {
                            Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                            switch (Selectedrow.CAOSIDES.ToString())
                            {
                                case "3":
                                    mensajelabel.Text = "¿Desea continuar con la preparación de esta OSA?";
                                    break;
                                //case "4":
                                //    break;
                                default:
                                    mensajelabel.Text = "¿Desea Atender esta OSA?";
                                    break;
                            }
                            mensajemodal.Show();
                        }
                    }
                }
                else
                {
                    mensajelabel.Text = "Debe selecionar al menos una OSA.";
                    mensajemodal.Show();


                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }


        private bool genera_pedido(PECAOS objpecaos)
        {
            IappServiceClient clt = null;
            bool result = false;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_PEDIDO_INTERNO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(objpecaos));
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0] != "0")
                    {
                        idosa = Decimal.Parse(resultado.VALSAL[0]);
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    result = false;
                }
                result = resultado.ESTOPE;

                return result;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return result;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        protected void ActualizarButton_Click(object sender, EventArgs e)
        {
            SetDataSourceDetalle(null);
            Listosas = null;
            BuscaOsasPartida();
        }

        //Grillas
        protected void pendientesGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void pendientesGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (pendientesGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = pendientesGridView.Rows[pendientesGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = pendientesGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pendientesGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {

                GridViewRow row = pendientesGridView.SelectedRow;
                List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> listseleccionadas = new List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>();
                listseleccionadas = Listosas;
                if (row != null)
                {
                    string corrLiq = row.Cells[0].Text;
                    //LENAR TABPAGES
                    List<USP_OBTIENE_OSAS_PENDIENTES_Result> detConsumo = OsasPendientesBusqueda;

                    if (detConsumo != null && detConsumo[0].OSAROW != -1)
                    {
                        Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                        CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                        if (chkRow.Checked)
                        {
                            if (!listseleccionadas.Contains(Selectedrow))
                            {
                                listseleccionadas.Add(Selectedrow);
                            }
                            Listosas = listseleccionadas;
                            eliminaDetalle = "1";
                            MuestraDetalleOsa();
                        }
                        else
                        {
                            listseleccionadas.Remove(Selectedrow);
                            Listosas = listseleccionadas;
                            eliminaDetalle = null;
                            MuestraDetalleOsaRemove(listseleccionadas);
                        }


                    }
                }

            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pendientesGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(pendientesGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[7].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[2].Text = ConsumosExamen.Sum(x => x.MOVMCANT).ToString(Constantes.FORMATO_IMPORTE);
            //    e.Row.Cells[3].Text = ConsumosExamen.Sum(x => x.PORCENTAJE).ToString(Constantes.FORMATO_DECIMAL_0 + "1");
            //}
        }

        protected void detalleGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");





            }
        }

        protected void detalleGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            String PartBase = "";
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(detalleGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                }
                PartBase = Convert.ToString(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "PARTSTPR"));

                if (PartBase.Equals("T") || PartBase.Equals("R"))
                {
                    e.Row.BackColor = System.Drawing.Color.LightGreen;
                }
                if (PartBase.Equals("A") || PartBase.Equals("C") || PartBase.Equals("S"))
                {
                    e.Row.BackColor = System.Drawing.Color.Khaki;
                }
                if (PartBase.Equals("G") || PartBase.Equals("E") || PartBase.Equals("F"))
                {
                    e.Row.BackColor = System.Drawing.Color.Tomato;
                }


            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void buscaButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (buscarTextBox.Text.Trim().ToString() != "")
                {
                    SetDataSourceDetalle(null);
                    Listosas = null;
                    buscarosa(tipfolDropDownList.SelectedValue, buscarTextBox.Text.Trim(), PartidabaseTextBox.Text.Trim());
                }
                else
                {
                    SetDataSourceDetalle(null);
                    Listosas = null;
                    BuscaOsasPartida();
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        //Ventana Modal
        protected void maceptarbutton_Click(object sender, EventArgs e)
        {
            if (Listosas.Count > 0)
            {
                foreach (var item in Listosas)
                {
                    PECAOS osa = new PECAOS();
                    osa.CAOSIDCO = item.CAOSIDCO;
                    osa.CAOSUSCR = item.OSASRESP;
                    osa.CAOSFOLI = item.OSASFOLI;
                    osa.CAOSPRIO = item.OSAROW;
                    osa.CAOSEPRI = item.CAOSPRIO;
                    if (item.CAOSIDES != 4)
                    {
                        osa.CAOSIDES = 3;
                        genera_pedido(osa);
                    }
                    //else
                    //{
                    //    osa.CAOSIDES = 4;
                    //}
                    //cambia estado

                    if (idosa != 0)
                    {
                        item.CAOSIDCO = osa.CAOSIDCO;
                    }
                }
                Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA] = Listosas;
                Session[Constantes.FOLIO_SELECCIONADO] = tipfolDropDownList.SelectedValue;
                Response.Redirect("../ope/atenderosa.aspx");
            }

        }

        protected void mcancelarbutton_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Metodos

        private void CargaDatosIniciales()
        {
            InicializaDatos();
            CargaFoliosUsuario();
            BuscaOsasPartida();
        }

        private void InicializaDatos()
        {
            //consumos
            SetDataSourceBusquedaOsas(null);

            //asignacion
            SetDataSourceDetalle(null);
        }

        public void CargaFoliosUsuario()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_TIPOS_FOLIO_USUARIO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(_ParametrosIni.Usuario);
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        var firstitem = tipfolDropDownList.Items[0];
                        tipfolDropDownList.Items.Clear();
                        tipfolDropDownList.Items.Add(firstitem);

                        List<PEUSTF> datos = Funciones.Deserialize<List<PEUSTF>>(resultado.VALSAL[1]);
                        foreach (PEUSTF item in datos)
                        {
                            tipfolDropDownList.Items.Add(new ListItem(item.PETIFO.TIFODESC, item.PETIFO.TIFOCOFO.ToString()));
                        }
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        public void VerificaAccesoSoloLectura()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.VALIDA_ACCESO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(_ParametrosIni.Usuario);
                parEnt.Add(CodigoOperacion.ACCESO_OSAS_PENDIENTES_SOLO_LECTURA.ToString());
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        seleccionarButton.Enabled = false;
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        //private void SetDataSourceOsas(List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> _listaConsumos)
        //{
        //    bool limpiaDet = false;
        //    if (_listaConsumos == null)
        //    {
        //        _listaConsumos = ObtienePendientesDefault();
        //        limpiaDet = true;
        //    }

        //    OsasPendientes = _listaConsumos;
        //    pendientesGridView.DataSource = OsasPendientes;
        //    pendientesGridView.DataBind();
        //    if (pendientesGridView.SelectedIndex == -1 || limpiaDet)
        //    {
        //        SetDataSourceDetalle(null);
        //    }
        //}

        //private void CargaOsasEmitidas()
        //{
        //    IappServiceClient clt = null;

        //    try
        //    {
        //        if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
        //        {
        //            SetDataSourceBusquedaOsas(null);

        //            return;
        //        }
        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.MUESTRA_OSAS_PENDIENTES_WEB;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {
        //            if (resultado.VALSAL[0].Equals("1")) //encontrado
        //            {
        //                List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result>>(resultado.VALSAL[1]);

        //                SetDataSourceOsas(datos);
        //            }
        //            else
        //            {
        //                SetDataSourceOsas(null);
        //            }

        //        }
        //        else
        //        {
        //            SetDataSourceOsas(null);

        //            MostrarMensaje(resultado.MENERR);
        //            //ErrorLabel.Font.Bold = true;
        //            //ErrorLabel.Text = resultado.MENERR;
        //        }
        //        //EstadoFinalBotonesNavegacionConsumo();
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}

        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_Result> _listaAsignacion)
        {
            List<USP_OBTIENE_DETALLE_OSA_Result> Detalles;
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
                DetalleOsaPendiente = _listaAsignacion;
            }
            else
            {
                if (Listosas.Count > 1 && eliminaDetalle != null)
                {
                    Detalles = DetalleOsaPendiente;
                    if (Detalles.FirstOrDefault(x => x.OSASFOLI == _listaAsignacion[0].OSASFOLI) == null)
                    {
                        Detalles.AddRange(_listaAsignacion);
                        DetalleOsaPendiente = Detalles;
                    }
                }
                else
                {
                    DetalleOsaPendiente = _listaAsignacion;
                }
            }
            detalleGridView.DataSource = DetalleOsaPendiente;
            detalleGridView.DataBind();

        }

        private void MuestraDetalleOsa()
        {
            //Obtiene el item selecconado y llama el metodo para mostrar el detalle del item
            GridViewRow row = pendientesGridView.SelectedRow;

            if (row != null)
            {
                string corrLiq = row.Cells[0].Text;
                //LENAR TABPAGES
                List<USP_OBTIENE_OSAS_PENDIENTES_Result> detConsumo = OsasPendientesBusqueda;

                if (detConsumo != null && detConsumo[0].OSAROW != -1)
                {
                    Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                    CargaDetalleOsa(Selectedrow.OSASFOLI.ToString());
                    //posOsaTextBox.Text = consumo.OSAROW.ToString();
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }
        private void MuestraDetalleOsaRemove(List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> remove)
        {
            SetDataSourceDetalle(null);
            foreach (var item in remove)
            {
                CargaDetalleOsa(item.OSASFOLI.ToString());
                eliminaDetalle = "1";
            }
        }

        private void CargaDetalleOsa(string folio)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }

        //Default
        //private List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> ObtienePendientesDefault()
        //{
        //    List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result>();
        //    datos.Add(new USP_OBTIENE_OSAS_PENDIENTES_WEB_Result() { OSAROW = -1 });
        //    return datos;
        //}

        private List<USP_OBTIENE_DETALLE_OSA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_Result() { OSASSECU = -1 });
            return datos;
        }

        //private List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> OsasPendientes
        //{
        //    get
        //    {
        //        List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_PENDIENTES] as List<USP_OBTIENE_OSAS_PENDIENTES_WEB_Result>;
        //        if (dt == null)
        //        {
        //            // Crear un DataTable y guarda la sesion
        //            dt = ObtienePendientesDefault();

        //            OsasPendientes = dt;
        //        }
        //        return dt;
        //    }
        //    set
        //    {
        //        HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_PENDIENTES] = value;
        //    }
        //}

        private List<USP_OBTIENE_DETALLE_OSA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_DETALLE_OSA_PENDIENTES] as List<USP_OBTIENE_DETALLE_OSA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_DETALLE_OSA_PENDIENTES] = value;
            }
        }

        private string eliminaDetalle
        {
            get
            {
                string dt = HttpContext.Current.Session[Constantes.MULTIPLE_DETALLE] as string;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = null;

                    eliminaDetalle = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.MULTIPLE_DETALLE] = value;
            }
        }

        private void buscarosa(string folio, string busqueda, string partida)
        {

            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.BUSQUEDA_OSAS;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);
                parEnt.Add(busqueda);
                parEnt.Add(partida);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_BUSCA_OSAS_PENDIENTES_Result> listabusqueda = Funciones.Deserialize<List<USP_BUSCA_OSAS_PENDIENTES_Result>>(resultado.VALSAL[1]);
                        List<USP_OBTIENE_OSAS_PENDIENTES_Result> listdatos = new List<USP_OBTIENE_OSAS_PENDIENTES_Result>();
                        foreach (var item in listabusqueda)
                        {
                            USP_OBTIENE_OSAS_PENDIENTES_Result obj = new USP_OBTIENE_OSAS_PENDIENTES_Result();
                            obj.OSAROW = item.OSAROW;
                            obj.OSASCIA = item.OSASCIA;
                            obj.OSASFOLI = item.OSASFOLI;
                            obj.PARTFEEF = item.PARTFEEF;
                            obj.OSASFEEM = item.OSASFEEM;
                            obj.OSASRESP = item.OSASRESP;
                            obj.CAOSIDCO = item.CAOSIDCO;
                            obj.CAOSPRIO = item.CAOSPRIO;
                            obj.CAOSIDES = item.CAOSIDES;

                            listdatos.Add(obj);
                        }

                        SetDataSourceBusquedaOsas(listdatos);
                    }
                    else
                    {
                        SetDataSourceBusquedaOsas(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        #endregion


        private void BuscaOsasPartida()
        {
            IappServiceClient clt = null;

            try
            {
                if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
                {
                    SetDataSourceBusquedaOsas(null);

                    return;
                }
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_BUSCA_OSAS_PENDIENTES;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado
                parEnt.Add(PartidabaseTextBox.Text);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_OSAS_PENDIENTES_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_OSAS_PENDIENTES_Result>>(resultado.VALSAL[1]);

                        SetDataSourceBusquedaOsas(datos);
                    }
                    else
                    {
                        SetDataSourceBusquedaOsas(null);
                    }

                }
                else
                {
                    SetDataSourceBusquedaOsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionConsumo();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceBusquedaOsas(List<USP_OBTIENE_OSAS_PENDIENTES_Result> _listaConsumos)
        {
            bool limpiaDet = false;
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtieneBusquedaDefault();
                limpiaDet = true;
            }

            OsasPendientesBusqueda = _listaConsumos;
            pendientesGridView.DataSource = OsasPendientesBusqueda;
            pendientesGridView.DataBind();
            if (pendientesGridView.SelectedIndex == -1 || limpiaDet)
            {
                SetDataSourceDetalle(null);
            }
        }
        private List<USP_OBTIENE_OSAS_PENDIENTES_Result> ObtieneBusquedaDefault()
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_Result>();
            datos.Add(new USP_OBTIENE_OSAS_PENDIENTES_Result() { OSAROW = -1 });
            return datos;
        }

        private List<USP_OBTIENE_OSAS_PENDIENTES_Result> OsasPendientesBusqueda
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_PENDIENTES_BUSQUEDA] as List<USP_OBTIENE_OSAS_PENDIENTES_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneBusquedaDefault();

                    OsasPendientesBusqueda = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSA_PENDIENTES_BUSQUEDA] = value;
            }
        }

        private List<USP_OBTIENE_OSAS_PENDIENTES_Result> Listosas
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_Result> dt = HttpContext.Current.Session[Constantes.LISTA_OSA_PENDIENTES] as List<USP_OBTIENE_OSAS_PENDIENTES_Result>;
                if (dt == null)
                {
                    List<USP_OBTIENE_OSAS_PENDIENTES_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_Result>();
                    dt = datos;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.LISTA_OSA_PENDIENTES] = value;
            }
        }

    }
}