﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Configuration;
using System.Data;

using appWcfService;
using appConstantes;
using System.IO;

namespace appLanzador
{
    public class Principal
    {

        public Principal()
        {

        }

      
        public RESOPE EjecutaOperacion(PAROPE paramOperacion)
        {
            appLogica.MKT _spn;
            appLogica.Principal _principal;
            //
            appLogica.appDB2 _appDB2;
            _appDB2 = null;

            RESOPE vpar;

            _spn = null;
            vpar = new RESOPE();
            vpar.ESTOPE = false;
            try
            {
                switch (paramOperacion.CODOPE)
                {
                    case CodigoOperacion.VALIDA_USUARIO:
                        _principal = new appLogica.Principal();
                        vpar = _principal.ValidaUsuario(paramOperacion);
                        break;
                    case CodigoOperacion.CAMBIAR_PASSWORD:
                        _principal = new appLogica.Principal();
                        vpar = _principal.CambiaClave(paramOperacion);
                        break;
                        //
                    case CodigoOperacion.TRACKING_PEDIDOS:
                        _spn = new appLogica.MKT();
                        vpar = _spn.TrackingPedidos(paramOperacion);
                        break;
                    case CodigoOperacion.CARGA_FOLIO:
                        _spn = new appLogica.MKT();
                        vpar = _spn.CargaFolio(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_OSAS_PENDIENTES:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientes(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsa(paramOperacion);
                        break;
                    case CodigoOperacion.GENERA_PEDIDO_INTERNO:
                        _spn = new appLogica.MKT();
                        vpar = _spn.GeneraPedidoInterno(paramOperacion);
                        break;
                    case CodigoOperacion.ACTUALIZA_DETOSA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ActualizaDetOsa(paramOperacion);
                        break;
                    case CodigoOperacion.OBTIENE_PREPARACIONOSA:
                        _spn = new appLogica.MKT();
                        //vpar = _spn.ObtienePreparacionOsa(paramOperacion);
                        vpar = _spn.ObtienePreparacionOsase(paramOperacion);
                        break;
                    case CodigoOperacion.OBTIENE_BOLSA_OSA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ObtieneBolsaOsa(paramOperacion);
                        break;
                    case CodigoOperacion.BUSQUEDA_OSAS:
                        _spn = new appLogica.MKT();
                        vpar = _spn.BusquedaOsas(paramOperacion);
                        break;
                    case CodigoOperacion.OBTIENE_OSAS_EMITIDAS_PRIORIZAR:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientesPrioriza(paramOperacion);
                        break;
                    case CodigoOperacion.OBTIENE_TIPOS_FOLIO_USUARIO:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ObtieneFoliosUsuario(paramOperacion);
                        break;
                    case CodigoOperacion.GUARDA_PRIORIDAD:
                        _spn = new appLogica.MKT();
                        vpar = _spn.GuardaPrioridad(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_OSAS_PENDIENTES_WEB:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientesweb(paramOperacion);
                        break;
                    case CodigoOperacion.MOSTRAR_UBICACION:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraUbicacionesArticulo(paramOperacion);
                        break;
                    case CodigoOperacion.GUARDA_BOLSA:
                        _spn = new appLogica.MKT();
                        //vpar = _spn.guardaPreparacionBolsa(paramOperacion);
                        vpar = _spn.guardaPreparacionBolsase(paramOperacion);
                        break;
                    case CodigoOperacion.ELIMINA_BOLSA:
                        _spn = new appLogica.MKT();
                        //vpar = _spn.remueveBolsaPedido(paramOperacion);
                        vpar = _spn.remueveBolsaPedidose(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_OSAS_PENDIENTES_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientesPlanta(paramOperacion);
                        break;
                    case CodigoOperacion.CAMBIA_ESTADO_DEOS:
                        _spn = new appLogica.MKT();
                        vpar = _spn.Cambiaestadeos(paramOperacion);
                        break;
                    case CodigoOperacion.GENERA_ORDEN_TRABAJO:
                        _appDB2 = new appLogica.appDB2();
                        vpar = _appDB2.GeneraOrdenTrabajo(paramOperacion);
                        //if (vpar.ESTOPE)
                        //{
                        //    _spn = new appLogica.MKT();
                        //    vpar.VALSAL.Add(_spn.Cambiaestadeos(paramOperacion));
                        //}
                        break;
                    case CodigoOperacion.CAMBIA_ESTADO_BODP:
                        _spn = new appLogica.MKT();
                        vpar = _spn.cambiaestadoBodp(paramOperacion);
                        break;
                    case CodigoOperacion.BUSCA_OSAS_PENDIENTES_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.BusquedaOsasPlanta(paramOperacion);
                        break;
                    case CodigoOperacion.GUARDA_ORIGEN:
                        _spn = new appLogica.MKT();
                        vpar = _spn.GuardaOrigin(paramOperacion);
                        break;
                    case CodigoOperacion.REABRE_OSA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ReabreOsa(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSA_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsaPlanta(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSA_PLANTA_LISTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsaPlantaList(paramOperacion);
                        break;
                    case CodigoOperacion.APRUEBA_OSAS_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ApruebaOsasPlanta(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_BUSCA_OSAS_PENDIENTES:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestrayBuscaOsasPendientes(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSA_LIST:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsaList(paramOperacion);
                        break;
                    case CodigoOperacion.CAMBIA_ESTADO_DEOS_BODP:
                        _spn = new appLogica.MKT();
                        vpar = _spn.cambiaestaDeosBodp(paramOperacion);
                        break;

                    case CodigoOperacion.MUESTRA_OSAS_REABRIR_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientesReabrir(paramOperacion);
                        break;
                    case CodigoOperacion.BUSCA_OSAS_REABRIR_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.BusquedaOsasReabrir(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_OSAS_PENDIENTES_IMPRIMIR:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraOsasPendientesImprimir(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSAS_IMPRIMIR:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsaPlantaImprimir(paramOperacion);
                        break;
                    case CodigoOperacion.MUESTRA_DETALLE_OSA_REABRIR:
                        _spn = new appLogica.MKT();
                        vpar = _spn.MuestraDetalleOsaReabrir(paramOperacion);
                        break;
                    case CodigoOperacion.EXTORNA_OSA_PLANTA:
                        _spn = new appLogica.MKT();
                        vpar = _spn.ExtornarOsasPlanta(paramOperacion);
                        break;
                    case CodigoOperacion.GENERA_DEVOLUCION_MATERIAL:
                        _spn = new appLogica.MKT();
                        vpar = _spn.generaDevolucionBolsa(paramOperacion);
                        break;
                    case CodigoOperacion.VALIDA_ACCESO:
                        _appDB2 = new appLogica.appDB2();
                        vpar = _appDB2.ValidaAcceso(paramOperacion);
                        break;
                    default:
                        vpar.MENERR = "OPERACION NO DEFINIDA";
                        break;
                }
        

    }
            catch (Exception ex)
            {
                vpar.MENERR = ex.Message;
                Util.EscribeLog(ex.Message);
                //throw ex;
            }
            finally
            {
                if (_spn != null)
                {
                    _spn.Finaliza();
                    _spn = null;
                }
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }

            return vpar;

        }

    }
}
