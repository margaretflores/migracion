﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using System.Configuration;
using System.Data;
using IBM.Data.DB2.iSeries;

using appWcfService;
//using AccesoDatos;
using appConstantes;
using System.Reflection;
using System.Text.RegularExpressions;
using System.IO;
using EFModelo;
using System.Data.Entity.Validation;
using System.Diagnostics;

namespace appLogica
{
    public class MKT
    {
        //internal BaseDatos DB2;

        #region variables
        //correo
        private string ServidorSMTP, CuentaDe, CuentaDescripcion, ClaveCuenta, DominioCuenta, PuertoSMTP;

        private bool OcultaErrorReal;
        private string Aplicacion;
        private string DataSourceDB2;

        public static string NombreCLDescargaInventario = "GMA003PP"; //GMA003P 20151130 PRUEBAS USUARIO //GMA003PP produccion

        #endregion

        #region constantes

        private const decimal TIPO_MOV_SALIDA_PREP_PED = 1; //-
        private const decimal TIPO_MOV_CANCELA_SALIDA_PREP_PED = 2; //+
        private const decimal TIPO_MOV_MODIFICA_SALIDA_PREP_PED = 3;  //+
        private const decimal TIPO_MOV_DEVOLUCION_MATERIAL = 4; //+

        #endregion

        public MKT()
        {
            string stringConnection, userId, userPassword;
            DataSourceDB2 = ConfigurationManager.AppSettings["DataSource"];
            Aplicacion = ConfigurationManager.AppSettings["Aplicacion"];

            userId = "PCS400";
            userPassword = "pcs400";
            stringConnection = "DataSource=" + DataSourceDB2 + ";User Id=" + userId + ";Password=" + userPassword + ";Naming=System;LibraryList=QS36F,INCAOBJ,PRODDAT,MANTDAT;CheckConnectionOnOpen=true;";
            //DB2 = new BaseDatos(stringConnection);

            ServidorSMTP = ConfigurationManager.AppSettings["Smtp"];
            CuentaDe = ConfigurationManager.AppSettings["DeSmtp"];
            CuentaDescripcion = ConfigurationManager.AppSettings["NombreSmtp"];
            ClaveCuenta = ConfigurationManager.AppSettings["ClaveSmtp"];
            DominioCuenta = ConfigurationManager.AppSettings["DominioSmtp"];
            PuertoSMTP = ConfigurationManager.AppSettings["PuertoSmtp"];


            if (ConfigurationManager.AppSettings["OcultaErrorReal"].Equals("1"))
            {
                OcultaErrorReal = true;
            }
            else
            {
                OcultaErrorReal = false;
            }
        }

        //RESOPES
        public RESOPE TrackingPedidos(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.PECAPE> lista = null;
            string serie;
            decimal numped;
            try
            {
                serie = paramOperacion.VALENT[0];
                numped = decimal.Parse(paramOperacion.VALENT[1]);

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.PECAPE.Include("TCLIE").Where(ped => ped.CAPESERI.Equals(serie) && ped.CAPENUME == numped).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.PECAPE>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE CargaFolio(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.PETIFO> lista = null;
            try
            {
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.PETIFO.ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.PETIFO>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientes(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            try
            {
                folio = paramOperacion.VALENT[0];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES(folio, "").ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientesweb(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_WEB_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            try
            {
                folio = paramOperacion.VALENT[0];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES_WEB(folio).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_WEB_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraDetalleOsa(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> lista = null;
            string folio; //envia folio completo
            try
            {
                folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETALLE_OSA(folio).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraDetalleOsaList(PAROPE paramOperacion)
        {
            //Recibe una lista
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<object> listaeo2 = new List<object>();

            List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> lista = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> ListaOsas = new List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>();
            try
            {
                ListaOsas = Util.Deserialize<List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>>(paramOperacion.VALENT[0]);
                foreach (var item in ListaOsas)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        listaeo = context.USP_OBTIENE_DETALLE_OSA(item.OSASFOLI).ToList<object>();
                    }
                    if (listaeo.Count > 0)
                    {
                        listaeo2.AddRange(listaeo);
                    }
                }

                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>(listaeo2);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE GeneraPedidoInterno(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            appWcfService.PECAOS objpecaos;

            bool nuevoregistro = false;
            string resultado = "";
            string idco = "";
            string usuario;
            try
            {
                objpecaos = Utils.Deserialize<appWcfService.PECAOS>(paramOperacion.VALENT[0]);
                usuario = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    var ent = context.PECAOS.Find(Convert.ToDecimal(objpecaos.CAOSIDCO));
                    if (ent == null)
                    {
                        ent = new EFModelo.PECAOS();
                        ent.CAOSFOLI = objpecaos.CAOSFOLI;
                        ent.CAOSPRIO = 0;
                        ent.CAOSFECR = DateTime.Now;
                        ent.CAOSUSCR = objpecaos.CAOSUSCR;
                        context.PECAOS.Add(ent);
                        nuevoregistro = true;
                    }
                    else
                    {
                        if (ent.CAOSFOLI.Trim() != objpecaos.CAOSFOLI.Trim())
                        {
                            throw new Exception("Folio no válido");
                        }
                        ent.CAOSFEMO = DateTime.Now;
                        ent.CAOSUSMO = usuario;
                    }
                    //ent.CAOSIDES = estadopedint.CAOSIDES;
                    ent.CAOSIDES = objpecaos.CAOSIDES; //probar para la transacción
                    if (objpecaos.CAOSIDES == 5 || objpecaos.CAOSIDES == 4) // se completo todas los detalles de ese folio
                    {
                        ent.CAOSFHFP = DateTime.Now;
                        ent.CAOSUSFP = usuario;
                        ent.CAOSNOTA = objpecaos.CAOSNOTA;
                    }
                    if (ent.CAOSIDES == 3)
                    {
                        ent.CAOSFHIP = DateTime.Now;
                        ent.CAOSUSIP = usuario;
                    }
                    context.SaveChanges();
                    //actualiza estado OSA en SQL --falta actualizar estado OSA en AS
                    if (nuevoregistro)
                    {
                        idco = ent.CAOSIDCO.ToString();
                    }
                    var osas = context.PROSAS.Where(ped => ped.OSASCIA == 1 && ped.OSASFOLI == objpecaos.CAOSFOLI).ToList();
                    if (osas != null)
                    {
                        foreach (var osa in osas)
                        {
                            var detped = context.PEDEOS.FirstOrDefault(det => det.DEOSFOLI == osa.OSASFOLI && det.DEOSSECU == osa.OSASSECU);
                            if (detped == null)
                            {
                                //si llegaran a agregar lineas despues de emitida no funcionaría, peor si eliminan
                                detped = new EFModelo.PEDEOS();
                                detped.DEOSIDCO = ent.CAOSIDCO;
                                detped.DEOSSECU = osa.OSASSECU;
                                detped.DEOSFOLI = osa.OSASFOLI;
                                detped.DEOSPEAT = 0;
                                detped.DEOSCAAT = 0;
                                detped.DEOSPERE = 0;
                                detped.DEOSSTOC = 0;
                                detped.DEOSESTA = 1; //CREADO //NO SE USA POR AHORA
                                detped.DEOSFECR = DateTime.Now;
                                detped.DEOSUSCR = objpecaos.CAOSUSCR;
                                context.PEDEOS.Add(detped);
                            }
                            if (detped.DEOSCOAR != osa.OSASARTI || detped.DEOSPART != osa.OSASPAOR || detped.DEOSALMA != osa.OSASALMA || detped.DEOSPESO != osa.OSASCASO)
                            {
                                detped.DEOSFEMO = DateTime.Now;
                                detped.DEOSUSMO = usuario;
                            }
                            detped.DEOSCOAR = osa.OSASARTI;
                            detped.DEOSPART = osa.OSASPAOR;
                            detped.DEOSALMA = osa.OSASALMA;
                            detped.DEOSPESO = osa.OSASCASO;

                            if (objpecaos.CAOSIDES == 3)  //3   En preparación                               
                            {
                                //actualizar al guardar bolsa preparada o al trabajar item?
                                //if (osa.OSASSTOS.Equals("E") || (osa.OSASSTOS.Equals("C")))
                                //{
                                //    osa.OSASSTOS = "S";
                                //    //actualizar estado PENDIENTE AS
                                // actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, -1, osa.OSASSTOS); //Validar
                                //}
                            }
                            else if (objpecaos.CAOSIDES == 4 || objpecaos.CAOSIDES == 5)  //4 existen detalles sin atender o 5 preparación de todos los detalles finalizada
                            {
                                //20180713
                                //if (osa.OSASCASO > 0 && (detped.DEOSESPA == 0)) //osa.OSASSTOS.Equals("S") &&  detped.DEOSPEAT != 0 ||
                                if (osa.OSASCASO > 0 && detped.DEOSESPA == 0 && !osa.OSASSTOS.Equals("T")) //osa.OSASSTOS.Equals("S") &&  detped.DEOSPEAT != 0 ||
                                {
                                    if (detped.DEOSPEAT == 0)
                                    {
                                        osa.OSASSTOS = "T";
                                    }
                                    else
                                    {
                                        osa.OSASSTOS = "C";
                                    }
                                    //actualizar estado PENDIENTE AS
                                    actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, -1, osa.OSASSTOS); //Validar
                                }

                            }
                        }
                    }
                    context.SaveChanges();
                }
                vpar.VALSAL = new List<string>();
                if (nuevoregistro)
                {
                    vpar.VALSAL.Add(idco);
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
                if (ex.InnerException != null && ex.InnerException.InnerException != null)
                {
                    Util.EscribeLog(ex.InnerException.InnerException.Message);
                    resultado += ex.InnerException.InnerException.Message;
                }
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        public RESOPE ActualizaDetOsa(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            appWcfService.PEDEOS detpedint;
            string resultado = "";
            try
            {
                detpedint = Utils.Deserialize<appWcfService.PEDEOS>(paramOperacion.VALENT[0]);
                using (var context = new PEDIDOSEntities())
                {
                    var osa = context.PROSAS.FirstOrDefault(ped => ped.OSASCIA == 1 && ped.OSASFOLI == detpedint.DEOSFOLI && ped.OSASSECU == detpedint.DEOSSECU);
                    if (osa != null)
                    {
                        //actualizar al guardar bolsa preparada o al trabajar item?
                        if (osa.OSASSTOS.Equals("E") || osa.OSASSTOS.Equals("P")) //|| p
                        {
                            osa.OSASSTOS = "S";
                            //actualizar estado PENDIENTE AS
                            actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, -1, osa.OSASSTOS); //Validar AS
                        }
                    }
                    context.SaveChanges();
                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
                if (ex.InnerException != null && ex.InnerException.InnerException != null)
                {
                    Util.EscribeLog(ex.InnerException.InnerException.Message);
                    resultado += ex.InnerException.InnerException.Message;
                }
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        public RESOPE ObtienePreparacionOsa(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> lista = null;
            decimal idosa;
            try
            {
                idosa = decimal.Parse(paramOperacion.VALENT[0]);
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA(idosa).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ObtieneBolsaOsa(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_BOLSA_OSA_Result> lista = null;
            decimal iddetalle;
            string empaque;
            try
            {
                iddetalle = decimal.Parse(paramOperacion.VALENT[0]);
                empaque = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_BOLSA_OSA(iddetalle, empaque).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_BOLSA_OSA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ObtieneBolsaUbicacion(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_BOLSA_UBICACION_Result> lista = null;

            string empaque;
            try
            {
                empaque = paramOperacion.VALENT[0];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_BOLSA_UBICACION(empaque).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_BOLSA_UBICACION_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ObtieneDetalleBolsa(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_BOLSA_Result> lista = null;

            string empaque;
            try
            {
                empaque = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETALLE_BOLSA(empaque).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_BOLSA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraUbicacionesArticulo(PAROPE paramOperacion)
        {

            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_UBICACIONES_Result> lista = null;
            try
            {
                string articulo, partida;
                decimal almacen;
                articulo = paramOperacion.VALENT[0];
                partida = paramOperacion.VALENT[1];
                almacen = decimal.Parse(paramOperacion.VALENT[2]);

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_UBICACIONES(articulo, partida, almacen).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_UBICACIONES_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1"); //existe //0
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0"); //no existe
                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
                //throw ex;
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE BusquedaOsas(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_BUSCA_OSAS_PENDIENTES_Result> lista = null;

            string folio, busqueda, partida;
            try
            {
                folio = paramOperacion.VALENT[0];
                busqueda = paramOperacion.VALENT[1];
                partida = paramOperacion.VALENT[2];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_BUSCA_OSAS_PENDIENTES(folio, busqueda, partida).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_BUSCA_OSAS_PENDIENTES_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE BusquedaOsasPlanta(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result> lista = null;

            string folio, busqueda;
            try
            {
                folio = paramOperacion.VALENT[0];
                busqueda = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_BUSCA_OSAS_PENDIENTES_PLANTA(folio, busqueda).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientesPlanta(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            string busqueda;
            try
            {
                folio = paramOperacion.VALENT[0];
                busqueda = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES_PLANTA(folio, busqueda).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE Cambiaestadeos(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> listdetosas = null;
            string usuario;
            try
            {
                listdetosas = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>>(paramOperacion.VALENT[0]);
                usuario = paramOperacion.VALENT[1];
                foreach (var item in listdetosas)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        var deos = context.PEDEOS.Find(item.DEOSIDDO);
                        if (deos != null)
                        {
                            deos.DEOSESTA = item.DEOSESTA;
                            var caos = context.PECAOS.Find(item.DEOSIDCO);

                            switch (Int32.Parse(item.DEOSESTA.ToString()))
                            {
                                case 3:
                                    caos.CAOSFHIP = DateTime.Now;
                                    caos.CAOSUSIP = usuario;
                                    break;
                                case 6:
                                    deos.DEOSESPA = 1;
                                    break;
                                case 5:
                                    deos.DEOSESPA = 0;
                                    caos.CAOSFHFP = DateTime.Now;
                                    caos.CAOSUSFP = usuario;
                                    break;

                            }
                            context.SaveChanges();
                        }
                    }
                }
                vpar.VALSAL = new List<string>();
                vpar.ESTOPE = true;
            }

            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {

            }
            return vpar;
        }

        //cambios

        public RESOPE ObtieneFoliosUsuario(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.PEUSTF> lista = null;

            string usuario;
            try
            {
                usuario = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.PEUSTF.Include("PETIFO").Where(a => a.USTFUSUA == usuario).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.PEUSTF>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientesPrioriza(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            try
            {
                folio = paramOperacion.VALENT[0];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR(folio)/*.OrderByDescending(ped => ped.CAOSPRIO).ThenBy(ped => ped.PARTFEEF)*/.ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PRIORIZAR_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE GuardaPrioridad(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.PECAOS> lista = null;
            try
            {
                lista = Util.Deserialize<List<appWcfService.PECAOS>>(paramOperacion.VALENT[0]);
                string usuario = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    foreach (var item in lista)
                    {
                        var ped = context.PECAOS.Find(item.CAOSIDCO);

                        ped.CAOSPRIO = item.CAOSPRIO;
                        if (item.CAOSEPRI == 1 && item.CAOSUSPR == null)
                        {
                            ped.CAOSEPRI = item.CAOSEPRI;
                            ped.CAOSFEPR = DateTime.Now;
                            ped.CAOSUSPR = usuario;
                        }
                        context.SaveChanges();
                    }
                }
                vpar.ESTOPE = true;
            }

            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {

            }
            return vpar;
        }

        public RESOPE guardaPreparacionBolsa(PAROPE paramOperacion)//appWcfService.PEBODP detallebolsa)
        {
            /////comentado 26-4-18
            //appWcfService.PEBODP detallebolsa;
            ////

            ///////////////////////cambios para multiple
            List<appWcfService.PEBODP> ListaBolsas = null;
            ///////////////////////

            Nullable<decimal> iddetpedidostoc = null;

            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            string resultado = "";
            string partida, articulo;
            try
            {
                ////comentado 26-4-18
                //detallebolsa = Util.Deserialize<appWcfService.PEBODP>(paramOperacion.VALENT[0]);
                ///

                //////////////////////cambios para multiple
                ListaBolsas = Util.Deserialize<List<appWcfService.PEBODP>>(paramOperacion.VALENT[0]);
                //////////////////////

                partida = articulo = "";
                //if (detallebolsa == null)
                //{
                //    Util.EscribeLog("detallebolsa es null");
                //}
                //else
                //{
                //    Util.EscribeLog("detallebolsa " + detallebolsa.BODPIDDP.ToString() + " " + detallebolsa.BODPIDDP.ToString());
                //}

                using (var context = new PEDIDOSEntities())
                {

                    foreach (var detallebolsa in ListaBolsas)///cambios para multiple
                    {
                        EFModelo.PEDEPE detpednac = null;
                        EFModelo.PEDEOS detpedint = null;
                        //inserta PBOLS si no existe
                        //var bol = context.PEBOLS.Find(detallebolsa.BODPIDBO);
                        var emp = context.GMCAEM.First(b => b.CAEMCIA == 1 && b.CAEMCOEM == detallebolsa.PEBOLS.BOLSCOEM);
                        if (emp != null)
                        {
                            var bol = context.PEBOLS.FirstOrDefault(b => b.BOLSCOEM == detallebolsa.PEBOLS.BOLSCOEM); //.Find(bolsa.BOLSIDBO);//agregado 9/05/2018
                            if (bol == null) //no existe pbols, insertar
                            {
                                bol = new EFModelo.PEBOLS();
                                //inserta = true;
                                bol.BOLSCOEM = detallebolsa.PEBOLS.BOLSCOEM;
                                bol.BOLSUSCR = detallebolsa.BODPUSCR;
                                bol.BOLSFECR = DateTime.Now;
                                bol.BOLSCOCA = null;
                                bol.BOLSESTA = 1;
                                bol.BOLSALMA = emp.CAEMALMA;
                                bol.BOLSCOAR = "";//agregado 9/05/2018
                                context.PEBOLS.Add(bol);
                                context.SaveChanges();
                                detallebolsa.BODPIDBO = bol.BOLSIDBO;
                            }
                            else
                            {
                                if (bol.BOLSALMA == 0)
                                {
                                    bol.BOLSALMA = emp.CAEMALMA;
                                }
                            }
                            if (detallebolsa.BODPDIFE <= 0 || detallebolsa.BODPSTCE == 1)
                            {
                                //bol.BOLSESTA = 9; //ya no se usa la bolsa, pero esta mal por detalle
                            }
                            //bool inserta = false;
                            //
                            if (detallebolsa.BODPIDDP.HasValue)
                            {
                                detpednac = context.PEDEPE.Find(detallebolsa.BODPIDDP);
                                partida = detpednac.DEPEPART;
                                articulo = detpednac.DEPECOAR;
                            }
                            else if (detallebolsa.BODPIDDO.HasValue)
                            {
                                detpedint = context.PEDEOS.Find(detallebolsa.BODPIDDO);
                                partida = detpedint.DEOSPART;
                                articulo = detpedint.DEOSCOAR;
                            }

                            //var ent = context.PEBODP.Find(detallebolsa.BODPIDDE);
                            var ent = context.PEBODP.FirstOrDefault(x => x.BODPIDDE == detallebolsa.BODPIDDE);
                            if (ent == null) //detallebolsa.BODPIDDE != 0)
                            {
                                ent = new EFModelo.PEBODP();
                                //inserta = true;
                                ent.BODPUSCR = detallebolsa.BODPUSCR;
                                ent.BODPFECR = DateTime.Now;
                                ent.BODPESTA = 1;
                                context.PEBODP.Add(ent);
                                //inserta tipo 1 SALIDA
                                insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, detallebolsa.BODPCANT, detallebolsa.BODPPESO, detallebolsa.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                            }
                            else
                            {
                                ent.BODPUSMO = detallebolsa.BODPUSCR;
                                ent.BODPFEMO = DateTime.Now;
                                ent.BODPESTA = 3;
                                //SOLO si las cantidades o pesos son diferentes
                                //inserta tipo 3 reingreso
                                //inserta tipo 1 salida
                                if (detallebolsa.BODPCANT != ent.BODPCANT || detallebolsa.BODPPESO != ent.BODPPESO)
                                {
                                    insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_MODIFICA_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, ent.BODPCANT, ent.BODPPESO, ent.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                                    insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, detallebolsa.BODPCANT, detallebolsa.BODPPESO, detallebolsa.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                                }
                            }
                            //automatizar el parse sin incluir la PK
                            ent.BODPIDBO = detallebolsa.BODPIDBO;
                            ent.BODPIDDP = detallebolsa.BODPIDDP; //detalle de pedido si es que no es null
                            ent.BODPALMA = bol.BOLSALMA;
                            ent.BODPPART = partida;
                            ent.BODPCOAR = articulo;
                            ent.BODPCANT = detallebolsa.BODPCANT;
                            ent.BODPPESO = detallebolsa.BODPPESO;
                            ent.BODPPERE = detallebolsa.BODPPERE;
                            ent.BODPDIFE = detallebolsa.BODPDIFE;
                            ent.BODPSTCE = detallebolsa.BODPSTCE;
                            ent.BODPINBO = detallebolsa.BODPINBO;
                            ent.BODPIDDO = detallebolsa.BODPIDDO; //detalle de osa si es que no es null
                                                                  //iddetpedido = ent.BODPIDDP;
                                                                  //iddetpedidoint = ent.BODPIDDO;
                            ent.BODPTAUN = detallebolsa.BODPTAUN; //agregado 9/05/2018
                            if (detallebolsa.PEDEPE != null && detallebolsa.PEDEPE.DEPESTOC.HasValue)
                            {
                                iddetpedidostoc = detallebolsa.PEDEPE.DEPESTOC;
                            }

                            ent.BODPTADE = detallebolsa.BODPTADE;
                            ent.BODPPEBR = detallebolsa.BODPPEBR;
                            ent.BODPESTA = detallebolsa.BODPESTA; //agregado 9/05/2018

                            context.SaveChanges(); //necesite guardar 1ro labolsa actual para luego recuperar todas las bolsas de la BD
                            decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            if (detallebolsa.BODPIDDP.HasValue)
                            {
                                var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDP == detallebolsa.BODPIDDP).ToList();
                                // decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                                cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                                foreach (var bolsaprep in listbolsas)
                                {
                                    cantatendida += bolsaprep.BODPCANT;
                                    pesoatendido += bolsaprep.BODPPESO;
                                    pesoreal += bolsaprep.BODPPERE;
                                    tade += bolsaprep.BODPTADE;
                                    pebr += bolsaprep.BODPPEBR;
                                }
                                //var detpednac = context.PEDEPE.Find(iddetpedido);
                                detpednac.DEPECAAT = cantatendida;
                                detpednac.DEPEPEAT = pesoatendido;
                                detpednac.DEPEPERE = pesoreal;
                                if (iddetpedidostoc.HasValue)
                                {
                                    detpednac.DEPESTOC = iddetpedidostoc;
                                }
                                detpednac.DEPETADE = tade;
                                detpednac.DEPEPEBR = pebr;

                                context.SaveChanges();
                            }
                            else if (detallebolsa.BODPIDDO.HasValue)
                            {
                                var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDO == detallebolsa.BODPIDDO).ToList();
                                //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                                cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                                foreach (var bolsaprep in listbolsas)
                                {
                                    cantatendida += bolsaprep.BODPCANT;
                                    pesoatendido += bolsaprep.BODPPESO;
                                    pesoreal += bolsaprep.BODPPERE;
                                    tade += bolsaprep.BODPTADE;
                                    pebr += bolsaprep.BODPPEBR;
                                }
                                //var detpedint = context.PEDEOS.Find(detallebolsa.BODPIDDO);
                                detpedint.DEOSCAAT = cantatendida;
                                detpedint.DEOSPEAT = pesoatendido;
                                detpedint.DEOSPERE = pesoreal;
                                if (iddetpedidostoc.HasValue)
                                {
                                    detpedint.DEOSSTOC = iddetpedidostoc;
                                }
                                detpedint.DEOSTADE = tade;
                                detpedint.DEOSPEBR = pebr;
                                //actualiza peso en osa ---PENDIENTE EN AS
                                var osa = context.PROSAS.Find(1, detpedint.DEOSFOLI, detpedint.DEOSSECU);
                                if (osa != null)
                                {
                                    osa.OSASCAEN = pesoatendido;
                                    actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, osa.OSASCAEN, ""); //Validar AS 
                                }
                                context.SaveChanges();
                            }
                            //actualiza el stock de la bolsa
                            var todasbolsasprep = context.PEBODP.Where(prep => prep.BODPIDBO == bol.BOLSIDBO && prep.BODPALMA == bol.BOLSALMA && prep.BODPPART == partida && prep.BODPCOAR == articulo).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in todasbolsasprep)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            var detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMPART == partida && det.DEEMARTI == articulo && det.DEEMTIPE == "N");
                            if (detemp != null)
                            {
                                detemp.DEEMCAST = detemp.DEEMCANT - cantatendida;
                                detemp.DEEMPEST = (detemp.DEEMPNET - detemp.DEEMDEST + detemp.DEEMACON) - pesoatendido;
                                if (iddetpedidostoc.HasValue)
                                {
                                    detemp.DEEMSTCE = iddetpedidostoc.Value;
                                }
                                if (detemp.DEEMSTCE == 1)
                                {
                                    detemp.DEEMESBO = 9;
                                }
                                else if (detemp.DEEMCAST <= 0 && detemp.DEEMPEST <= 0)
                                {
                                    detemp.DEEMESBO = 9;
                                }
                                else
                                {
                                    detemp.DEEMESBO = 1;
                                }
                                actualizaGMDEEM(detemp.DEEMCOEM, detemp.DEEMSECU, detemp.DEEMCAST, detemp.DEEMPEST, detemp.DEEMSTCE, detemp.DEEMESBO); // Validar AS 
                                context.SaveChanges();
                                //buscar una partida en la bolsa que no este vacia, si no hay ninguna actualizar a 9 anulado
                                detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMTIPE == "N" && det.DEEMESBO != 9);
                                if (detemp == null)
                                {
                                    bol.BOLSESTA = 9; //ya no se usa la bolsa
                                }
                                else
                                {
                                    bol.BOLSESTA = 1; //ya no se usa la bolsa - si se modifica la cant o kilos de la bolsa o si se le quito el stock cero desmarcar la bolsa
                                }
                                context.SaveChanges();
                            }
                        }
                        else
                        {
                            resultado = "Código de empaque incorrecto";
                        } 
                    }
                }
                vpar.VALSAL = new List<string>();
                //vpar.VALSAL.Add(ent.BODPIDDE.ToString());
                //vpar.VALSAL.Add(detallebolsa.BODPIDBO.ToString());
                resultado = ""; // ent.BODPIDDE.ToString();
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        private void insertaMovimientoKardex(PEDIDOSEntities context, decimal? idbolsa, decimal idtipomovimiento, decimal almacen, string partida, string articulo, decimal cantidad, decimal peso, decimal pesobr, string usuario, Nullable<decimal> iddetpedido, Nullable<decimal> iddetosa)
        {
            decimal valorsigno = 1;
            if (idtipomovimiento == TIPO_MOV_SALIDA_PREP_PED)
            {
                valorsigno = -1;
            }
            var entk = new EFModelo.PEKABO();
            entk.KABOIDBO = idbolsa.Value;
            entk.KABOIDTM = idtipomovimiento;
            entk.KABOALMA = almacen;
            entk.KABOPART = partida;
            entk.KABOITEM = articulo;
            entk.KABOCANT = cantidad * valorsigno;
            entk.KABOPESO = peso * valorsigno;
            entk.KABOPEBR = pesobr * valorsigno;
            entk.KABOTARA = entk.KABOPEBR - entk.KABOPESO;
            entk.KABOFECH = DateTime.Today;
            entk.KABOUSCR = usuario;
            entk.KABOFECR = DateTime.Now;
            entk.KABOIDDP = iddetpedido;
            entk.KABOIDDO = iddetosa;
            context.PEKABO.Add(entk);
        }

        public RESOPE remueveBolsaPedido(PAROPE paramOperacion)//decimal idbolsapedido, string usuario)
        {
            Nullable<decimal> iddetpedido;
            Nullable<decimal> iddetpedidoint;
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            string resultado = "";
            string partida, articulo;
            try
            {
                decimal idbolsapedido = decimal.Parse(paramOperacion.VALENT[0]);
                string usuario = paramOperacion.VALENT[1];

                partida = articulo = "";
                using (var context = new PEDIDOSEntities())
                {
                    EFModelo.PEDEPE detpednac = null;
                    EFModelo.PEDEOS detpedint = null;

                    //bool inserta = false;
                    //foreach (var item in collection)
                    //{

                    //}
                    var ent = context.PEBODP.Find(idbolsapedido);
                    if (ent != null) //detallebolsa.BODPIDDE != 0)
                    {
                        var bol = context.PEBOLS.Find(ent.BODPIDBO);
                        if (ent.BODPIDDP.HasValue)
                        {
                            detpednac = context.PEDEPE.Find(ent.BODPIDDP);
                            partida = detpednac.DEPEPART;
                            articulo = detpednac.DEPECOAR;
                        }
                        else if (ent.BODPIDDO.HasValue)
                        {
                            detpedint = context.PEDEOS.Find(ent.BODPIDDO);
                            partida = detpedint.DEOSPART;
                            articulo = detpedint.DEOSCOAR;
                        }
                        iddetpedido = ent.BODPIDDP;
                        iddetpedidoint = ent.BODPIDDO;
                        insertaMovimientoKardex(context, ent.BODPIDBO, TIPO_MOV_CANCELA_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, ent.BODPCANT, ent.BODPPESO, ent.BODPPEBR - ent.BODPTADE, usuario, ent.BODPIDDP, ent.BODPIDDO);

                        context.PEBODP.Remove(ent);
                        //if (detallebolsa.BODPDIFE <= 0 || detallebolsa.BODPSTCE == 1)
                        //{
                        //bol.BOLSESTA = 1; //ya no se usa
                        //}

                        context.SaveChanges();
                        decimal cantatendida, pesoatendido, pesoreal, tade, pebr;

                        if (iddetpedido.HasValue)
                        {
                            var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDP == iddetpedido).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in listbolsas)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            //detpednac = context.PEDEPE.Find(iddetpedido);
                            detpednac.DEPECAAT = cantatendida;
                            detpednac.DEPEPEAT = pesoatendido;
                            detpednac.DEPEPERE = pesoreal;
                            detpednac.DEPETADE = tade;
                            detpednac.DEPEPEBR = pebr;

                            //inserta tipo 2 kardex reingreso
                            context.SaveChanges();
                        }
                        else if (iddetpedidoint.HasValue)
                        {
                            var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDO == iddetpedidoint).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in listbolsas)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            detpedint.DEOSCAAT = cantatendida;
                            detpedint.DEOSPEAT = pesoatendido;
                            detpedint.DEOSPERE = pesoreal;
                            detpedint.DEOSTADE = tade;
                            detpedint.DEOSPEBR = pebr;
                            //actualiza peso en osa ---PENDIENTE EN AS
                            var osa = context.PROSAS.Find(1, detpedint.DEOSFOLI, detpedint.DEOSSECU);
                            if (osa != null)
                            {
                                osa.OSASCAEN = pesoatendido;
                                actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, osa.OSASCAEN, ""); //Validar AS
                            }
                            context.SaveChanges();

                        }
                        //actualiza el stock de la bolsa
                        var todasbolsasprep = context.PEBODP.Where(prep => prep.BODPIDBO == bol.BOLSIDBO && prep.BODPALMA == bol.BOLSALMA && prep.BODPPART == partida && prep.BODPCOAR == articulo).ToList();
                        //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                        cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                        foreach (var bolsaprep in todasbolsasprep)
                        {
                            cantatendida += bolsaprep.BODPCANT;
                            pesoatendido += bolsaprep.BODPPESO;
                            pesoreal += bolsaprep.BODPPERE;
                            tade += bolsaprep.BODPTADE;
                            pebr += bolsaprep.BODPPEBR;
                        }
                        var detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMPART == partida && det.DEEMARTI == articulo && det.DEEMTIPE == "N");
                        if (detemp != null)
                        {
                            detemp.DEEMCAST = detemp.DEEMCANT - cantatendida;
                            detemp.DEEMPEST = (detemp.DEEMPNET - detemp.DEEMDEST + detemp.DEEMACON) - pesoatendido;
                            //si la bolsa preparada estaba marcada como stock cero, lo desmarco
                            if (ent.BODPSTCE == 1)
                            {
                                detemp.DEEMSTCE = 0;
                            }
                            if (detemp.DEEMSTCE == 0)
                            {
                                detemp.DEEMESBO = 1;
                            }
                            else
                            if (detemp.DEEMCAST <= 0 && detemp.DEEMPEST <= 0)
                            {
                                detemp.DEEMESBO = 9;
                            }
                            else
                            {
                                detemp.DEEMESBO = 1;
                            }
                            context.SaveChanges();
                            actualizaGMDEEM(detemp.DEEMCOEM, detemp.DEEMSECU, detemp.DEEMCAST, detemp.DEEMPEST, detemp.DEEMSTCE, detemp.DEEMESBO); // Validar AS 
                            //buscar una partida en la bolsa que no este vacia, si no hay ninguna actualizar a 9 anulado
                            detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMTIPE == "N" && det.DEEMESBO != 9);
                            if (detemp == null)
                            {
                                bol.BOLSESTA = 9; //ya no se usa la bolsa
                            }
                            else
                            {
                                bol.BOLSESTA = 1; //ya no se usa la bolsa - si se modifica la cant o kilos de la bolsa o si se le quito el stock cero desmarcar la bolsa
                            }
                            context.SaveChanges();
                        }
                    }
                    vpar.ESTOPE = true;
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        public RESOPE cambiaestadoBodp(PAROPE paramOperacion)
        {
            //Por corregir 19/02
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<EFModelo.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> idosa = null;
            decimal estado;
            string usuario;
            try
            {
                idosa = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>>(paramOperacion.VALENT[0]);

                estado = decimal.Parse(paramOperacion.VALENT[1]);
                usuario = paramOperacion.VALENT[2];

                using (var context = new PEDIDOSEntities())
                {
                    foreach (var item in idosa)
                    {
                        listaeo = context.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA(item.DEOSIDDO).ToList();
                        //lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>(listaeo);
                        ////
                        int estacambia = 0;

                        switch (Int32.Parse(estado.ToString()))
                        {
                            case 4:
                                estacambia = 3;
                                break;
                            case 3:
                                estacambia = 4;
                                break;
                            case 5:
                                estacambia = 4;
                                break;
                        }
                        ////
                        foreach (var item1 in listaeo)
                        {
                            if (estacambia != 0)
                            {
                                var ent = context.PEBODP.Find(item1.BODPIDDE);
                                if (ent.BODPESTA == estacambia)
                                {
                                    ent.BODPESTA = estado;
                                    ent.BODPFEMO = DateTime.Now;
                                    ent.BODPUSMO = usuario;
                                    context.SaveChanges();
                                }
                            }
                            else
                            {
                                break;
                            }

                        }
                    }
                }

                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE GuardaOrigin(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            appWcfService.USP_OBTIENE_DETALLE_OSA_Result detosas = null;
            try
            {
                detosas = Util.Deserialize<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>(paramOperacion.VALENT[0]);

                using (var context = new PEDIDOSEntities())
                {
                    var deos = context.PEDEOS.Find(detosas.DEOSIDDO);
                    if (deos != null)
                    {
                        deos.DEOSCAOR = detosas.DEOSCAAT;
                        deos.DEOSPEOR = detosas.DEOSPEAT;
                        context.SaveChanges();
                    }
                }
                vpar.ESTOPE = true;
            }

            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {

            }
            return vpar;
        }

        public RESOPE ReabreOsa(PAROPE paramOperacion)
        {
            //restructurar para recibir una list de detalles 
            //cambiar el estado de la prosa a s
            //cabecera cambia a 3 sin importar
            //deos cambiaar estado a 3
            // restar la secuenci y actualizar esta  en bodp y deos 
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> Detosas = null;
            string usuario;
            try
            {
                Detosas = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result>>(paramOperacion.VALENT[0]);
                usuario = paramOperacion.VALENT[1];

                if (Detosas.Count > 0)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        foreach (var item in Detosas)
                        {
                            //CAMBIO DE ESTADO PROSA
                            var osa = context.PROSAS.FirstOrDefault(x => x.OSASFOLI == item.OSASFOLI && x.OSASSTOS == item.OSASSTOS && x.OSASSECU == item.OSASSECU && x.OSASPAOR == item.OSASPAOR);
                            if (osa != null && (osa.OSASSTOS.Equals("C") || osa.OSASSTOS.Equals("P")))
                            {
                                osa.OSASSTOS = "S";
                                actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, -1, osa.OSASSTOS); //Validar
                            }
                            //CAMBIO DE ESTADO DEOS
                            var deos = context.PEDEOS.Find(item.DEOSIDDO);
                            if (deos != null)
                            {
                                deos.DEOSESTA = 3;
                                deos.DEOSSECR = item.DEOSSECR - 1;//SOLO PARA REABRIR
                                deos.DEOSUSMO = usuario;
                                deos.DEOSFEMO = DateTime.Now;
                            }
                            //CAMBIO DE ESTADO PECAOS
                            var cabosa = context.PECAOS.FirstOrDefault(x => x.CAOSIDCO == item.DEOSIDCO);
                            if (cabosa != null)
                            {
                                cabosa.CAOSIDES = 3;
                                cabosa.CAOSUSMO = usuario;
                                cabosa.CAOSFEMO = DateTime.Now;
                            }
                            //PENDIENTE DE AGREGAR MARGARET
                            // RESTAR LA SECUENCIA Y ACTUALIZAR ESTA EN PEBODP Y DEOS
                            var dpbolsa = context.PEBODP.Where(x => x.BODPESTA == 4 && x.BODPIDDO == item.DEOSIDDO).ToList();
                            foreach (var item1 in dpbolsa)
                            {
                                item1.BODPESTA = 3;
                                item1.BODPFEMO = DateTime.Now;
                                item1.BODPUSMO = usuario;
                                item1.BODPSECR = item1.BODPSECR - 1;
                            }
                        }
                        context.SaveChanges();
                        vpar.ESTOPE = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {

            }
            return vpar;
        }

        public RESOPE MuestraDetalleOsaPlanta(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result> lista = null;
            string folio; //envia folio completo
            try
            {
                folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETALLE_OSA_PLANTA(folio).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientesImprimir(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result> lista = null;
            string folio, valbus; //Solo le manda inicial del folio W,S, etc

            try
            {
                folio = paramOperacion.VALENT[0];
                valbus = paramOperacion.VALENT[1];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA(folio, valbus).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_IMPRIMIR_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");
                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }
        public RESOPE MuestraDetalleOsaPlantaImprimir(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result> lista = null;
            string folio; //envia folio completo
            try
            {
                folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA(folio).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_IMPRIMIR_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraDetalleOsaPlantaList(PAROPE paramOperacion)
        {
            //Recibe una lista
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<object> listaeo2 = new List<object>();

            List<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result> lista = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> ListaOsas = new List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
            try
            {
                ListaOsas = Util.Deserialize<List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>>(paramOperacion.VALENT[0]);
                foreach (var item in ListaOsas)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        listaeo = context.USP_OBTIENE_DETALLE_OSA_PLANTA(item.OSASFOLI).ToList<object>();
                    }
                    if (listaeo.Count > 0)
                    {
                        listaeo2.AddRange(listaeo);
                    }
                }

                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result>(listaeo2);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ApruebaOsasPlanta(PAROPE paramOperacion)
        {
            //Recibe una lista
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result> Listadetalles = new List<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result>();
            string usuario;
            appLogica.appDB2 _appDB2 = null;
            int secuencia = 0;
            try
            {
                _appDB2 = new appLogica.appDB2();
                Listadetalles = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_PLANTA_Result>>(paramOperacion.VALENT[0]);
                usuario = paramOperacion.VALENT[1];
                using (var context = new PEDIDOSEntities())
                {
                    foreach (var item in Listadetalles)
                    {
                        decimal cantentreg = 0;
                        var osaplanta = context.PROSAS.SingleOrDefault(o => o.OSASCIA == item.OSASCIA && o.OSASFOLI == item.OSASFOLI && o.OSASSECU == item.OSASSECU && o.OSASSTOS == item.OSASSTOS);
                        if (osaplanta != null)
                        {
                            if (item.DEOSESPA == 1)
                            {
                                if (osaplanta.OSASSTOS != "E")
                                {
                                    osaplanta.OSASSTOS = "P";

                                }
                            }
                            else
                            {
                                osaplanta.OSASSTOS = "T";
                            }
                            //20180424
                            //actualizaPROSAS(osaplanta.OSASFOLI, osaplanta.OSASSECU, -1, osaplanta.OSASSTOS); //Validar
                            //osaplanta.OSASFEAT = DateTime.Today;
                            var pecaos = context.PECAOS.SingleOrDefault(p => p.CAOSFOLI == item.OSASFOLI && p.CAOSIDCO == item.DEOSIDCO);
                            osaplanta.OSASFEAT = pecaos.CAOSFHFP.Value.Date; // : DateTime.Today;
                            actualizaPROSAS(osaplanta.OSASFOLI, osaplanta.OSASSECU, osaplanta.OSASSTOS, osaplanta.OSASFEAT); //Validar

                            //Obtenemos las bolsas
                            var bolsas = context.PEBODP.Where(dp => dp.BODPIDDO == item.DEOSIDDO).ToList();
                            if (bolsas != null)
                            {
                                foreach (var bol in bolsas)
                                {
                                    if (bol.BODPESTA == 4)
                                    {
                                        bol.BODPESTA = 5;
                                    }
                                }
                            }
                            secuencia++;
                            ////Descuento de inventario
                            //20180713
                            //cantentreg = osaplanta.OSASCAEN;
                            //cantentreg = 0;
                            cantentreg = item.DEOSPEAT;
                            if (item.DEOSPEOR > 0)
                            {
                                cantentreg -= item.DEOSPEOR;
                            }
                            if (cantentreg > 0)// && item.DEOSPEAT != 0)
                            {
                                _appDB2.descargaOSA(false, osaplanta.OSASFOLI, secuencia, osaplanta.OSASFEAT, osaplanta.OSASARTI, osaplanta.OSASPAOR, osaplanta.OSASALMA, osaplanta.OSASPADE, Convert.ToInt32(osaplanta.OSASCCOS).ToString(), "-", cantentreg);
                            }

                            //20180424
                            //Actualiza el estado a la la cabecera en nuestra base de datos 
                            //var pecaos = context.PECAOS.SingleOrDefault(p => p.CAOSFOLI == item.OSASFOLI && p.CAOSIDCO == item.DEOSIDCO);
                            if (pecaos.CAOSIDES == 4)
                            {
                                //pecaos.CAOSIDES = 3; //cambiar a 3 para preparación
                                pecaos.CAOSUSAP = usuario;
                                pecaos.CAOSFEAP = DateTime.Now;
                            }
                            else if (pecaos.CAOSIDES == 5)
                            {
                                pecaos.CAOSIDES = 7; // Completado totalmente
                                pecaos.CAOSUSAP = usuario;
                                pecaos.CAOSFEAP = DateTime.Now;
                            }
                            pecaos.CAOSEXTO = 1; //Activa el flag para indicar que es posble realizar el extorno
                            var deos = context.PEDEOS.Find(item.DEOSIDDO);
                            if (deos != null)
                            {
                                if (deos.DEOSESTA == 6) //es parcial estado del detalle
                                {
                                    //deos.DEOSESTA = 3; //mantenemos en parcial
                                }
                                else // 5 significa completo 
                                {
                                    deos.DEOSESTA = 7;
                                }
                                deos.DEOSUSMO = usuario;
                                deos.DEOSFEMO = DateTime.Now;
                            }
                            context.SaveChanges();
                        }
                    }
                    vpar.ESTOPE = true;
                }

                vpar.VALSAL = new List<string>();
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
            return vpar;
        }

        /// <summary>

        public RESOPE MuestrayBuscaOsasPendientes(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            string Pbase;
            try
            {
                folio = paramOperacion.VALENT[0];
                Pbase = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_OSAS_PENDIENTES_2(folio, Pbase).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE cambiaestaDeosBodp(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> listdetosas = null;
            List<EFModelo.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> listaeo = null;
            decimal estado;
            string usuario;
            try
            {
                listdetosas = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>>(paramOperacion.VALENT[0]);
                estado = Decimal.Parse(paramOperacion.VALENT[1]);
                usuario = paramOperacion.VALENT[2];

                foreach (var item in listdetosas)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        var deos = context.PEDEOS.Find(item.DEOSIDDO);
                        if (deos != null)
                        {
                            //deos.DEOSESTA = item.DEOSESTA;
                            var caos = context.PECAOS.Find(item.DEOSIDCO);

                            switch (Int32.Parse(item.DEOSESTA.ToString()))
                            {
                                case 1:
                                    deos.DEOSESPA = item.DEOSESPA;
                                    break;
                                case 3:
                                    if (deos.DEOSESTA != 3) //PODRIA SER 2 o 6
                                    {
                                        //20180713 cambiar el peso origen, no usar el valor de peso atendido, en su lugar usar cant entregada de la OSA
                                        var osa = context.PROSAS.FirstOrDefault(o => o.OSASCIA == 1 && o.OSASFOLI == deos.DEOSFOLI && o.OSASSECU == deos.DEOSSECU);

                                        deos.DEOSCAOR = item.DEOSCAAT;
                                        if (osa == null)
                                        {
                                            //como estaba antes, no tendria porque no ocurrir
                                            deos.DEOSPEOR = item.DEOSPEAT;
                                        }
                                        else
                                        {
                                            deos.DEOSPEOR = osa.OSASCAEN;
                                        }
                                    }
                                    deos.DEOSESTA = item.DEOSESTA;
                                    break;
                                case 6: //FINALIZAR PREPARACION parciakl marcado
                                    deos.DEOSESPA = 1;
                                    if (deos.DEOSPEAT >= deos.DEOSPESO) //20180425 peso atendido mayor igual a peso solicitado
                                    {
                                        deos.DEOSESPA = 0;
                                    }
                                    //deos.DEOSCAOR = item.DEOSCAAT;
                                    //deos.DEOSPEOR = item.DEOSPEAT;
                                    deos.DEOSESTA = item.DEOSESTA;

                                    if (estado == 4)
                                    {
                                        deos.DEOSSECR = deos.DEOSSECR + 1;
                                    }
                                    break;
                                case 5: //FINALIZAR PREPARACION sin marcar parcial
                                    deos.DEOSESTA = item.DEOSESTA;
                                    deos.DEOSESPA = 0;
                                    if (estado == 4)
                                    {
                                        deos.DEOSSECR = deos.DEOSSECR + 1;
                                    }
                                    break;
                            }
                            //////
                            listaeo = context.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA(item.DEOSIDDO).ToList();
                            //lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>(listaeo);
                            ////
                            int estacambia = 0;
                            int estacreado = 0;
                            decimal secuencia = 0;

                            switch (Int32.Parse(estado.ToString()))
                            {
                                case 4:
                                    estacambia = 3;
                                    estacreado = 1;
                                    secuencia = 1;
                                    break;
                                case 3:
                                case 5:
                                    estacambia = 4;
                                    break;
                            }
                            ////
                            foreach (var item1 in listaeo)
                            {
                                if (estacambia != 0)
                                {
                                    var ent = context.PEBODP.FirstOrDefault(x => x.BODPIDDE == item1.BODPIDDE);
                                    if (ent != null)
                                    {
                                        if (ent.BODPESTA == estacambia || ent.BODPESTA == estacreado)
                                        {
                                            ent.BODPESTA = estado;
                                            ent.BODPFEMO = DateTime.Now;
                                            ent.BODPUSMO = usuario;
                                            //context.SaveChanges();
                                        }
                                        ent.BODPSECR = ent.BODPSECR + secuencia;
                                    }
                                }
                                else
                                {
                                    break;
                                }
                            }
                            //////
                            context.SaveChanges();
                        }
                    }
                }
                vpar.VALSAL = new List<string>();
                vpar.ESTOPE = true;
            }

            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {

            }
            return vpar;
        }


        //REABRIR PLANTA
        public RESOPE BusquedaOsasReabrir(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<object> listaeo = null;
            List<appWcfService.USP_BUSCA_OSAS_REABRIR_PLANTA_Result> lista = null;

            string folio, busqueda;
            int horas = 0;
            try
            {
                folio = paramOperacion.VALENT[0];
                busqueda = paramOperacion.VALENT[1];

                using (var context = new PEDIDOSEntities())
                {
                    var parametros = context.PEPARM.Find(Constantes.ID_CONTROL_HORAS);
                    if (parametros.PARMIDPA != 0)
                    {
                        horas = int.Parse(parametros.PARMVAPA.ToString());
                        listaeo = context.USP_BUSCA_OSAS_REABRIR_PLANTA(folio, busqueda, horas).ToList<object>();
                    }
                }
                lista = Util.ParseEntityObject<appWcfService.USP_BUSCA_OSAS_REABRIR_PLANTA_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");
                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraOsasPendientesReabrir(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_OSAS_PLANTA_REABRIR_Result> lista = null;
            string folio; //Solo le manda inicial del folio W,S, etc
            int horas = 0;
            try
            {
                folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    var parametros = context.PEPARM.Find(Constantes.ID_CONTROL_HORAS);
                    if (parametros.PARMIDPA != 0)
                    {
                        horas = int.Parse(parametros.PARMVAPA.ToString());
                        listaeo = context.USP_OBTIENE_OSAS_PLANTA_REABRIR(folio, horas).ToList<object>();
                    }
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_OSAS_PLANTA_REABRIR_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");
                }
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE MuestraDetalleOsaReabrir(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_REABRIR_Result> lista = null;
            string folio; //envia folio completo
            try
            {
                folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETALLE_OSA_REABRIR(folio).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETALLE_OSA_REABRIR_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ExtornarOsasPlanta(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            List<appWcfService.USP_OBTIENE_DETALLE_OSA_REABRIR_Result> Listadetalles = new List<appWcfService.USP_OBTIENE_DETALLE_OSA_REABRIR_Result>();
            string usuario;
            appLogica.appDB2 _appDB2 = null;

            int secuencia = 0;

            try
            {
                _appDB2 = new appLogica.appDB2();

                Listadetalles = Util.Deserialize<List<appWcfService.USP_OBTIENE_DETALLE_OSA_REABRIR_Result>>(paramOperacion.VALENT[0]);
                usuario = paramOperacion.VALENT[1];
                if (Listadetalles.Count > 0)
                {
                    using (var context = new PEDIDOSEntities())
                    {
                        foreach (var item in Listadetalles)
                        {
                            decimal cantentreg = 0;
                            //PROSAS CAMBIA DE T A C 
                            var osa = context.PROSAS.FirstOrDefault(x => x.OSASPAOR == item.OSASPAOR && x.OSASFOLI == item.OSASFOLI && x.OSASSECU == item.OSASSECU);
                            if (osa != null)
                            {
                                if (osa.OSASSTOS.Equals("T") || osa.OSASSTOS.Equals("P"))
                                {
                                    osa.OSASSTOS = "C";
                                    actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, -1, osa.OSASSTOS); //Validar AS
                                }

                                //EXTORNA INVENTARIO
                                secuencia++;
                                ////Descuento de inventario
                                cantentreg = osa.OSASCAEN;
                                //if (item.DEOSCAOR.HasValue)
                                //{
                                    cantentreg -= item.DEOSPEOR;
                                //}
                                if (cantentreg > 0)
                                {
                                    _appDB2.descargaOSA(false, osa.OSASFOLI, secuencia, osa.OSASFEAT, osa.OSASARTI, osa.OSASPAOR, osa.OSASALMA, osa.OSASPADE, Convert.ToInt32(osa.OSASCCOS).ToString(), "+", cantentreg);
                                }
                            }
                            //DEOS 
                            var deos = context.PEDEOS.Find(item.DEOSIDDO);
                            if (deos != null)
                            {
                                /// es completado 7
                                if (deos.DEOSESTA == 7)
                                {
                                    deos.DEOSESTA = 5;
                                }
                                // se mantiene en 6 significa que es parcial
                                deos.DEOSUSMO = usuario;
                                deos.DEOSFEMO = DateTime.Now;
                            }
                            //PECAOS
                            var caos = context.PECAOS.Find(item.DEOSIDCO);
                            if (caos != null)
                            {
                                // 7 COMPLETO
                                if (caos.CAOSIDES == 7)
                                {
                                    caos.CAOSIDES = 5;
                                }
                                //4 es parcial
                                caos.CAOSUSMO = usuario;
                                caos.CAOSFEMO = DateTime.Now;
                                caos.CAOSUSAP = null;
                                caos.CAOSFEAP = null;
                                caos.CAOSEXTO = 0; //desactiva el flag de extornos para poder reabrir la osa y pasarla a preparacion
                            }
                            //PEBODP
                            var dpbolsa = context.PEBODP.Where(x => x.BODPESTA == 5 && x.BODPSECR == 1 /*item.DEOSSECR*/ && x.BODPIDDO == item.DEOSIDDO).ToList();
                            foreach (var item1 in dpbolsa)
                            {
                                //cambia de estado 5 : completo a 4
                                item1.BODPESTA = 4;
                                item1.BODPFEMO = DateTime.Now;
                                item1.BODPUSMO = usuario;
                            }


                        }
                        context.SaveChanges();
                        vpar.ESTOPE = true;
                    }
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
            return vpar;
        }

        #region Devoluciones
        public RESOPE generaDevolucionBolsa(PAROPE paramOperacion)//appWcfService.PEBODP detallebolsa)
        {
            //pendiente de validar donde se usa
            appWcfService.GMDEEM empaque;
            RESOPE vpar;
            appLogica.appDB2 _appDB2 = null;

            vpar = new RESOPE() { ESTOPE = false };
            string tipdoc, numdoc, partfin, cencos;

            string resultado = "";
            string partida, articulo;
            decimal cantidad, peso;
            try
            {
                _appDB2 = new appLogica.appDB2();

                empaque = Util.Deserialize<appWcfService.GMDEEM>(paramOperacion.VALENT[0]);
                tipdoc = paramOperacion.VALENT[1];
                numdoc = paramOperacion.VALENT[2];
                partfin = paramOperacion.VALENT[3];
                cencos = paramOperacion.VALENT[4];
                empaque.DEEMCIA = Constantes.CODIGO_CIA;

                partida = empaque.DEEMPART;
                articulo = empaque.DEEMARTI;
                cantidad = empaque.DEEMCANT;
                peso = empaque.DEEMPNET;

                using (var context = new PEDIDOSEntities())
                {
                    //inserta PBOLS si no existe
                    //var bol = context.PEBOLS.Find(detallebolsa.BODPIDBO);
                    var emp = context.GMCAEM.First(b => b.CAEMCIA == 1 && b.CAEMCOEM == empaque.DEEMCOEM);
                    if (emp != null)
                    {
                        var bol = context.PEBOLS.First(b => b.BOLSCOEM == empaque.DEEMCOEM); //.Find(bolsa.BOLSIDBO);
                        if (bol == null) //no existe pbols, insertar
                        {
                            bol = new EFModelo.PEBOLS();
                            //inserta = true;
                            bol.BOLSCOEM = empaque.DEEMCOEM;
                            bol.BOLSUSCR = empaque.DEEMUSER;
                            bol.BOLSFECR = DateTime.Now;
                            bol.BOLSCOCA = "";
                            bol.BOLSESTA = 1;
                            bol.BOLSALMA = emp.CAEMALMA;

                            context.PEBOLS.Add(bol);
                            context.SaveChanges();
                        }
                        else
                        {
                            if (bol.BOLSALMA == 0)
                            {
                                bol.BOLSALMA = emp.CAEMALMA;
                            }
                        }
                        _appDB2.descargaDevolucion(false, tipdoc, numdoc, 1, DateTime.Today, articulo, partida, bol.BOLSALMA, partfin, Convert.ToInt32(cencos).ToString(), cantidad); //consumo es negativo

                        insertaMovimientoKardex(context, bol.BOLSIDBO, TIPO_MOV_DEVOLUCION_MATERIAL, bol.BOLSALMA, partida, articulo, cantidad, peso, peso, empaque.DEEMUSER, null, null);

                        //actualiza el stock de la bolsa
                        //VERIFICAR EL STOCVK SE ACTUALIZA DE PREPARACIONES PERO POR UNA DEVOLUCION SE DESCUADRARIA??
                        var detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMSECU == empaque.DEEMSECU && det.DEEMTIPE == "N");
                        if (detemp != null)
                        {
                            detemp.DEEMCAST = detemp.DEEMCAST + cantidad;
                            detemp.DEEMPEST = detemp.DEEMPEST + peso;
                            detemp.DEEMSTCE = 0; //stock cero no puede ser
                            detemp.DEEMESBO = 1; //no puede estar anulada la bolsa
                            bol.BOLSESTA = 1; //ya no se usa la bolsa - si se modifica la cant o kilos de la bolsa o si se le quito el stock cero desmarcar la bolsa
                            context.SaveChanges();
                        }
                        //PENDIENTE AS
                        actualizaGMDEEM(detemp.DEEMCOEM, detemp.DEEMSECU, detemp.DEEMCAST, detemp.DEEMPEST, detemp.DEEMSTCE, detemp.DEEMESBO); //Validar AS

                        vpar.VALSAL = new List<string>();
                        resultado = ""; // ent.BODPIDDE.ToString();
                        vpar.ESTOPE = true;
                    }
                    else
                    {
                        resultado = "Código de empaque incorrecto";
                    }
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        #endregion
        /// <summary>
        /// Actualiza PROSAS en AS
        /// </summary>
        /// <param name="folio"></param>
        /// <param name="secuencia"></param>
        /// <param name="pesoentregado">Peso entregado en la OSA, -1 si no se actualizará</param>
        /// <param name="estado">estado de la OSA, solo se actualizará si pesoentregado es -1</param>
        private void actualizaPROSAS(string folio, decimal secuencia, decimal pesoentregado, string estado)
        {
            appLogica.appDB2 _appDB2 = null;
            try
            {
                _appDB2 = new appLogica.appDB2();
                _appDB2.actualizaPROSAS(folio, secuencia, pesoentregado, estado);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
        }

        private void actualizaPROSAS(string folio, decimal secuencia, string estado, DateTime fechaatencion)
        {
            appLogica.appDB2 _appDB2 = null;
            try
            {
                _appDB2 = new appLogica.appDB2();
                _appDB2.actualizaPROSAS(folio, secuencia, estado, fechaatencion);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
        }

        /// <summary>
        /// Actualiza GMDEEM en AS
        /// </summary>
        /// <param name="empaque"></param>
        /// <param name="secuencia"></param>
        /// <param name="cantidadrestante"></param>
        /// <param name="pesorestante"></param>
        /// <param name="stockcerobolsa">Valor 1 o 0 para indicar que la bolsa se marcó como stock cero, -1 para no actualizar el valor</param>
        /// <param name="estadobolsa"></param>
        private void actualizaGMDEEM(string empaque, decimal secuencia, decimal cantidadrestante, decimal pesorestante, decimal stockcerobolsa, decimal estadobolsa)
        {
            appLogica.appDB2 _appDB2 = null;
            try
            {
                _appDB2 = new appLogica.appDB2();
                _appDB2.actualizaGMDEEM(empaque, secuencia, cantidadrestante, pesorestante, stockcerobolsa, estadobolsa);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
        }

        private void actualizaGMCAEM(string empaque, string estado)
        {
            appLogica.appDB2 _appDB2 = null;
            try
            {
                _appDB2 = new appLogica.appDB2();
                _appDB2.actualizaGMCAEM(empaque, estado);
            }
            finally
            {
                if (_appDB2 != null)
                {
                    _appDB2.Finaliza();
                    _appDB2 = null;
                }
            }
        }

        #region SIN EMPAQUE

        public RESOPE guardaPreparacionBolsase(PAROPE paramOperacion)//appWcfService.PEBODP detallebolsa)
        {
            /////comentado 26-4-18
            //appWcfService.PEBODP detallebolsa;
            ////

            ///////////////////////cambios para multiple
            List<appWcfService.PEBODP> ListaBolsas = null;
            ///////////////////////

            Nullable<decimal> iddetpedidostoc = null;

            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            string resultado = "";
            string partida, articulo;
            decimal almacen;

            try
            {
                ////comentado 26-4-18
                //detallebolsa = Util.Deserialize<appWcfService.PEBODP>(paramOperacion.VALENT[0]);
                ///

                //////////////////////cambios para multiple
                ListaBolsas = Util.Deserialize<List<appWcfService.PEBODP>>(paramOperacion.VALENT[0]);
                //////////////////////

                partida = articulo = "";
                almacen = 0;

                //if (detallebolsa == null)
                //{
                //    Util.EscribeLog("detallebolsa es null");
                //}
                //else
                //{
                //    Util.EscribeLog("detallebolsa " + detallebolsa.BODPIDDP.ToString() + " " + detallebolsa.BODPIDDP.ToString());
                //}

                using (var context = new PEDIDOSEntities())
                {

                    foreach (var detallebolsa in ListaBolsas)///cambios para multiple
                    {
                        EFModelo.PEDEPE detpednac = null;
                        EFModelo.PEDEOS detpedint = null;
                        EFModelo.GMCAEM emp = null;
                        //inserta PBOLS si no existe
                        //var bol = context.PEBOLS.Find(detallebolsa.BODPIDBO);
                        bool sinempaque = string.IsNullOrWhiteSpace(detallebolsa.PEBOLS.BOLSCOEM);
                        if (!sinempaque)
                        {
                            emp = context.GMCAEM.FirstOrDefault(b => b.CAEMCIA == 1 && b.CAEMCOEM == detallebolsa.PEBOLS.BOLSCOEM);
                        }

                        if (emp != null || sinempaque)
                        {
                            EFModelo.PEBOLS bol = null;
                            if (!sinempaque)
                            {
                                bol = context.PEBOLS.FirstOrDefault(b => b.BOLSCOEM == detallebolsa.PEBOLS.BOLSCOEM); //.Find(bolsa.BOLSIDBO);

                                if (bol == null) //no existe pbols, insertar
                                {
                                    bol = new EFModelo.PEBOLS();
                                    //inserta = true;
                                    bol.BOLSCOEM = detallebolsa.PEBOLS.BOLSCOEM;
                                    bol.BOLSUSCR = detallebolsa.BODPUSCR;
                                    bol.BOLSFECR = DateTime.Now;
                                    bol.BOLSCOCA = null;
                                    bol.BOLSESTA = 1;
                                    bol.BOLSALMA = emp.CAEMALMA;
                                    bol.BOLSCOAR = "";
                                    Util.EscribeLog("3");

                                    context.PEBOLS.Add(bol);
                                    Util.EscribeLog("4");

                                    context.SaveChanges();
                                    Util.EscribeLog("5");

                                    detallebolsa.BODPIDBO = bol.BOLSIDBO;
                                }
                                else
                                {
                                    if (bol.BOLSALMA == 0)
                                    {
                                        bol.BOLSALMA = emp.CAEMALMA;
                                    }
                                }
                            }

                            if (detallebolsa.BODPDIFE <= 0 || detallebolsa.BODPSTCE == 1)
                            {
                                //bol.BOLSESTA = 9; //ya no se usa la bolsa, pero esta mal por detalle
                            }
                            //bool inserta = false;
                            //
                            if (detallebolsa.BODPIDDP.HasValue)
                            {
                                detpednac = context.PEDEPE.Find(detallebolsa.BODPIDDP);
                                partida = detpednac.DEPEPART;
                                articulo = detpednac.DEPECOAR;
                                almacen = detpednac.DEPEALMA;
                            }
                            else if (detallebolsa.BODPIDDO.HasValue)
                            {
                                detpedint = context.PEDEOS.Find(detallebolsa.BODPIDDO);
                                partida = detpedint.DEOSPART;
                                articulo = detpedint.DEOSCOAR;
                                almacen = detpedint.DEOSALMA;
                            }

                            //var ent = context.PEBODP.Find(detallebolsa.BODPIDDE);
                            var ent = context.PEBODP.FirstOrDefault(x => x.BODPIDDE == detallebolsa.BODPIDDE);

                            if (ent == null) //detallebolsa.BODPIDDE != 0)
                            {
                                ent = new EFModelo.PEBODP();
                                //inserta = true;
                                ent.BODPUSCR = detallebolsa.BODPUSCR;
                                ent.BODPFECR = DateTime.Now;
                                context.PEBODP.Add(ent);
                                if (!sinempaque)
                                {
                                    //inserta tipo 1 SALIDA
                                    insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, detallebolsa.BODPCANT, detallebolsa.BODPPESO, detallebolsa.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                                }
                            }
                            else
                            {
                                ent.BODPUSMO = detallebolsa.BODPUSCR;
                                ent.BODPFEMO = DateTime.Now;
                                ent.BODPESTA = 3;
                                if (!sinempaque)
                                {
                                    //SOLO si las cantidades o pesos son diferentes
                                    //inserta tipo 3 reingreso
                                    //inserta tipo 1 salida
                                    if (detallebolsa.BODPCANT != ent.BODPCANT || detallebolsa.BODPPESO != ent.BODPPESO)
                                    {
                                        insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_MODIFICA_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, ent.BODPCANT, ent.BODPPESO, ent.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                                        insertaMovimientoKardex(context, detallebolsa.BODPIDBO, TIPO_MOV_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, detallebolsa.BODPCANT, detallebolsa.BODPPESO, detallebolsa.BODPPEBR - detallebolsa.BODPTADE, detallebolsa.BODPUSCR, detallebolsa.BODPIDDP, detallebolsa.BODPIDDO);
                                    }
                                }
                            }
                            //automatizar el parse sin incluir la PK
                            ent.BODPIDBO = detallebolsa.BODPIDBO;
                            ent.BODPIDDP = detallebolsa.BODPIDDP; //detalle de pedido si es que no es null
                            ent.BODPALMA = almacen; //bol.BOLSALMA;
                            ent.BODPPART = partida;
                            ent.BODPCOAR = articulo;
                            ent.BODPCANT = detallebolsa.BODPCANT;
                            ent.BODPPESO = detallebolsa.BODPPESO;
                            ent.BODPPERE = detallebolsa.BODPPERE;
                            ent.BODPDIFE = detallebolsa.BODPDIFE;
                            ent.BODPSTCE = detallebolsa.BODPSTCE;
                            ent.BODPINBO = detallebolsa.BODPINBO;
                            ent.BODPIDDO = detallebolsa.BODPIDDO; //detalle de osa si es que no es null
                                                                  //2018-04-11
                            ent.BODPTAUN = detallebolsa.BODPTAUN;
                            //iddetpedido = ent.BODPIDDP;
                            //iddetpedidoint = ent.BODPIDDO;
                            if (detallebolsa.PEDEPE != null && detallebolsa.PEDEPE.DEPESTOC.HasValue)
                            {
                                iddetpedidostoc = detallebolsa.PEDEPE.DEPESTOC;
                            }

                            ent.BODPTADE = detallebolsa.BODPTADE;
                            ent.BODPPEBR = detallebolsa.BODPPEBR;
                            ent.BODPESTA = detallebolsa.BODPESTA;

                            context.SaveChanges(); //necesite guardar 1ro labolsa actual para luego recuperar todas las bolsas de la BD
                            decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            if (detallebolsa.BODPIDDP.HasValue)
                            {
                                var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDP == detallebolsa.BODPIDDP).ToList();
                                // decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                                cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                                foreach (var bolsaprep in listbolsas)
                                {
                                    cantatendida += bolsaprep.BODPCANT;
                                    pesoatendido += bolsaprep.BODPPESO;
                                    pesoreal += bolsaprep.BODPPERE;
                                    tade += bolsaprep.BODPTADE;
                                    pebr += bolsaprep.BODPPEBR;
                                }
                                //var detpednac = context.PEDEPE.Find(iddetpedido);
                                detpednac.DEPECAAT = cantatendida;
                                detpednac.DEPEPEAT = pesoatendido;
                                detpednac.DEPEPERE = pesoreal;
                                if (iddetpedidostoc.HasValue)
                                {
                                    detpednac.DEPESTOC = iddetpedidostoc;
                                }
                                detpednac.DEPETADE = tade;
                                detpednac.DEPEPEBR = pebr;

                                context.SaveChanges();
                            }
                            else if (detallebolsa.BODPIDDO.HasValue)
                            {
                                var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDO == detallebolsa.BODPIDDO).ToList();
                                //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                                cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                                foreach (var bolsaprep in listbolsas)
                                {
                                    cantatendida += bolsaprep.BODPCANT;
                                    pesoatendido += bolsaprep.BODPPESO;
                                    pesoreal += bolsaprep.BODPPERE;
                                    tade += bolsaprep.BODPTADE;
                                    pebr += bolsaprep.BODPPEBR;
                                }
                                //var detpedint = context.PEDEOS.Find(detallebolsa.BODPIDDO);
                                detpedint.DEOSCAAT = cantatendida;
                                detpedint.DEOSPEAT = pesoatendido;
                                detpedint.DEOSPERE = pesoreal;
                                if (iddetpedidostoc.HasValue)
                                {
                                    detpedint.DEOSSTOC = iddetpedidostoc;
                                }
                                detpedint.DEOSTADE = tade;
                                detpedint.DEOSPEBR = pebr;
                                //actualiza peso en osa ---PENDIENTE EN AS
                                var osa = context.PROSAS.Find(1, detpedint.DEOSFOLI, detpedint.DEOSSECU);
                                if (osa != null)
                                {
                                    osa.OSASCAEN = pesoatendido;
                                    actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, osa.OSASCAEN, ""); //Validar si es correcto
                                }
                                context.SaveChanges();
                            }
                            if (!sinempaque)
                            {
                                //actualiza el stock de la bolsa
                                var todasbolsasprep = context.PEBODP.Where(prep => prep.BODPIDBO == bol.BOLSIDBO && prep.BODPALMA == bol.BOLSALMA && prep.BODPPART == partida && prep.BODPCOAR == articulo).ToList();
                                //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                                cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                                foreach (var bolsaprep in todasbolsasprep)
                                {
                                    cantatendida += bolsaprep.BODPCANT;
                                    pesoatendido += bolsaprep.BODPPESO;
                                    pesoreal += bolsaprep.BODPPERE;
                                    tade += bolsaprep.BODPTADE;
                                    pebr += bolsaprep.BODPPEBR;
                                }
                                var detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMPART == partida && det.DEEMARTI == articulo && det.DEEMTIPE == "N");
                                if (detemp != null)
                                {
                                    //---PENDIENTE EN AS
                                    detemp.DEEMCAST = detemp.DEEMCANT - cantatendida;
                                    if (emp.CAEMMSPA == "+")
                                    {
                                        detemp.DEEMPEST = (detemp.DEEMPNET - detemp.DEEMDEST + detemp.DEEMACON) - pesoatendido;
                                    }
                                    else
                                    {
                                        detemp.DEEMPEST = (detemp.DEEMPNET - detemp.DEEMDEST + detemp.DEEMACON) - emp.CAEMDEEM - pesoatendido;
                                    }
                                    if (iddetpedidostoc.HasValue)
                                    {
                                        detemp.DEEMSTCE = iddetpedidostoc.Value;
                                    }
                                    if (detemp.DEEMSTCE == 1 || ent.BODPSTCE == 1)
                                    {
                                        detemp.DEEMESBO = 9;
                                    }
                                    else if (detemp.DEEMCAST <= 0 && detemp.DEEMPEST <= 0)
                                    {
                                        detemp.DEEMESBO = 9;
                                    }
                                    else
                                    {
                                        detemp.DEEMESBO = 1;
                                    }
                                    actualizaGMDEEM(detemp.DEEMCOEM, detemp.DEEMSECU, detemp.DEEMCAST, detemp.DEEMPEST, detemp.DEEMSTCE, detemp.DEEMESBO);
                                    context.SaveChanges();
                                    //buscar una partida en la bolsa que no este vacia, si no hay ninguna actualizar a 9 anulado
                                    detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMTIPE == "N" && det.DEEMESBO != 9);
                                    if (detemp == null)
                                    {
                                        bol.BOLSESTA = 9; //ya no se usa la bolsa
                                        actualizaGMCAEM(bol.BOLSCOEM, "B");
                                    }
                                    else
                                    {
                                        bol.BOLSESTA = 1; //ya no se usa la bolsa - si se modifica la cant o kilos de la bolsa o si se le quito el stock cero desmarcar la bolsa
                                        actualizaGMCAEM(bol.BOLSCOEM, "");
                                    }
                                    context.SaveChanges();
                                }
                            }
                            //vpar.VALSAL = new List<string>();
                            ////vpar.VALSAL.Add(ent.BODPIDDE.ToString());
                            ////vpar.VALSAL.Add(detallebolsa.BODPIDBO.ToString());
                            //resultado = ""; // ent.BODPIDDE.ToString();
                            //vpar.ESTOPE = true;
                        }
                        else
                        {
                            resultado = "Código de empaque incorrecto";
                        }
                    }
                }
                vpar.VALSAL = new List<string>();
                //vpar.VALSAL.Add(ent.BODPIDDE.ToString());
                //vpar.VALSAL.Add(detallebolsa.BODPIDBO.ToString());
                resultado = ""; // ent.BODPIDDE.ToString();
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        public RESOPE remueveBolsaPedidose(PAROPE paramOperacion)//decimal idbolsapedido, string usuario)
        {
            Nullable<decimal> iddetpedido;
            Nullable<decimal> iddetpedidoint;
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            string resultado = "";
            string partida, articulo;
            try
            {
                decimal idbolsapedido = decimal.Parse(paramOperacion.VALENT[0]);
                string usuario = paramOperacion.VALENT[1];

                partida = articulo = "";
                using (var context = new PEDIDOSEntities())
                {
                    EFModelo.PEDEPE detpednac = null;
                    EFModelo.PEDEOS detpedint = null;

                    //bool inserta = false;
                    //foreach (var item in collection)
                    //{

                    //}
                    var ent = context.PEBODP.Find(idbolsapedido);
                    if (ent != null) //detallebolsa.BODPIDDE != 0)
                    {
                        bool sinempaque = !ent.BODPIDBO.HasValue;
                        EFModelo.PEBOLS bol = null;
                        if (!sinempaque)
                        {
                            bol = context.PEBOLS.Find(ent.BODPIDBO);
                        }

                        if (ent.BODPIDDP.HasValue)
                        {
                            detpednac = context.PEDEPE.Find(ent.BODPIDDP);
                            partida = detpednac.DEPEPART;
                            articulo = detpednac.DEPECOAR;
                        }
                        else if (ent.BODPIDDO.HasValue)
                        {
                            detpedint = context.PEDEOS.Find(ent.BODPIDDO);
                            partida = detpedint.DEOSPART;
                            articulo = detpedint.DEOSCOAR;
                        }
                        iddetpedido = ent.BODPIDDP;
                        iddetpedidoint = ent.BODPIDDO;
                        //if (detallebolsa.BODPDIFE <= 0 || detallebolsa.BODPSTCE == 1)
                        //{
                        //bol.BOLSESTA = 1; //ya no se usa
                        //}
                        if (!sinempaque)
                        {
                            insertaMovimientoKardex(context, ent.BODPIDBO, TIPO_MOV_CANCELA_SALIDA_PREP_PED, bol.BOLSALMA, partida, articulo, ent.BODPCANT, ent.BODPPESO, ent.BODPPEBR - ent.BODPTADE, usuario, ent.BODPIDDP, ent.BODPIDDO);
                        }
                        context.PEBODP.Remove(ent);
                        context.SaveChanges();
                        decimal cantatendida, pesoatendido, pesoreal, tade, pebr;

                        if (iddetpedido.HasValue)
                        {
                            var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDP == iddetpedido).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in listbolsas)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            //detpednac = context.PEDEPE.Find(iddetpedido);
                            detpednac.DEPECAAT = cantatendida;
                            detpednac.DEPEPEAT = pesoatendido;
                            detpednac.DEPEPERE = pesoreal;
                            detpednac.DEPETADE = tade;
                            detpednac.DEPEPEBR = pebr;

                            //inserta tipo 2 kardex reingreso
                            context.SaveChanges();
                        }
                        else if (iddetpedidoint.HasValue)
                        {
                            var listbolsas = context.PEBODP.Where(ped => ped.BODPIDDO == iddetpedidoint).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in listbolsas)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            detpedint.DEOSCAAT = cantatendida;
                            detpedint.DEOSPEAT = pesoatendido;
                            detpedint.DEOSPERE = pesoreal;
                            detpedint.DEOSTADE = tade;
                            detpedint.DEOSPEBR = pebr;
                            //actualiza peso en osa ---PENDIENTE EN AS
                            var osa = context.PROSAS.Find(1, detpedint.DEOSFOLI, detpedint.DEOSSECU);
                            if (osa != null)
                            {
                                osa.OSASCAEN = pesoatendido;
                                actualizaPROSAS(osa.OSASFOLI, osa.OSASSECU, osa.OSASCAEN, ""); //Validar AS
                            }
                            context.SaveChanges();

                        }
                        if (!sinempaque)
                        {
                            //actualiza el stock de la bolsa
                            var todasbolsasprep = context.PEBODP.Where(prep => prep.BODPIDBO == bol.BOLSIDBO && prep.BODPALMA == bol.BOLSALMA && prep.BODPPART == partida && prep.BODPCOAR == articulo).ToList();
                            //decimal cantatendida, pesoatendido, pesoreal, tade, pebr;
                            cantatendida = pesoatendido = pesoreal = tade = pebr = 0;
                            foreach (var bolsaprep in todasbolsasprep)
                            {
                                cantatendida += bolsaprep.BODPCANT;
                                pesoatendido += bolsaprep.BODPPESO;
                                pesoreal += bolsaprep.BODPPERE;
                                tade += bolsaprep.BODPTADE;
                                pebr += bolsaprep.BODPPEBR;
                            }
                            var detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMPART == partida && det.DEEMARTI == articulo && det.DEEMTIPE == "N");
                            if (detemp != null)
                            {
                                detemp.DEEMCAST = detemp.DEEMCANT - cantatendida;
                                detemp.DEEMPEST = (detemp.DEEMPNET - detemp.DEEMDEST + detemp.DEEMACON) - pesoatendido;
                                //si la bolsa preparada estaba marcada como stock cero, lo desmarco
                                if (ent.BODPSTCE == 1)
                                {
                                    detemp.DEEMSTCE = 0;
                                }
                                if (detemp.DEEMSTCE == 0)
                                {
                                    detemp.DEEMESBO = 1;
                                }
                                else
                                if (detemp.DEEMCAST <= 0 && detemp.DEEMPEST <= 0)
                                {
                                    detemp.DEEMESBO = 9;
                                }
                                else
                                {
                                    detemp.DEEMESBO = 1;
                                }
                                context.SaveChanges();
                                actualizaGMDEEM(detemp.DEEMCOEM, detemp.DEEMSECU, detemp.DEEMCAST, detemp.DEEMPEST, detemp.DEEMSTCE, detemp.DEEMESBO); //Validar AS
                                                                                                                                                       //buscar una partida en la bolsa que no este vacia, si no hay ninguna actualizar a 9 anulado
                                detemp = context.GMDEEM.FirstOrDefault(det => det.DEEMCIA == 1 && det.DEEMCOEM == bol.BOLSCOEM && det.DEEMTIPE == "N" && det.DEEMESBO != 9);
                                if (detemp == null)
                                {
                                    bol.BOLSESTA = 9; //ya no se usa la bolsa
                                    actualizaGMCAEM(bol.BOLSCOEM, "B");
                                }
                                else
                                {
                                    bol.BOLSESTA = 1; //ya no se usa la bolsa - si se modifica la cant o kilos de la bolsa o si se le quito el stock cero desmarcar la bolsa
                                    actualizaGMCAEM(bol.BOLSCOEM, "");
                                }
                                context.SaveChanges();
                            }
                        }
                    }
                    vpar.ESTOPE = true;
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                resultado = ex.Message;
            }
            finally
            {
            }
            vpar.MENERR = resultado;
            return vpar;
        }

        public RESOPE ObtienePreparacionOsase(PAROPE paramOperacion)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            List<object> listaeo = null;
            List<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> lista = null;
            decimal idosa;
            try
            {
                idosa = decimal.Parse(paramOperacion.VALENT[0]);
                using (var context = new PEDIDOSEntities())
                {
                    listaeo = context.USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE(idosa).ToList<object>();
                }
                lista = Util.ParseEntityObject<appWcfService.USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>(listaeo);
                vpar.VALSAL = new List<string>();
                if (lista.Count > 0)
                {
                    vpar.VALSAL.Add("1");
                    vpar.VALSAL.Add(Util.Serialize(lista));
                }
                else
                {
                    vpar.VALSAL.Add("0");

                }
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        public RESOPE ObtienePecaos(string folio)
        {
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };

            object pecaos = null;
            appWcfService.PECAOS odto = null;
            //string folio;
            try
            {
                //folio = paramOperacion.VALENT[0];
                using (var context = new PEDIDOSEntities())
                {
                    pecaos = context.PECAOS.SingleOrDefault(p => p.CAOSFOLI == folio);
                }
                odto = Util.ParseEntityObject<appWcfService.PECAOS>(pecaos);
                vpar.VALSAL = new List<string>();
                vpar.VALSAL.Add(Util.Serialize(odto));
                vpar.ESTOPE = true;

            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
            }
            return vpar;
        }

        #endregion

        /// </summary>

        public void Finaliza()
        {
            //DB2 = null;
        }

        private string ErrorGenerico(string exception)
        {
            if (OcultaErrorReal)
            {
                return Mensajes.MENSAJE_ERROR_GENERICO;
            }
            else
            {
                return exception;
            }
        }

        //BORRAR


        //

    }
}
