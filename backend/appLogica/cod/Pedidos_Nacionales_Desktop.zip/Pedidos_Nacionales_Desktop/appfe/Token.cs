﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace appfe
{
    public class Token
    {
        public static string security { get; set; }
    }
}
