﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace appFew.dto
{
    public class RhUbig
    {
        public string UbigDep { get; set; }
        public string UbigPro { get; set; }
        public string UbigDis { get; set; }
        public string UbigDes { get; set; }
    }
}