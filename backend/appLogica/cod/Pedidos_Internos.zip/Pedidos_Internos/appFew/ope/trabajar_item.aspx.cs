﻿using appConstantes;
using appFew.appServicio;
using appWcfService;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace appFew.ope
{
    public partial class trabajar_item : System.Web.UI.Page
    {
        private static ParametrosFe _ParametrosIni;

       

        //////////
        /////////

        //private bool Cargando = false;
        protected void Page_Load(object sender, EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];

            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);

                //Response.Redirect("../login.aspx");
            }
            else
            {
                this.Form.DefaultButton = this.agregarbutton.UniqueID;
                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();
                    if (!Page.IsPostBack)
                    {
                        
                        if (Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] != null)
                        {
                            detaOsa = (USP_OBTIENE_DETALLE_OSA_Result)Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER];

                            RFolioLabel.Text = "FOLIO: " + detaOsa.OSASFOLI;
                            RSolicitadoLabel.Text = "P. SOLICITADO: " + detaOsa.OSASCASO.ToString() + "KG";
                            RPartidaLabel.Text = "PARTIDA: " + detaOsa.OSASPAOR;
                            RDiferenciaLabel.Text = "DIFERENCIA: " + (detaOsa.OSASCASO - detaOsa.DEOSPEAT).ToString() + "KG";
                            Almacen.Text = "ALMACEN: " + detaOsa.OSASALMA.ToString();

                            if (detaOsa.DEOSSTOC == 1)
                            {
                                stockcheckbox.Checked = true; 
                            }
                        }
                        CargaDatosIniciales();
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }


        #region Variables
        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;

        private string url = string.Empty;
        decimal incluyestock, incluyebolsa;

        USP_OBTIENE_DETALLE_OSA_Result detaOsa = new USP_OBTIENE_DETALLE_OSA_Result();

        private bool multiple
        {
            get
            {
                bool multi = Boolean.Parse(Session[Constantes.NOMBRE_SESION_MULTIPLE].ToString());
                return multi;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_MULTIPLE] = value;
            }
        }
        private decimal Fintotcant
        {
            get
            {
                decimal Fintot = Decimal.Parse(Session[Constantes.NOMBRE_SESION_CANTIDAD_TOTAL].ToString());
                return Fintot;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_CANTIDAD_TOTAL] = value;
            }
        }

        private decimal pcono
        {
            get
            {
                decimal Fintot = Decimal.Parse(Session[Constantes.NOMBRE_SESION_PESO_CONO].ToString());
                return Fintot;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_PESO_CONO] = value;
            }
        }

        private decimal pbolsa
        {
            get
            {
                decimal Fintot = Decimal.Parse(Session[Constantes.NOMBRE_SESION_PESO_BOLSA].ToString());
                return Fintot;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_PESO_BOLSA] = value;
            }
        }

        private List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> DetalleBolsas
        {
            get
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> dt = Session[Constantes.NOMBRE_SESION_DETALLE_BOLSA] as List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneBolsaDefault();

                    DetalleBolsas = dt;
                }
                return dt;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_DETALLE_BOLSA] = value;
            }
        }

        private List<USP_OBTIENE_UBICACIONES_Result> Ubicaciones
        {
            get
            {
                List<USP_OBTIENE_UBICACIONES_Result> dt = Session[Constantes.NOMBRE_SESION_UBICACIONES] as List<USP_OBTIENE_UBICACIONES_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneUbicacionesDefault();

                    Ubicaciones = dt;
                }
                return dt;
            }
            set
            {
                Session[Constantes.NOMBRE_SESION_UBICACIONES] = value;
            }
        }

        private List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> ObtieneBolsaDefault()
        {
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> datos = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();
            datos.Add(new USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result() { DEOSIDDO = -1 });
            return datos;
        }


        private List<USP_OBTIENE_UBICACIONES_Result> ObtieneUbicacionesDefault()
        {
            List<USP_OBTIENE_UBICACIONES_Result> datos = new List<USP_OBTIENE_UBICACIONES_Result>();
            datos.Add(new USP_OBTIENE_UBICACIONES_Result() { UBICCANT = 0 });
            return datos;
        }

        #endregion

        #region Eventos
        protected void trabajaritemGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }

        }

        protected void trabajaritemGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

                if (detConsumo != null && detConsumo[0].BOLSCOEM != null)
                {
                    int indexSelect = 0;
                    indexSelect = trabajaritemGridView.SelectedIndex;

                    if (indexSelect != -1)
                    {
                        GridViewRow row = trabajaritemGridView.SelectedRow;

                        if (row != null)
                        {
                            string corrLiq = row.Cells[0].Text;
                            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = detConsumo.Find(x => x.BOLSCOEM == corrLiq);
                            if (detalle == null)
                            {
                                detalle = detConsumo.Find(x => x.BOLSCOEM == "");
                            }
                            mensajemodal.Show();
                            multiple = false;
                            llena_modal(detalle);
                        }
                        else
                        {
                            iddeHiddenFieldConsumo.Value = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void trabajaritemGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (trabajaritemGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = trabajaritemGridView.Rows[trabajaritemGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = trabajaritemGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void trabajaritemGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("&nbsp;") || !e.Row.Cells[1].Text.Equals("&nbsp;"))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(trabajaritemGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[5].Text = "";
                    e.Row.Cells[6].Text = "";
                }
            }
        }

        protected void guardarbutton_Click(object sender, EventArgs e)
        {
            //mensajemodal.Show();

            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> listbolsas = DetalleBolsas;
            try
            {
                bool flag = true;
                if (Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] != null)
                {
                    detaOsa = (USP_OBTIENE_DETALLE_OSA_Result)Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER];
                    List<PEBODP> ListaBolsas = new List<PEBODP>();

                    foreach (var item in listbolsas)
                    {
                        PEBODP bodp = new PEBODP();
                        bodp.BODPIDDE = item.BODPIDDE;
                        bodp.PEBOLS = new PEBOLS();
                        if (!string.IsNullOrWhiteSpace(item.BOLSCOEM))
                        {
                            bodp.BODPIDBO = item.BOLSIDBO;
                            bodp.PEBOLS.BOLSCOEM = item.BOLSCOEM;
                        }
                        else
                        {
                            bodp.PEBOLS.BOLSCOEM = null;
                        }
                        bodp.BODPIDDO = detaOsa.DEOSIDDO;
                        bodp.BODPCANT = item.BODPCANT;
                        bodp.BODPPESO = item.BODPPESO;
                        bodp.BODPUSCR = _ParametrosIni.Usuario;
                        bodp.BODPPERE = item.BODPPERE;
                        bodp.BODPSTCE = item.BODPSTCE;
                        bodp.BODPINBO = item.BODPINBO;
                        bodp.BODPDIFE = item.BODPDIFE;
                        bodp.BODPTADE = item.BODPTADE;
                        bodp.BODPPEBR = item.BODPPEBR;
                        bodp.BODPESTA = item.BODPESTA;

                        bodp.BODPTAUN = item.BODPTAUN;

                        bodp.PEDEPE = new PEDEPE();
                        bodp.PEDEPE.DEPESTOC = (stockcheckbox.Checked == true) ? 1 : 0;

                        ListaBolsas.Add(bodp);
                        //if (!guardaPreparacionBolsa(bodp))
                        //{
                        //    flag = false;
                        //    break;
                        //}
                    }
                    guardaPreparacionBolsa(ListaBolsas);
                }

                //if (flag)
                //{
                //    MostrarMensaje("Se ha guardado correctamente.");
                //    cargaDatos();
                //}
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                //MostrarMensaje("No se puede guardar la preparación actual");
            }

        }

        protected void agregarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

                if (detConsumo != null && detConsumo[0].BOLSCOEM != null && detConsumo[0].BOLSARTI != null)
                {
                    agrega(false);
                }
                else
                {
                    //trabajaritemGridView.DeleteRow(-1);
                    agrega(true);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void eliminarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

                if (detConsumo != null && detConsumo[0].BOLSCOEM != null)
                {
                    int indexSelect = 0;
                    indexSelect = trabajaritemGridView.SelectedIndex;

                    if (indexSelect != -1)
                    {
                        GridViewRow row = trabajaritemGridView.SelectedRow;

                        if (row != null)
                        {
                            string corrLiq = row.Cells[0].Text;
                            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = detConsumo.Find(x => x.BOLSCOEM == corrLiq);
                            if (detalle == null)
                            {
                                detalle = detConsumo.Find(x => x.BOLSCOEM == "");
                            }
                            if (RemueveBolsa(detalle.BODPIDDE.ToString()))
                            {
                                //trabajaritemGridView.DeleteRow(indexSelect);
                                detConsumo.Remove(detalle);
                                if (detConsumo.Count < 1)
                                {
                                    SetDataSourceBolsas(null);
                                }
                                else
                                {
                                    SetDataSourceBolsas(detConsumo);
                                }
                                MostrarMensaje("Se ha eliminado la bolsa");
                                CargaUbicaciones();
                                totaliza();
                            }
                        }
                        else
                        {
                            iddeHiddenFieldConsumo.Value = "";
                        }
                    }
                    else
                        MostrarMensaje("Debe seleccionar una bolsa.");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void trabajaritemGridView_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            //cargaDatos();
            
        }

        protected void PesadomultipleButton_Click(object sender, EventArgs e)
        {
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

                if (detConsumo.Count >= 2 && detConsumo[0].BOLSCOEM != null)
                {
                    mensajemodal.Show();
                    multiple = true;
                    llena_modal_multi(detConsumo);
                }
                else
                {
                    MostrarMensaje("Debe tener mas de una bolsa.");
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void AtrasButton_Click(object sender, EventArgs e)
        {
            //Response.Redirect("../ope/pendientes.aspx");
            MostrarMensaje("");
            Response.Redirect("../ope/atenderosa.aspx");

        }

        protected void taradesTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double taradespa = 0; //taradespacho
                double pesobruto = 0;
                double tara = 0;
                double pesoneto = 0;
                try
                {
                    taradespa = Double.Parse(taradesTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    taradespa = 0;
                }
                try
                {
                    pesobruto = Double.Parse(pbrutoTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    pesobruto = 0;
                }
                try
                {
                    tara = Double.Parse(taraTextBox.Text.ToString());
                }
                catch (Exception ) {
                    tara = 0;
                }
                //pesobruto = pesobruto + taradespa;
                //pbfinalTextBox.Text = Math.Round(pesobruto, 3).ToString();

                pesoneto = Math.Round(pesobruto - tara - taradespa, 3);
                pnrealTextBox.Text = Math.Round(pesoneto, 2).ToString();
                pnmodificadoTextBox.Text = Math.Round(pesoneto, 2).ToString();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pnmodificadoTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pbrutoTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                double tara = 0;
                double value, taradesp;
                double pesoneto;
                try
                {
                    value = Double.Parse(pbrutoTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    value = 0;
                }
                try
                {
                    taradesp = Double.Parse(taradesTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    taradesp = 0;
                }

                tara = Double.Parse(taraTextBox.Text.ToString());
                pesoneto = value - tara - taradesp;

                pnrealTextBox.Text = (Math.Round(pesoneto, 2)).ToString();
                pnmodificadoTextBox.Text = (Math.Round(pesoneto, 2)).ToString();
                pbfinalTextBox.Text = Math.Round(value, 2).ToString();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void cantidadTextBox_TextChanged(object sender, EventArgs e)
        {
            //USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = seleccionado();
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

            //pcono = detalle.UNIDTARA;
            //pbolsa = detalle.TIEMTARA;
            int cantlista = detConsumo.Count;
            try
            {
                decimal tara = 0;
                double pesoneto;
                decimal value = 0; //cantidad
                double pesobruto = 0;
                double taradespa = 0;

                if (IncluirbCheckBox.Checked)
                {
                    incluyebolsa = 1;
                }
                else
                {
                    incluyebolsa = 0;
                }
                try
                {
                    value = Decimal.Parse(cantidadTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    value = 0;
                }
                try
                {
                    pesobruto = Double.Parse(pbrutoTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    pesobruto = 0;
                }
                try
                {
                    taradespa = Double.Parse(taradesTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    taradespa = 0;
                }
                if (multiple)
                {
                    tara = Math.Round(pcono,3) * value + (pbolsa * incluyebolsa * (cantlista));
                    pesoneto = pesobruto - Double.Parse(tara.ToString()) - taradespa;
                }
                else
                {
                    tara = Math.Round(pcono, 3) * value + (pbolsa * incluyebolsa);
                    pesoneto = pesobruto - Double.Parse(tara.ToString()) - taradespa;
                }

                taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();
                pnrealTextBox.Text = (Math.Round(pesoneto, 2)).ToString();
                pnmodificadoTextBox.Text = pnrealTextBox.Text.ToString();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void IncluirbCheckBox_CheckedChanged(object sender, EventArgs e)
        {
            //USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = seleccionado();
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

            //pcono = detalle.UNIDTARA;
            //pbolsa = detalle.TIEMTARA;
            int cantlista = detConsumo.Count;
            try
            {
                CheckBox cb = sender as CheckBox;
                if (cb.Checked)
                {
                    incluyebolsa = 1;
                }
                else
                {
                    incluyebolsa = 0;
                }
                decimal tara = 0;
                double pesoneto;
                decimal value = 0; //cantidad
                double pesobruto = 0;
                double taradespa = 0;

                try
                {
                    value = Decimal.Parse(cantidadTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    value = 0;
                }
                try
                {
                    pesobruto = Double.Parse(pbrutoTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    pesobruto = 0;
                }
                try
                {
                    taradespa = Double.Parse(taradesTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    taradespa = 0;
                }

                if (multiple)
                {
                    tara = Math.Round(pcono, 3) * value + (pbolsa * incluyebolsa * (cantlista));
                    pesoneto = pesobruto - Double.Parse(tara.ToString()) - taradespa;

                    taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();

                }
                else
                {
                    tara = Math.Round(pcono, 3) * value + (pbolsa * incluyebolsa);
                    pesoneto = pesobruto - Double.Parse(tara.ToString()) - taradespa;

                    taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();

                }

                pnrealTextBox.Text = (Math.Round(pesoneto, 2)).ToString();
                pnmodificadoTextBox.Text = pnrealTextBox.Text.ToString();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void Stock0CheckBox_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                decimal cantidadbolsa;
                USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = seleccionado();

                cantidadbolsa = detalle.BOLSCANT.Value;

                if (Stock0CheckBox.Checked)
                {
                    if (multiple == true)
                    {
                        if ((Fintotcant - Decimal.Parse(cantidadTextBox.Text.ToString())) <= 0)
                        {
                            Stock0CheckBox.Checked = true;
                        }
                        else
                        {
                            MostrarMensaje("Aún hay existencias en la bolsa");//, ¿Desea activar la casilla de  Stock 0?.
                            Stock0CheckBox.Checked = false;
                        }
                    }
                    else
                    {
                        if ((cantidadbolsa - Decimal.Parse(cantidadTextBox.Text.ToString())) <= 0)
                        {
                            Stock0CheckBox.Checked = true;
                        }
                        else
                        {
                            MostrarMensaje("Aún hay existencias en la última bolsa");
                            Stock0CheckBox.Checked = false;
                        }
                    }
                }
            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void mcancelarButton_Click(object sender, EventArgs e)
        {
            try
            {
                //mensajemodal.Hide();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void maceptarButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (multiple == true)
                {
                    editapesomulti();
                }
                else
                {
                    editapeso();
                }
                totaliza();
                //mensajemodal.Hide();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void btnparcial_Click(object sender, EventArgs e)
        {
            modalPreparadas.Show();
        }

        protected void mcancelar_Click(object sender, EventArgs e)
        {

        }

        protected void maceptar_Click(object sender, EventArgs e)
        {

        }

        protected void taraTextBox_TextChanged(object sender, EventArgs e)
        {
            try
            {
                //if (CheckBoxModificable.Checked)
                //{
                decimal tara = 0;
                decimal pesoneto;
                //decimal value = 0; //cantidad
                decimal pesobruto = 0;
                decimal taradesp = 0;
                try
                {
                    tara = Decimal.Parse(taraTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    tara = 0;
                }
                try
                {
                    pesobruto = Decimal.Parse(pbrutoTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    pesobruto = 0;
                }
                try
                {
                    taradesp = Decimal.Parse(taradesTextBox.Text.ToString());
                }
                catch (Exception)
                {
                    taradesp = 0;
                }

                //if (multiple)
                //{
                //    tara = pcono * value + (pbolsa * incluyebolsa * (cantlista));
                //    pesoneto = pesobruto - Double.Parse(tara.ToString());

                //    taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();

                //}
                //else
                //{
                //tara = pcono * value + (pbolsa * incluyebolsa);
                pesoneto = pesobruto - tara - taradesp;

                //taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();

                //}

                pnrealTextBox.Text = (Math.Round(pesoneto, 3)).ToString();
                pnmodificadoTextBox.Text = pnrealTextBox.Text.ToString();
                //}

            }
            catch (Exception)
            {

                throw;
            }
        }

        protected void taraconoTextBox_TextChanged(object sender, EventArgs e)
        {
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;
            decimal tara = 0;
            decimal tara_cono = 0;
            decimal cantidad = 0;
            double pesobruto = 0;
            double taradespa = 0;
            double pesoneto = 0;
            int cantlista = detConsumo.Count;

            if (IncluirbCheckBox.Checked)
            {
                incluyebolsa = 1;
            }
            else
            {
                incluyebolsa = 0;
            }

            try
            {
                tara_cono = Decimal.Parse(taraconoTextBox.Text.ToString());
            }
            catch (Exception)
            {
                tara_cono = 0;
            }
            try
            {
                cantidad = Decimal.Parse(cantidadTextBox.Text.ToString());
            }
            catch (Exception)
            {
                cantidad = 0;
            }
            try
            {
                pesobruto = Double.Parse(pbrutoTextBox.Text.ToString());
            }
            catch (Exception)
            {
                pesobruto = 0;
            }
            try
            {
                taradespa = Double.Parse(taradesTextBox.Text.ToString());
            }
            catch (Exception)
            {
                taradespa = 0;
            }
            if (multiple)
            {
                tara = tara_cono * cantidad + (pbolsa * incluyebolsa * (cantlista));
            }
            else
            {
                tara = tara_cono * cantidad + (pbolsa * incluyebolsa);
            }
            pesoneto = pesobruto - Double.Parse(tara.ToString()) - taradespa;

            tara = Math.Round(tara, 3);
            pcono = tara_cono;
            taraTextBox.Text = (Math.Round(Double.Parse(tara.ToString()), 3)).ToString();
            pnrealTextBox.Text = (Math.Round(pesoneto, 2)).ToString();
            pnmodificadoTextBox.Text = pnrealTextBox.Text.ToString();

        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("&nbsp;") && !e.Row.Cells[0].Text.Equals("&nbsp;"))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(trabajaritemGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[5].Text = "";
                    e.Row.Cells[6].Text = "";
                }
            }
        }

        /*protected void CheckBoxModificable_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                CheckBox cb = sender as CheckBox;
                if (cb.Checked)
                {
                    taraTextBox.Enabled = true;
                }
                else
                {
                    taraTextBox.Enabled = false;
                }

            }
            catch (Exception)
            {

                throw;
            }
        }*/

        protected void BtnSinEmpaque_Click(object sender, EventArgs e)
        {
            detaOsa = (USP_OBTIENE_DETALLE_OSA_Result)Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER];
            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result objdet = new USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result();
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;
            var bolsa = detConsumo.Find(x => x.BOLSCOEM == "");
            if (bolsa == null)
            {
                if (detConsumo == null || detConsumo[0].BOLSCOEM == null)
                {
                    detConsumo = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();
                }

                objdet.DEOSIDDO = null;
                //objdet.BOLSIDBO = 0;
                objdet.BOLSCOEM = "";
                objdet.BOLSARTI = detaOsa.OSASARTI;
                objdet.BOLSPART = detaOsa.OSASPAOR;
                objdet.BOLSALMA = detaOsa.OSASALMA;
                objdet.BOLSCANT = 0;
                objdet.BOLSPESO = 0;
                objdet.TIEMTARA = 0.1M;
                objdet.UNIDTARA = 0;
                objdet.BODPCANT = 0;
                objdet.BODPPESO = 0;
                objdet.BODPPERE = 0;
                objdet.BODPPEBR = 0;
                objdet.BODPESTA = 3;
                objdet.BODPTAUN = 0;//tara cono modificable
                objdet.BODPINBO = 0; //check incluye bolsa

                detConsumo.Add(objdet);

                SetDataSourceBolsas(detConsumo);
                empaquetextbox.Text = "";
                totaliza();
            }
            else
            {
                MostrarMensaje("Solo puede ingresar una vez una bolsa sin empaque");
            }
        }

        #endregion

        #region Metodos
        private void CargaDatosIniciales()
        {
            InicializaDatos();
            CargaBolsasGuardadas(detaOsa.DEOSIDDO.ToString());
            CargaUbicaciones();
            totaliza();
        }

        private void InicializaDatos()
        {
            SetDataSourceBolsas(null);
            SetDataSourceUbicaciones(null);
            SetDataSourceGuardadas(null);
        }

        public void CargaUbicaciones()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MOSTRAR_UBICACION;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                //parEnt.Add(_ParametrosIni.Usuario);
                parEnt.Add(detaOsa.OSASARTI);
                parEnt.Add(detaOsa.OSASPAOR);
                parEnt.Add(detaOsa.OSASALMA.ToString());
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);

                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_UBICACIONES_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_UBICACIONES_Result>>(resultado.VALSAL[1]);

                        SetDataSourceUbicaciones(datos);
                    }
                    else
                    {
                        SetDataSourceUbicaciones(null);
                    }

                }
                else
                {
                    SetDataSourceUbicaciones(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        public void CargaBolsasGuardadas(string iddo)
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_PREPARACIONOSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(iddo);
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        //List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> datos = appWcfService.Utils.Deserialize<List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>>(resultado.VALSAL[1]);
                        //List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> listplanta = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>();
                        //List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result> listenprepa = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result>();
                        List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> datos = appWcfService.Utils.Deserialize<List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>>(resultado.VALSAL[1]);
                        List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> listplanta = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();
                        List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> listenprepa = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();

                        foreach (var item in datos)
                        {
                            if (item.BOLSCOEM == null)
                            {
                                item.BOLSCOEM = "";
                            }
                            if (item.BODPESTA == 5 || item.BODPESTA == 4)
                            { 
                                listplanta.Add(item);
                            }
                            else
                            {
                                listenprepa.Add(item);
                            }
                        }
                        if (listplanta.Count != 0)
                        {
                            SetDataSourceGuardadas(listplanta);
                        }
                        else
                        {
                            SetDataSourceGuardadas(null);
                        }
                        if (listenprepa.Count != 0)
                        {
                            SetDataSourceBolsas(listenprepa);
                        }
                        else
                        {
                            SetDataSourceBolsas(null);
                        }
                    }
                    else
                    {
                        SetDataSourceBolsas(null);
                    }

                }
                else
                {
                    SetDataSourceBolsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        public void CargaBolsa(string iddo, bool nuevo)
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_BOLSA_OSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(iddo);
                parEnt.Add(empaquetextbox.Text.ToString());
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_BOLSA_OSA_Result> datos = appWcfService.Utils.Deserialize<List<USP_OBTIENE_BOLSA_OSA_Result>>(resultado.VALSAL[1]);
                        List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> listbolsas;
                        if (nuevo)
                        {
                            listbolsas = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();
                        }
                        else
                        {
                            listbolsas = DetalleBolsas;
                        }
                        foreach (var item in datos)
                        {
                            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result objdet = new USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result();

                            objdet.DEOSIDDO = item.DEOSIDDO;
                            objdet.BOLSIDBO = item.BOLSIDBO;
                            objdet.BOLSCOEM = item.BOLSCOEM;
                            //objdet.BOLSCOCA = item.BOLSCOCA;
                            objdet.BOLSARTI = item.BOLSARTI;
                            objdet.BOLSPART = item.BOLSPART;
                            objdet.BOLSALMA = item.BOLSALMA;
                            objdet.BOLSCANT = item.BOLSCANT;
                            objdet.BOLSPESO = item.BOLSPESO;
                            objdet.TIEMTARA = item.TIEMTARA;
                            objdet.UNIDTARA = item.UNIDTARA;
                            objdet.BODPCANT = item.BOLSCANT;
                            objdet.BODPPESO = Math.Round(item.BOLSPESO, 2);
                            objdet.BODPPERE = Math.Round(item.BOLSPESO,2);
                            objdet.BODPPEBR = Math.Round((((item.UNIDTARA * objdet.BODPCANT) + objdet.BODPPESO) + item.TIEMTARA),2);
                            objdet.BODPESTA = 3;
                            objdet.BODPTAUN = item.UNIDTARA;//tara cono modificable
                            objdet.BODPINBO = 1; //check incluye bolsa

                            //var bolsa = listbolsas.Find(x => x.BOLSCOEM == objdet.BOLSCOEM);
                            //if (bolsa == null)
                            //{
                            listbolsas.Add(objdet);
                            //}
                            //else
                            //{
                            //    MostrarMensaje("Ya se ha ingresado el código de empaque, por favor ingrese un código de empaque diferente.");
                            //}
                        }
                        SetDataSourceBolsas(listbolsas);
                        empaquetextbox.Text = "";
                    }
                    else
                    {
                        MostrarMensaje("El empaque ingresado es incorrecto");
                    }
                }
                else
                {
                    SetDataSourceBolsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }

        protected void agrega(bool nuevo)
        {
            if (Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] != null)
            {
                detaOsa = (USP_OBTIENE_DETALLE_OSA_Result)Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER];
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> listbolsas = DetalleBolsas;
                var bolsa = listbolsas.Find(x => x.BOLSCOEM == empaquetextbox.Text.ToString());
                if (bolsa == null)
                {
                    CargaBolsa(detaOsa.DEOSIDDO.ToString(), nuevo);
                    CargaUbicaciones();
                    totaliza();
                }
                else
                {
                    MostrarMensaje("Ya se ha ingresado el código de empaque, por favor ingrese un código de empaque diferente.");
                }

            }
        }

        protected bool RemueveBolsa(string idde)
        {
            IappServiceClient clt = null;
            bool elimina = false;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.ELIMINA_BOLSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(idde);
                parEnt.Add(_ParametrosIni.Usuario);
                parEnt.Add(empaquetextbox.Text.ToString());

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    elimina = true;
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    elimina = false;
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                return elimina;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return elimina;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        protected void guardaPreparacionBolsa(List<PEBODP> bolsa)
        {

            bool resultadoOpe;
            IappServiceClient clt = null;
            //resultadoOpe = false;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GUARDA_BOLSA;
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(bolsa));

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);

                if (resultado.ESTOPE)
                {

                    //MessageBox.Show("Se ha guardado correctamente.", "Guardado", MessageBoxButton.OK, MessageBoxImage.Information);
                    //Double idprep = Double.Parse(resultado.VALSAL[0]);
                    //bolsa.BODPIDDE = Decimal.Parse(idprep.ToString());
                    //resultadoOpe = true;
                    MostrarMensaje("Se ha guardado correctamente.");
                    cargaDatos();
                }
                else
                {
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
            //return resultadoOpe;
        }

        protected void cargaDatos()
        {
            if (Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] != null)
            {
                detaOsa = (USP_OBTIENE_DETALLE_OSA_Result)Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER];
            }
            CargaBolsasGuardadas(detaOsa.DEOSIDDO.ToString());
            CargaUbicaciones();
        }

        protected void editapeso()
        {
            decimal cantidad, pesomodif, pesoreal, pesobolsa, taradesp, pesobruto, taun ;
            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = seleccionado();
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;


            try
            {
                if (IncluirbCheckBox.Checked)
                {
                    incluyebolsa = 1;
                }
                else
                {
                    incluyebolsa = 0;
                }
                if (Stock0CheckBox.Checked)
                {
                    incluyestock = 1;
                }
                else
                {
                    incluyestock = 0;
                }
                cantidad = Decimal.Parse(cantidadTextBox.Text.ToString());
                pesomodif = Decimal.Parse(pnmodificadoTextBox.Text.Equals("") ? "0" : pnmodificadoTextBox.Text.ToString());
                pesoreal = Decimal.Parse(pnrealTextBox.Text.ToString());
                pesobolsa = detalle.BOLSPESO.Value;
                taradesp = Decimal.Parse(taradesTextBox.Text.Equals("") ? "0" : taradesTextBox.Text.ToString());
                pesobruto = Decimal.Parse(pbrutoTextBox.Text.ToString());
                taun = Decimal.Parse(taraconoTextBox.Text.ToString());
                //selected.setBODPTAUN(taracono);

                detalle.BODPCANT = Math.Round(cantidad, 2);
                detalle.BODPPESO = Math.Round(pesomodif, 2);
                detalle.BODPPERE = Math.Round(pesoreal, 2);
                detalle.BODPSTCE = Math.Round(Decimal.Parse(incluyestock.ToString()), 3);
                detalle.BODPINBO = Math.Round(Decimal.Parse(incluyebolsa.ToString()), 3);
                detalle.BODPDIFE = Math.Round(pesobolsa - pesomodif, 3);//PESO DE LA BOLSA - PESO NETO MOODIFICADO
                detalle.BODPPEBR = Math.Round(pesobruto, 2);//(bruto + taraempaque);
                detalle.BODPTADE = Math.Round(taradesp, 3);// (taraempaque);
                detalle.BODPTAUN = Math.Round(taun, 3);// (taraempaque);
                SetDataSourceBolsas(detConsumo);

            }
            catch (Exception)
            {
                MostrarMensaje("Las cantidades ingresadas no son correctas");
                //MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void editapesomulti()
        {
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;
            int cantlista = detConsumo.Count - 1;
            try
            {
                bool checkbols = false;
                //if (stock0checkbox.IsChecked == true) check0 = true;
                if (IncluirbCheckBox.Checked == true) checkbols = true;
                //int count = 0;
                ////

                decimal fincant, finbrutofin, finreal, finpemodif, taraempaque, taracono;

                fincant = Decimal.Parse(cantidadTextBox.Text.ToString());
                finbrutofin = Decimal.Parse(pbfinalTextBox.Text.ToString());
                finreal = Decimal.Parse(pnrealTextBox.Text.ToString());
                finpemodif = Decimal.Parse(pnmodificadoTextBox.Text.ToString());
                taraempaque = Decimal.Parse(taradesTextBox.Text.ToString());
                taracono = Decimal.Parse(taraconoTextBox.Text.ToString());

                ////

                if (true)//Fintotcant >= Decimal.Parse(cantidadTextBox.Text.ToString()))
                {
                    foreach (var item in detConsumo)
                    {
                        //count++;
                        //if (count != cantlista)
                        //{
                        pcono = item.UNIDTARA.Value;
                        pbolsa = item.TIEMTARA.Value;
                        if (pcono != taracono)
                        {
                            pcono = taracono;
                        }

                        decimal taracal, brutocal;
                        taracal = Math.Round(pcono,3) * item.BODPCANT + (pbolsa * incluyebolsa); //taracal = round(taracal, 3);¿?

                        brutocal = item.BODPPESO + taracal; //
                        brutocal = Math.Round(brutocal, 2);//¿?

                        if (checkbols) item.BODPINBO = 1;
                        else item.BODPINBO = 0;

                        item.UNIDTARA = pcono;

                        if (fincant > 0)
                        {
                            if (fincant <= item.BODPCANT)
                            {
                                item.BODPCANT = Math.Round(fincant, 2);
                            }
                            fincant = fincant - item.BODPCANT;
                        }
                        else
                        {
                            item.BODPCANT = fincant;
                        }

                        if (finreal > 0)
                        {
                            if (finreal <= item.BODPPERE)
                            {
                                item.BODPPERE = Math.Round(brutocal, 2);
                            }
                            finreal = finreal - brutocal;
                        }
                        else
                        {
                            item.BODPPERE = finreal;
                        }

                        if (finbrutofin > 0)
                        {
                            if (finbrutofin <= item.BODPPEBR)
                            {
                                item.BODPPEBR = Math.Round(finbrutofin, 2);
                            }
                            finbrutofin = finbrutofin - item.BODPPEBR;
                        }
                        else
                        {
                            item.BODPPEBR = finbrutofin;
                        }

                        if (finpemodif > 0)
                        {
                            if (finpemodif <= item.BODPPESO)
                            {
                                item.BODPPESO = Math.Round(finpemodif, 2);
                            }
                            finpemodif = finpemodif - item.BODPPESO;
                        }
                        else
                        {
                            item.BODPPESO = Math.Round(finpemodif, 2);
                            //if (finpemodif == 0) count = cantlista;
                        }
                        //}
                        //else
                        //{
                        //}
                    }
                    //SOLO LA ULTIMA
                    detConsumo[cantlista].BODPTADE = Math.Round(taraempaque, 2);


                    detConsumo[cantlista].BODPPEBR = detConsumo[cantlista].BODPPEBR + finbrutofin;
                    detConsumo[cantlista].BODPPESO = detConsumo[cantlista].BODPPESO + finpemodif;
                    detConsumo[cantlista].BODPCANT = detConsumo[cantlista].BODPCANT + fincant;
                    detConsumo[cantlista].BODPPERE = detConsumo[cantlista].BODPPERE + finreal;

                    detConsumo[cantlista].BODPTAUN = taracono;


                    detConsumo[cantlista].BODPDIFE = Math.Round(detConsumo[cantlista].BOLSPESO.Value - detConsumo[cantlista].BODPPESO,2);
                    if (Stock0CheckBox.Checked == true) detConsumo[cantlista].BODPSTCE = 1;
                    else detConsumo[cantlista].BODPSTCE = 0;
                }
                else
                    MostrarMensaje("Las cantidades ingresadas son incorrectas");
                ////
                SetDataSourceBolsas(detConsumo);
            }
            catch (Exception ex)
            {
                MostrarMensaje("Las cantidades ingresadas no son correctas");
                //MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        private void SetDataSourceBolsas(List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> _listaConsumos)
        {
            bool limpiaDet = false;
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtieneBolsaDefault();
                limpiaDet = true;
            }

            DetalleBolsas = _listaConsumos;
            trabajaritemGridView.DataSource = DetalleBolsas;
            trabajaritemGridView.DataBind();
            if (trabajaritemGridView.SelectedIndex == -1 || limpiaDet)
            {
                SetDataSourceUbicaciones(null);
            }
        }

        private void SetDataSourceUbicaciones(List<USP_OBTIENE_UBICACIONES_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneUbicacionesDefault();
            }

            Ubicaciones = _listaAsignacion;
            detalleGridView.DataSource = Ubicaciones;
            detalleGridView.DataBind();
        }

        protected void totaliza()
        {
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;
                //USP_OBTIENE_DETPREPARACION_POR_IDDETOSA_Result detalle = seleccionado();

                decimal totcant, totpesobru, tottar, totpesonet, diferencia, cantAtend, pesoAtend, totpesobrut;
                totcant = 0;
                totpesobru = 0;
                tottar = 0;
                totpesobrut = 0;
                totpesonet = 0;

                foreach (var item in detConsumo)
                {
                    decimal taracal, brutocal, pesobruto;

                    incluyebolsa = item.BODPINBO;
                    pbolsa = item.TIEMTARA.Value;
                    pcono = item.UNIDTARA.Value;
                    cantAtend = item.BODPCANT;
                    pesoAtend = item.BODPPESO;
                    pesobruto = item.BODPPEBR - item.BODPTADE;//el peso bruto de la bolsa

                    taracal = pcono * cantAtend + (pbolsa * incluyebolsa);

                    brutocal = pesoAtend + taracal;//el peso modificado es diferente del peso bruto, cuando cambien el peso neto  no cmbiaria el calculo???

                    totcant += cantAtend;
                    totpesonet += pesoAtend;
                    totpesobru += brutocal;
                    tottar += taracal;

                    totpesobrut += pesobruto;

                }
                //diferencia = detalle.DEPEPESO - totpesonet;

                cantidadLabel.Text = Math.Round(Double.Parse(totcant.ToString()), 2) + " UND";
                brutoLabel.Text = Math.Round(Double.Parse(totpesobrut.ToString()), 2) + " KG";
                taraLabel.Text = Math.Round(Double.Parse(tottar.ToString()), 3) + " KG";
                netoLabel.Text = Math.Round(Double.Parse(totpesonet.ToString()), 3) + " KG";
                //diferencialabel.Content = (Double.Parse(objdetalle.DEPEPESO.ToString()) - Double.Parse(totpesonet.ToString())) + " KG";
            }
            catch (Exception)
            {
                cantidadLabel.Text = "00.00 UND";
                brutoLabel.Text = "00.00 KG";
                taraLabel.Text = "00.00 KG";
                netoLabel.Text = "00.00 KG";
                //diferencialabel.Content = "00.00 KG";
            }
        }

        private void SetDataSourceGuardadas(List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> _listaConsumos)
        {
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtieneGuardadasDefault();
            }

            //DetalleBolsas = _listaConsumos;
            GridView1.DataSource = _listaConsumos;
            GridView1.DataBind();
        }

        private List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> ObtieneGuardadasDefault()
        {
            List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> datos = new List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result>();
            datos.Add(new USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result() { DEOSIDDO = -1 });
            return datos;
        }

        protected USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result seleccionado()
        {
            USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle = null;
            try
            {
                List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detConsumo = DetalleBolsas;

                if (detConsumo != null && detConsumo[0].BOLSCOEM != null)
                {
                    int indexSelect = 0;
                    indexSelect = trabajaritemGridView.SelectedIndex;

                    if (indexSelect != -1)
                    {
                        GridViewRow row = trabajaritemGridView.SelectedRow;

                        if (row != null)
                        {
                            string corrLiq = row.Cells[0].Text;
                            detalle = detConsumo.Find(x => x.BOLSCOEM == corrLiq);
                            if (detalle == null)
                            {
                                detalle = detConsumo.Find(x => x.BOLSCOEM == "");
                            }
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            return detalle;
        }

        protected void llena_modal(USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result detalle)
        {
            try
            {
                this.Form.DefaultFocus = this.maceptarButton.UniqueID;
                BolsaLabel.Text = "BOLSA: " + detalle.BOLSCOEM;
                PartidaLabel.Text = "PARTIDA: " + detalle.BOLSPART;
                AlmacenLabel.Text = "ALMACEN: " + detalle.BOLSALMA;
                incluyestock = detalle.BODPSTCE;
                incluyebolsa = detalle.BODPINBO;
                if (!string.IsNullOrWhiteSpace(detalle.BOLSCOEM))
                {
                    pcono = detalle.UNIDTARA.Value;
                    pbolsa = detalle.TIEMTARA.Value;
                }
                else
                {
                    pcono = 0;
                    pbolsa = 0.1M;
                }

                if (incluyestock == 1)
                {
                    Stock0CheckBox.Checked = true;
                }
                else
                    Stock0CheckBox.Checked = false;

                if (incluyebolsa == 1)
                {
                    IncluirbCheckBox.Checked = true;
                }
                else
                    IncluirbCheckBox.Checked = false;

                decimal taracal = 0;
                decimal brutocal = 0;

                taracal = Math.Round(pcono, 3) * detalle.BODPCANT + (pbolsa * incluyebolsa);
                brutocal = detalle.BODPPESO + taracal + detalle.BODPTADE;


                cantidadTextBox.Text = detalle.BODPCANT.ToString();
                pbrutoTextBox.Text = (Math.Round(Double.Parse(detalle.BODPPEBR.ToString()), 2)).ToString();
                taraTextBox.Text = (Math.Round(Double.Parse(taracal.ToString()), 3)).ToString();
                taradesTextBox.Text = (Math.Round(detalle.BODPTADE, 3)).ToString();
                pnrealTextBox.Text = (Math.Round(detalle.BODPPERE, 2)).ToString();
                pbfinalTextBox.Text = Math.Round((detalle.BODPPEBR), 2).ToString();
                pnmodificadoTextBox.Text = (Math.Round(detalle.BODPPESO, 2)).ToString();
                taraconoTextBox.Text = detalle.BODPTAUN.ToString();
                //taraconoTextBox.Text(String.valueOf(selected.getBODPTAUN()));
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void llena_modal_multi(List<USP_OBTIENE_DETPREPARACION_POR_IDDETOSASE_Result> detalle)
        {
            try
            {
                BolsaLabel.Text = "BOLSAS MULTIPLES ";
                PartidaLabel.Text = "PARTIDA: " + detalle[0].BOLSPART;
                AlmacenLabel.Text = "ALMACEN: " + detalle[0].BOLSALMA;
                IncluirbCheckBox.Checked = true;
                incluyebolsa = 1;

                decimal totpesobru, tottar, totpesonet, tade, tottade, cantAtend, pesoAtend, totpesobrut, totcant;
                totcant = 0;
                totpesobru = 0;
                tottar = 0;
                totpesobrut = 0;
                totpesonet = 0;
                tottade = 0;

                foreach (var item in detalle)
                {
                    decimal taracal, brutocal, pesobruto;

                    //incluyebolsa = item.BODPINBO;
                    pbolsa = item.TIEMTARA.Value;
                    pcono = item.UNIDTARA.Value;
                    cantAtend = item.BODPCANT;
                    pesoAtend = item.BODPPESO;
                    pesobruto = item.BODPPEBR;// - item.BODPTADE;//el peso bruto de la bolsa
                    tade = item.BODPTADE;

                    taracal = Math.Round(pcono, 3) * cantAtend + (pbolsa * incluyebolsa);

                    brutocal = pesoAtend + taracal + tade;//el peso modificado es diferente del peso bruto, cuando cambien el peso neto  no cmbiaria el calculo???

                    totcant += cantAtend;
                    totpesonet += pesoAtend;
                    totpesobru += brutocal;
                    tottar += taracal;
                    tottade += tade;
                    totpesobrut += pesobruto;
                }

                Fintotcant = totcant;
                cantidadTextBox.Text = totcant.ToString();
                pbrutoTextBox.Text = (Math.Round(Double.Parse(totpesobrut.ToString()), 2)).ToString();
                taraTextBox.Text = (Math.Round(Double.Parse(tottar.ToString()), 3)).ToString();
                taradesTextBox.Text = tottade.ToString();
                pnrealTextBox.Text = (Math.Round(totpesonet, 2)).ToString();
                pbfinalTextBox.Text = (Math.Round((totpesobrut), 2)).ToString();
                pnmodificadoTextBox.Text = (Math.Round(totpesonet, 2)).ToString();

                //ettaracono.setText(String.valueOf(round(pcono, 3)));

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        #endregion
    }
}