﻿using appConstantes;
using appFew.appServicio;
using appWcfService;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace appFew.ope
{
    public partial class atenderosa : System.Web.UI.Page
    {
        #region Variables
        private static ParametrosFe _ParametrosIni;

        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;
        List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> objpecaos = new List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>();
        #endregion

        #region Eventos

        protected void Page_Load(object sender, EventArgs e)
        {
            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];



            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {
                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();

                    if (!Page.IsPostBack)
                    {
                        CargaDatosIniciales();

                        if (Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA] != null)
                        {
                            objpecaos = (List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>)Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA];
                            if (objpecaos != null)
                            {
                                //foliolabel.Text = "FOLIO: " /*+ objpecaos.OSASFOLI*/;
                                //femisionlabel.Text = "F. EMISION: " /*+ objpecaos.OSASFEEM.ToShortDateString()*/;
                                //fentregalabel.Text = string.IsNullOrWhiteSpace(objpecaos.PARTFEEF.ToString()) ? "F. ENTREGA: " : "F. ENTREGA: " + objpecaos.PARTFEEF.Value.ToShortDateString();
                                //usrlabel.Text = "USUARIO: " + objpecaos.OSASRESP;
                                CargaDetalleOsaList(objpecaos);
                                revisionCheck();
                            }
                            //Session.Remove(Constantes.NOMBRE_SESION_OSA_SELECCIONADA);
                        }
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void DetallesosaGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void DetallesosaGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            String PartBase = "";
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(DetallesosaGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[6].Text = "";
                    e.Row.Cells[7].Text = "";
                }
                //Find checkbox and checked/Unchecked based on values
                CheckBox chkb = (CheckBox)e.Row.FindControl("cbSelect");
                double solicitado, atendido;
                solicitado = e.Row.Cells[4].Text.ToString().Equals("") ? 0 : Double.Parse(e.Row.Cells[4].Text.ToString());
                atendido = e.Row.Cells[7].Text.ToString().Equals("") ? 0 : Double.Parse(e.Row.Cells[7].Text.ToString());

                if (e.Row.Cells[9].Text.Equals("1.0") || (solicitado - atendido) > 0)
                {
                    chkb.Checked = true;
                }
                else
                {//'
                }
                PartBase = Convert.ToString(System.Web.UI.DataBinder.Eval(e.Row.DataItem, "PARTSTPR"));

                if (PartBase.Equals("T") || PartBase.Equals("R"))
                {
                    //e.Row.BackColor = System.Drawing.Color.LightGreen;
                    e.Row.BackColor = System.Drawing.ColorTranslator.FromHtml("#58D68D");
                    e.Row.ForeColor = System.Drawing.Color.Black;
                }
                if (PartBase.Equals("A") || PartBase.Equals("C") || PartBase.Equals("S"))
                {
                    //e.Row.BackColor = System.Drawing.Color.Khaki;
                    e.Row.BackColor = System.Drawing.ColorTranslator.FromHtml("#FFFF99");
                    e.Row.ForeColor = System.Drawing.Color.Black;
                }
                if (PartBase.Equals("G") || PartBase.Equals("E") || PartBase.Equals("F"))
                {
                    //e.Row.BackColor = System.Drawing.Color.Tomato;
                    e.Row.BackColor = System.Drawing.ColorTranslator.FromHtml("#EC7063");
                    e.Row.ForeColor = System.Drawing.Color.Black;
                }
            }
        }

        protected void DetallesosaGridView_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                MuestraUbicaciones();

                //GridViewRow row = DetallesosaGridView.SelectedRow;
                //List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result> listseleccionadas = new List<appWcfService.USP_OBTIENE_DETALLE_OSA_Result>();
                //listseleccionadas = Listosas;
                //if (row != null)
                //{
                //    //LENAR TABPAGES
                //    string corrLiq = row.Cells[0].Text;

                //    List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                //    if (detConsumo != null && detConsumo[0].OSASSECU != -1)
                //    {
                //        USP_OBTIENE_DETALLE_OSA_Result detalle = detConsumo.Find(x => x.OSASSECU == Convert.ToDecimal(corrLiq));
                //        CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                //        if (chkRow.Checked)
                //        {
                //            listseleccionadas.Add(detalle);
                //        }
                //        else
                //        {
                //            listseleccionadas.Remove(detalle);
                //        }
                //        Listosas = listseleccionadas;
                //    }
                //}

            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void DetallesosaGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (DetallesosaGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = DetallesosaGridView.Rows[DetallesosaGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = DetallesosaGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void UbicacionesGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void UbicacionesGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {
                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(UbicacionesGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[1].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void atenderbutton_Click(object sender, EventArgs e)
        {
            GridViewRow row = DetallesosaGridView.SelectedRow;

            if (row != null)
            {
                decimal corrLiq = Decimal.Parse(row.Cells[0].Text);

                List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                if (detConsumo != null && detConsumo[0].OSASSECU != -1)
                {
                    USP_OBTIENE_DETALLE_OSA_Result detalle = detConsumo.Find(x => x.OSASSECU == corrLiq);
                    List<USP_OBTIENE_DETALLE_OSA_Result> cambiosesta = new List<USP_OBTIENE_DETALLE_OSA_Result>();
                    //if (detalle.DEOSESTA == 1 || detalle.DEOSESTA == 0)
                    //{
                    detalle.DEOSESTA = 3;

                    //}
                    cambiosesta.Add(detalle);
                    CambiaestadeosBodp(cambiosesta, 0, _ParametrosIni.Usuario);
                    //GuardaOrigen(detalle);
                    if (!detalle.OSASSTOS.Equals("S"))
                    {
                        ActualizaPreparacion(detalle);
                    }
                    else
                    {
                        Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] = detalle;
                        Response.Redirect("../ope/trabajar_item.aspx");
                    }

                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }

        protected void btnfinalizapreparacion_Click(object sender, EventArgs e)
        {
            try
            {
                Nota.Show();
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        protected void maceptarbutton_Click(object sender, EventArgs e)
        {
            try
            {
                List<USP_OBTIENE_DETALLE_OSA_Result> Listadetalle = new List<USP_OBTIENE_DETALLE_OSA_Result>();
                List<appWcfService.PECAOS> listaesta4 = new List<PECAOS>();
                List<appWcfService.PECAOS> listaesta5 = new List<PECAOS>();
                objpecaos = (List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>)Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA];
                //if (objpecaos.CAOSIDCO != 0)
                //{
                if (DetallesosaGridView.Rows.Count > 0)
                {
                    //Si la grilla tiene items pasa a obtener en una lista los detalles
                    List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                    foreach (GridViewRow row in DetallesosaGridView.Rows)
                    {
                        //recorremos la grilla para seleccionar los items que han sidos marcados con checks
                        if (row.RowType == DataControlRowType.DataRow)
                        {
                            decimal corrLiq = Decimal.Parse(row.Cells[0].Text);
                            USP_OBTIENE_DETALLE_OSA_Result objdet = detConsumo.Find(x => x.OSASSECU == corrLiq);
                            CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                            PECAOS cabecera = new PECAOS();
                            cabecera.CAOSFOLI = objdet.OSASFOLI;
                            cabecera.CAOSIDCO = objdet.DEOSIDCO;
                            cabecera.CAOSNOTA = descripcionFinal;
                            if (objdet.DEOSPEAT > 0)
                            {
                                if (chkRow.Checked)
                                {
                                    //obtenemos el item marcado con el check
                                    if (objdet.DEOSPEAT >= objdet.OSASCASO)
                                    { //Si es esta marcado y su peso es mayor a 0 lo pone como parcial
                                        //estado completo 5
                                        objdet.DEOSESTA = 5;
                                        cabecera.CAOSIDES = 5;
                                        listaesta5.Add(cabecera);
                                        //Listadetalle.Add(objdet);
                                    }
                                    else
                                    {
                                        //estado parcial 6 
                                        objdet.DEOSESTA = 6;
                                        cabecera.CAOSIDES = 4;
                                        listaesta4.Add(cabecera);
                                    }
                                }
                                else
                                {
                                    //if (objdet.DEOSPEAT > 0)
                                    //{//estado completo 5
                                    objdet.DEOSESTA = 5;
                                    //Listadetalle.Add(objdet);
                                    //}
                                }
                                Listadetalle.Add(objdet);
                                if (/*objdet.DEOSPEAT > 0 && */(listaesta4.Find(x => x.CAOSFOLI == objdet.OSASFOLI) == null))//se atendio y no tiene ningun detalle del mismo folio en estado 4
                                {//si hay algun detalle con estdo 6 est se mandara a 4
                                    cabecera.CAOSIDES = 5;
                                    listaesta5.Add(cabecera);
                                }
                            }
                            else
                            {
                                if (chkRow.Checked)
                                {
                                    if (listaesta5.Find(x => x.CAOSFOLI == objdet.OSASFOLI) != null)
                                    {
                                        listaesta5.RemoveAll(x => x.CAOSFOLI == cabecera.CAOSFOLI);
                                    }
                                    if (objdet.DEOSESTA != 1)
                                    {
                                        objdet.DEOSESTA = 6;
                                    }
                                    else
                                    {
                                        objdet.DEOSESPA = 1;
                                    }
                                    cabecera.CAOSIDES = 4;
                                    listaesta4.Add(cabecera);
                                }
                                else
                                {
                                    if (listaesta5.Find(x => x.CAOSFOLI == objdet.OSASFOLI) == null)
                                    {
                                        cabecera.CAOSIDES = 5;
                                        listaesta5.Add(cabecera);
                                    }
                                    objdet.DEOSESTA = 5;
                                }
                                Listadetalle.Add(objdet);
                            }
                        }

                    }
                }
                //}
                if (Listadetalle.Count > 0)
                {
                    //llamar metodos para cambiar estados al detalle (PEDEOS) y a la OSA (PROSAS)
                    //luego llamar a metodo para obtener los detalles actualizados
                    if (CambiaestadeosBodp(Listadetalle, 4, _ParametrosIni.Usuario))
                    {
                        listaesta4.AddRange(listaesta5);
                        foreach (var item in listaesta4)
                        {
                            cambiaestadoCAOS(item);
                        }
                    }
                    //Session.Remove(Constantes.NOMBRE_SESION_DETALLE_OSAS_ATENDER);
                    //Session.Remove(Constantes.NOMBRE_SESION_UBICACIONES_ATENDER);
                    //Session.Remove(Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER);
                    //Session.Remove(Constantes.NOMBRE_SESION_OSA_SELECCIONADA);
                    Response.Redirect("../ope/pendientes.aspx");
                }
                else
                {
                    //Pendiente el mensaje, no deberia entrar nunca aquí
                    //MostrarMensaje("No se ha podido finalizar la Preparación, por favor revise que el peso atendido sea mayor a 0.00 ");
                    alerta.Show();
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }
        protected void maceptarbutton1_Click(object sender, EventArgs e)//ninguno ha sido trabajado o alguno esta en 0
        {
            try
            {
                List<USP_OBTIENE_DETALLE_OSA_Result> Listadetalle = new List<USP_OBTIENE_DETALLE_OSA_Result>();
                List<appWcfService.PECAOS> listaesta4 = new List<PECAOS>();
                List<appWcfService.PECAOS> listaesta5 = new List<PECAOS>();
                objpecaos = (List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result>)Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA];
                //if (objpecaos.CAOSIDCO != 0)
                //{
                if (DetallesosaGridView.Rows.Count > 0)
                {
                    //Si la grilla tiene items pasa a obtener en una lista los detalles
                    List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                    foreach (GridViewRow row in DetallesosaGridView.Rows)
                    {
                        //recorremos la grilla para seleccionar los items que han sidos marcados con checks
                        if (row.RowType == DataControlRowType.DataRow)
                        {
                            decimal corrLiq = Decimal.Parse(row.Cells[0].Text);
                            USP_OBTIENE_DETALLE_OSA_Result objdet = detConsumo.Find(x => x.OSASSECU == corrLiq);
                            CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                            PECAOS cabecera = new PECAOS();
                            cabecera.CAOSFOLI = objdet.OSASFOLI;
                            cabecera.CAOSIDCO = objdet.DEOSIDCO;
                            cabecera.CAOSNOTA = descripcionFinal;

                            //Si es esta marcado y su peso es mayor a 0 lo pone como parcial
                            objdet.DEOSESTA = 5;
                            cabecera.CAOSIDES = 5;
                            listaesta5.Add(cabecera);
                            Listadetalle.Add(objdet);
                        }
                    }
                    //}
                    if (Listadetalle.Count > 0)
                    {
                        //llamar metodos para cambiar estados al detalle (PEDEOS) y a la OSA (PROSAS)
                        //luego llamar a metodo para obtener los detalles actualizados
                        if (CambiaestadeosBodp(Listadetalle, 4, _ParametrosIni.Usuario))
                        {
                            foreach (var item in listaesta5)
                            {
                                cambiaestadoCAOS(item);
                            }
                        }
                        //Session.Remove(Constantes.NOMBRE_SESION_DETALLE_OSAS_ATENDER);
                        //Session.Remove(Constantes.NOMBRE_SESION_UBICACIONES_ATENDER);
                        //Session.Remove(Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER);
                        //Session.Remove(Constantes.NOMBRE_SESION_OSA_SELECCIONADA);
                        Response.Redirect("../ope/pendientes.aspx");
                    }
                    else
                    {
                        //Pendiente el mensaje, no deberia entrar nunca aquí
                        //MostrarMensaje("No se ha podido finalizar la Preparación, por favor revise que el peso atendido sea mayor a 0.00 ");
                        alerta.Show();
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        protected void mcancelarbutton1_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        protected void mcancelarbutton_Click(object sender, EventArgs e)
        {
            try
            {

            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }
        #endregion

        #region Metodos

        private void CargaDatosIniciales()
        {

            InicializaDatos();
            //CargaOsasEmitidas(folio, numfolio);
        }

        private void InicializaDatos()
        {
            //SetDataSourceOsas(null);

            ////asignacion
            SetDataSourceDetalle(null);
        }

        private void CargaDetalleOsa(string folio)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_Result>>(resultado.VALSAL[1]);
                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void CargaDetalleOsaList(List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_Result> Listafolios)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA_LIST;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(Listafolios));

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_Result>>(resultado.VALSAL[1]);
                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }
                }
                else
                {
                    SetDataSourceDetalle(null);
                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
            }

            DetalleOsaPendiente = _listaAsignacion;
            DetallesosaGridView.DataSource = DetalleOsaPendiente;
            DetallesosaGridView.DataBind();

        }

        private List<USP_OBTIENE_DETALLE_OSA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_Result() { OSASSECU = -1 });
            return datos;
        }

        private List<USP_OBTIENE_DETALLE_OSA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_ATENDER] as List<USP_OBTIENE_DETALLE_OSA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_ATENDER] = value;
            }
        }

        private void MuestraUbicaciones()
        {
            GridViewRow row = DetallesosaGridView.SelectedRow;

            if (row != null)
            {
                decimal corrLiq = Decimal.Parse(row.Cells[0].Text);

                List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                if (detConsumo != null && detConsumo[0].OSASSECU != -1)
                {
                    USP_OBTIENE_DETALLE_OSA_Result detalle = detConsumo.Find(x => x.OSASSECU == corrLiq);
                    CargaUbicaciones(detalle.OSASARTI, detalle.OSASPAOR, detalle.OSASALMA);
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }

        public void CargaUbicaciones(string Articulo, string Partida, decimal Almacen)
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MOSTRAR_UBICACION;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                //parEnt.Add(_ParametrosIni.Usuario);
                parEnt.Add(Articulo);
                parEnt.Add(Partida);
                parEnt.Add(Almacen.ToString());

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_UBICACIONES_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_UBICACIONES_Result>>(resultado.VALSAL[1]);

                        SetDataSourceUbicaciones(datos);
                    }
                    else
                    {
                        SetDataSourceUbicaciones(null);
                    }

                }
                else
                {
                    SetDataSourceUbicaciones(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceUbicaciones(List<USP_OBTIENE_UBICACIONES_Result> _listaAsignacion)
        {
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleUbicacionesDefault();
            }

            DetalleUbicaciones = _listaAsignacion;
            UbicacionesGridView.DataSource = DetalleUbicaciones;
            UbicacionesGridView.DataBind();
        }

        private List<USP_OBTIENE_UBICACIONES_Result> ObtieneDetalleUbicacionesDefault()
        {
            List<USP_OBTIENE_UBICACIONES_Result> datos = new List<USP_OBTIENE_UBICACIONES_Result>();
            datos.Add(new USP_OBTIENE_UBICACIONES_Result() { UBICCANT = 0 });
            return datos;
        }

        private List<USP_OBTIENE_UBICACIONES_Result> DetalleUbicaciones
        {
            get
            {
                List<USP_OBTIENE_UBICACIONES_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_UBICACIONES_ATENDER] as List<USP_OBTIENE_UBICACIONES_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleUbicacionesDefault();

                    DetalleUbicaciones = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_UBICACIONES_ATENDER] = value;
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }

        private void ActualizaPreparacion(USP_OBTIENE_DETALLE_OSA_Result detalle)
        {
            IappServiceClient clt = null;
            PEDEOS deta = new PEDEOS();
            deta.DEOSFOLI = detalle.OSASFOLI;
            deta.DEOSSECU = detalle.OSASSECU;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.ACTUALIZA_DETOSA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(deta));

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    Session[Constantes.NOMBRE_OSA_SELECCIONADA_ATENDER] = detalle;
                    Response.Redirect("../ope/trabajar_item.aspx");
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private bool CambiaestadeosBodp(List<USP_OBTIENE_DETALLE_OSA_Result> detalle, decimal estado, string usuario)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.CAMBIA_ESTADO_DEOS_BODP;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(detalle));
                parEnt.Add(estado.ToString());
                parEnt.Add(usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    //return resultado.ESTOPE;
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
                return resultado.ESTOPE;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return false;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        //private void Cambiaestadeos(List<USP_OBTIENE_DETALLE_OSA_Result> detalle, string usuario)
        //{
        //    IappServiceClient clt = null;

        //    try
        //    {
        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.CAMBIA_ESTADO_DEOS;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(Utils.Serialize(detalle));
        //        parEnt.Add(usuario);

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {

        //        }
        //        else
        //        {
        //            MostrarMensaje(resultado.MENERR);
        //            //return resultado.ESTOPE;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //        //return false;
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}

        private bool cambiaestadoCAOS(PECAOS seleccionado)
        {
            IappServiceClient clt = null;
            bool result = false;

            try
            {

                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_PEDIDO_INTERNO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(seleccionado));
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0] != "0")
                    {
                        seleccionado.CAOSIDCO = Decimal.Parse(resultado.VALSAL[0]);
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    result = false;
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                result = resultado.ESTOPE;
                return result;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return result;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        //private void cambiaestadoBODP(List<USP_OBTIENE_DETALLE_OSA_Result> iddo, decimal estado)
        //{
        //    IappServiceClient clt = null;
        //    try
        //    {

        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.CAMBIA_ESTADO_BODP;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(Utils.Serialize(iddo));
        //        parEnt.Add(estado.ToString());
        //        parEnt.Add(_ParametrosIni.Usuario);

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {

        //        }
        //        else
        //        {
        //            MostrarMensaje(resultado.MENERR);
        //            //ErrorLabel.Font.Bold = true;
        //            //ErrorLabel.Text = resultado.MENERR;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}

        //private void GuardaOrigen(USP_OBTIENE_DETALLE_OSA_Result detalle)
        //{
        //    IappServiceClient clt = null;

        //    try
        //    {
        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.GUARDA_ORIGEN;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(Utils.Serialize(detalle));

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {
        //            //return resultado.ESTOPE;
        //        }
        //        else
        //        {
        //            MostrarMensaje(resultado.MENERR);
        //            //return resultado.ESTOPE;
        //        }
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //        //return false;
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}
        #endregion

        public void revisionCheck()
        {
            if (DetallesosaGridView.Rows.Count > 0)
            {
                //Si la grilla tiene items pasa a obtener en una lista los detalles
                List<USP_OBTIENE_DETALLE_OSA_Result> detConsumo = DetalleOsaPendiente;

                foreach (GridViewRow row in DetallesosaGridView.Rows)
                {
                    //recorremos la grilla para seleccionar los items que han sidos marcados con checks
                    if (row.RowType == DataControlRowType.DataRow)
                    {
                        decimal corrLiq = Decimal.Parse(row.Cells[0].Text);
                        USP_OBTIENE_DETALLE_OSA_Result objdet = detConsumo.Find(x => x.OSASSECU == corrLiq);
                        CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);

                        if (objdet.DEOSPEAT >= objdet.OSASCASO)
                        {
                            chkRow.Checked = false;
                        }
                        else
                        {
                            chkRow.Checked = true;
                        }
                    }

                }
            }
        }

        //guarda notas

        protected void aceptar_nota_Click(object sender, EventArgs e)
        {
            //MostrarMensaje(descripcion.Text.ToString());
            descripcionFinal = descripcion.Text.ToString();
            mensajemodal.Show();
        }

        protected void cancelar_nota_Click(object sender, EventArgs e)
        {

        }

        private String descripcionFinal
        {
            get
            {
                String Findesc = Session[Constantes.DESCRIPCIONFINAL].ToString();
                return Findesc;
            }
            set
            {
                Session[Constantes.DESCRIPCIONFINAL] = value;
            }
        }
    }
}