﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace appConstantes
{
    public class CodigoOperacion
    {
        public const int ACCESO_OSAS_PENDIENTES_SOLO_LECTURA = 1;

        //public const string VALIDA_USUARIO = "COM001";
        #region Usuarios
        public const string VALIDA_USUARIO = "US001";
        public const string CAMBIAR_PASSWORD = "US002";

        public const string VALIDA_ACCESO = "US003";
        #endregion
        public const string TRACKING_PEDIDOS = "PEDI01";
        public const string CARGA_FOLIO = "PEDI02";
        public const string MUESTRA_OSAS_PENDIENTES = "PEDI03";
        public const string MUESTRA_DETALLE_OSA = "PEDI04";
        public const string GENERA_PEDIDO_INTERNO = "PEDI05";
        public const string ACTUALIZA_DETOSA = "PEDI06";
        public const string OBTIENE_PREPARACIONOSA = "PEDI07";
        public const string OBTIENE_BOLSA_OSA = "PEDI08";
        public const string BUSQUEDA_OSAS = "PEDI09";
        public const string OBTIENE_OSAS_EMITIDAS_PRIORIZAR = "PEDI10";
        public const string OBTIENE_TIPOS_FOLIO_USUARIO = "PEDI11";
        public const string GUARDA_PRIORIDAD = "PEDI12";
        public const string MUESTRA_OSAS_PENDIENTES_WEB = "PEDI13";
        public const string MOSTRAR_UBICACION = "PEDI14";
        public const string GUARDA_BOLSA = "PEDI15";
        public const string ELIMINA_BOLSA = "PEDI16";

        //PLANTA
        public const string MUESTRA_OSAS_PENDIENTES_PLANTA = "PEDI17";
        public const string CAMBIA_ESTADO_DEOS = "PEDI18";
        public const string GENERA_ORDEN_TRABAJO = "PEDI19";

        //
        public const string CAMBIA_ESTADO_BODP = "PEDI20";
        public const string BUSCA_OSAS_PENDIENTES_PLANTA = "PEDI21";
        public const string GUARDA_ORIGEN = "PEDI22";
        public const string REABRE_OSA = "PEDI23";
        public const string MUESTRA_DETALLE_OSA_PLANTA = "PEDI24";
        public const string MUESTRA_DETALLE_OSA_PLANTA_LISTA = "PEDI25";

        public const string APRUEBA_OSAS_PLANTA = "PEDI26";
        public const string UNIDAD_KG = "KG";
        public const string TIPO_ACCION_OSA = "S";

        //
        public const string MUESTRA_BUSCA_OSAS_PENDIENTES = "PEDI27";
        //
        public const string MUESTRA_DETALLE_OSA_LIST = "PEDI28";
        //
        public const string CAMBIA_ESTADO_DEOS_BODP = "PEDI29";

        //REABRIR PLANTA
        //PLANTA
        public const string MUESTRA_OSAS_REABRIR_PLANTA = "PEDI30";
        public const string BUSCA_OSAS_REABRIR_PLANTA = "PEDI31";
        public const string MUESTRA_DETALLE_OSA_REABRIR = "PEDI32";
        public const string EXTORNA_OSA_PLANTA = "PEDI33";
        public const string GENERA_DEVOLUCION_MATERIAL = "PEDI34";

        public const string MUESTRA_OSAS_PENDIENTES_IMPRIMIR = "PEDI35";
        public const string MUESTRA_DETALLE_OSAS_IMPRIMIR = "PEDI36";



    }

}
