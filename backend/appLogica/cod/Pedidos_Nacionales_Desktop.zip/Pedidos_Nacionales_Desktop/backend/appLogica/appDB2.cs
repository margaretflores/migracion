﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.Data;
using IBM.Data.DB2.iSeries;
using System.Configuration;

using AccesoDatos;
using appWcfService;
using appConstantes;


namespace appLogica
{
    public class appDB2
    {
        internal BaseDatos DB2;

        private bool OcultaErrorReal;
        private string Aplicacion;
        private string DataSourceDB2;

        public appDB2()
        {
            string stringConnection, userId, userPassword;
            DataSourceDB2 = ConfigurationManager.AppSettings["DataSource"];
            Aplicacion = ConfigurationManager.AppSettings["Aplicacion"];

            userId = ConfigurationManager.AppSettings["UserId"]; //"PCVTAS"; // "PCS400";
            userPassword = ConfigurationManager.AppSettings["UserPassword"]; //"PCVTAS"; // "pcs400";
            //stringConnection = "DataSource=" + DataSourceDB2 + ";User Id=" + userId + ";Password=" + userPassword + ";Naming=System;LibraryList=QS36F,PRODDAT,PRODPRG,costdat,INCAOBJ;CheckConnectionOnOpen=true;";
            stringConnection = "DataSource=" + DataSourceDB2 + ";User Id=" + userId + ";Password=" + userPassword + ";Naming=SQL;CheckConnectionOnOpen=true;";
            DB2 = new BaseDatos(stringConnection);

            if (ConfigurationManager.AppSettings["OcultaErrorReal"].Equals("1"))
            {
                OcultaErrorReal = true;
            }
            else
            {
                OcultaErrorReal = false;
            }
        }
        public void Finaliza()
        {
            DB2 = null;
        }
        public RESOPE obtieneDatosPartida(PAROPE paramOperacion)//string articulo, string partida, decimal idalmacen)
        {
            DataTable otrosDataTable;
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            try
            {
                string codigoColor;
                StringBuilder comandoSql;
                ///////

                string articulo, partida;
                decimal idalmacen;

                articulo = paramOperacion.VALENT[0];
                partida = paramOperacion.VALENT[1];
                idalmacen = Decimal.Parse(paramOperacion.VALENT[2]);

                ///////

                articulo = articulo.PadRight(15);
                vpar.VALSAL = new List<string>();
                DB2.Conectar();

                //stock
                comandoSql = new StringBuilder();
                comandoSql.Append("SELECT ");
                comandoSql.Append(" LOTSTOCK ");
                comandoSql.Append(" FROM QS36F.\"I1.DD41A\" "); //PRODDAT
                comandoSql.Append(" WHERE LOTCIA = ").Append(Constantes.CODIGO_CIA).Append(" AND LOTITEM = '").Append(articulo.Trim()).Append("' ");
                comandoSql.Append(" AND LOTPARTI = '").Append(partida.Trim()).Append("' AND LOTALM = ").Append(idalmacen);
                DB2.CrearComando(comandoSql.ToString(), CommandType.Text);
                otrosDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
                if (!Util.TablaVacia(otrosDataTable))
                {
                    DataRow cr = otrosDataTable.Rows[0];
                    decimal stock = Convert.ToDecimal(cr["LOTSTOCK"]) * 100;
                    vpar.VALSAL.Add(stock.ToString(Constantes.FORMATO_DECIMAL_0 + "0").Trim());
                }
                else
                {
                    vpar.VALSAL.Add("");
                }

                //COLOR
                codigoColor = articulo.Substring(9).Trim();
                if (string.IsNullOrEmpty(codigoColor))
                {
                    codigoColor = articulo.Substring(5, 4).Trim();
                }
                comandoSql = new StringBuilder();
                comandoSql.Append("SELECT ");
                comandoSql.Append(" DC.COINCOCO, DC.COINTICO, DC.COINGRCO, GC.TGRCDESC ");
                comandoSql.Append(" FROM PRODDAT.PRCOIN DC LEFT JOIN PRODDAT.PRTGRC GC ON DC.COINCIA = GC.TGRCCIA AND DC.COINGRCO = GC.TGRCCODI "); //QS36F PRODDAT  //QS36F.PRCOIN
                comandoSql.Append(" WHERE DC.COINCIA = ").Append(Constantes.CODIGO_CIA).Append(" AND DC.COINCOCO = '").Append(codigoColor).Append("' ");
                DB2.CrearComando(comandoSql.ToString(), CommandType.Text);
                otrosDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
                if (!Util.TablaVacia(otrosDataTable))
                {
                    DataRow cr = otrosDataTable.Rows[0];

                    vpar.VALSAL.Add(Convert.ToString(cr["COINTICO"]).Trim());
                    if (cr["COINTICO"] != DBNull.Value)
                    {
                        vpar.VALSAL.Add(Convert.ToString(cr["TGRCDESC"]).Trim());
                    }
                    else
                    {
                        vpar.VALSAL.Add("");
                    }
                }
                else
                {
                    vpar.VALSAL.Add("");
                    vpar.VALSAL.Add("");
                }

                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
            return vpar;
        }
        public RFEUSER ObtieneUsuarioDeFacturacion(string codusu)
        {
            List<RFEUSER> lista;
            RFEUSER usuario = null;
            try
            {
                DataTable cabeceraDataTable = null;
                DB2.Conectar();

                string comandoSql = "FAELDAT.USP_PED_OBTIENE_USUARIO";

                DB2.CrearComando(comandoSql, CommandType.StoredProcedure);
                DB2.AsignarParamProcAlmac("@PUSUARIO", iDB2DbType.iDB2Char, codusu);
                cabeceraDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
                lista = Util.ParseDataTable<RFEUSER>(cabeceraDataTable);
                if (lista.Count > 0)
                {
                    usuario = lista[0];
                }
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
            return usuario;
        }

        public RESOPE obtieneSeriesUsuario(PAROPE paramOperacion)
        {
            DataTable otrosDataTable;
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            try
            {
                string codigousuario;
                StringBuilder comandoSql;

                codigousuario = paramOperacion.VALENT[0];
                DB2.Conectar();

                //stock
                vpar.VALSAL = new List<string>();

                comandoSql = new StringBuilder();
                comandoSql.Append("FAELDAT.USP_OBTIENE_SERIES_POR_USUARIO"); //FAELDAT
                DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
                DB2.AsignarParamProcAlmac("@PUSERCUID", iDB2DbType.iDB2Char, codigousuario);
                DB2.AsignarParamProcAlmac("@PSRIEIDTD", iDB2DbType.iDB2Numeric, Constantes.ID_TIPO_DOC_PEDNAC);
                otrosDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
                if (!Util.TablaVacia(otrosDataTable))
                {
                    foreach (DataRow cr in otrosDataTable.Rows)
                    {
                        vpar.VALSAL.Add(Convert.ToString(cr["SRIECUID"]));                     
                    }
                }

                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
            return vpar;
        }

        public RESOPE GeneraPreguia(List<appWcfService.USP_OBTIENE_PEDIDO_CONSULTA_Result> cabdetpedido, string serie, string usuario, string codprovtrans, string estabpart, decimal estadest)
        {
            DataTable otrosDataTable;
            RESOPE vpar;
            vpar = new RESOPE() { ESTOPE = false };
            try
            {
                StringBuilder comandoSql;
                string ptopartida = "";
                decimal idpreguia;
                DB2.Conectar();

                //stock
                vpar.VALSAL = new List<string>();

                comandoSql = new StringBuilder();
                comandoSql.Append("COSTDAT.USP_OBTIENE_ESTABLECIMIENTO"); //COSTDAT
                DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
                DB2.AsignarParamProcAlmac("@PESTAESTA", iDB2DbType.iDB2Char, estabpart); //032
                otrosDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
                if (!Util.TablaVacia(otrosDataTable))
                {
                    DataRow row = otrosDataTable.Rows[0];
                    ptopartida = Convert.ToString(row["ESTADIR1"]).Trim() + Convert.ToString(row["ESTADIR2"]).Trim() + " - " + Convert.ToString(row["ESTADIST"]).Trim() + " - " + Convert.ToString(row["ESTAPROV"]).Trim() + " - " + Convert.ToString(row["ESTADEPA"]).Trim();
                }
                //por tipo usar el tipodoc y motivo en guia

                comandoSql = new StringBuilder();
                comandoSql.Append("FAELDAT.USP_PED_INSERTA_GUIA_CAB"); //FAELDAT
                DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
                //20181123
                if (cabdetpedido[0].CAPETIPO == Constantes.VENTA || cabdetpedido[0].CAPETIPO == Constantes.CONSIGNACION)
                {
                    //20180418
                    Decimal idtipdoc = cabdetpedido[0].CAPEIDTD;
                    if (idtipdoc != Constantes.ID_TIPO_DOC_GUIA && idtipdoc != Constantes.ID_TIPO_DOC_NE)
                    {
                        idtipdoc = Constantes.ID_TIPO_DOC_GUIA;
                    }
                    if (idtipdoc == Constantes.ID_TIPO_DOC_NE)
                    {
                        codprovtrans = "";
                        DB2.AsignarParamProcAlmac("@PDOCOIDES", iDB2DbType.iDB2Numeric, Constantes.ID_ESTADO_CREADO_NE); //7 creado
                    }
                    else
                    {
                        DB2.AsignarParamProcAlmac("@PDOCOIDES", iDB2DbType.iDB2Numeric, Constantes.ID_ESTADO_CREADO_PREGUIA); //7 creado
                    }

                    DB2.AsignarParamProcAlmac("@PDOCOIDTD", iDB2DbType.iDB2Numeric, idtipdoc); //3 TIPO GUIA o 5 NOTA ENTR
                }
                else if (cabdetpedido[0].CAPETIPO == Constantes.TRANSF_ALMACENES)
                {
                    DB2.AsignarParamProcAlmac("@PDOCOIDES", iDB2DbType.iDB2Numeric, Constantes.ID_ESTADO_CREADO_PREGUIA); //7 creado
                    DB2.AsignarParamProcAlmac("@PDOCOIDTD", iDB2DbType.iDB2Numeric, Constantes.ID_TIPO_DOC_GUIA); //3 TIPO GUIA
                }
                else
                {
                    DB2.AsignarParamProcAlmac("@PDOCOIDES", iDB2DbType.iDB2Numeric, Constantes.ID_ESTADO_CREADO_TI); //7 creado
                    DB2.AsignarParamProcAlmac("@PDOCOIDTD", iDB2DbType.iDB2Numeric, Constantes.ID_TIPO_DOC_TI); //ERA 14 NO 11 TIPO TI
                }
                decimal totalbruto = cabdetpedido.Sum(X => X.DEPEPEBR) + cabdetpedido[0].CAPETADE;
                DB2.AsignarParamProcAlmac("@PDOCOSRIE", iDB2DbType.iDB2Char, serie); //R007 o T001
                DB2.AsignarParamProcAlmac("@PDOCOEMIS", iDB2DbType.iDB2Date, DateTime.Today); // new DateTime(2016, 12, 1)); // DateTime.Today);
                DB2.AsignarParamProcAlmac("@PDOCOPBRU", iDB2DbType.iDB2Numeric, totalbruto);
                DB2.AsignarParamProcAlmac("@PDOCONBTS", iDB2DbType.iDB2Numeric, cabdetpedido[0].CAPENUBU);
                DB2.AsignarParamProcAlmac("@PDOCOOBSE", iDB2DbType.iDB2VarChar, cabdetpedido[0].CAPENOTG);
                DB2.AsignarParamProcAlmac("@PDOCODIRC", iDB2DbType.iDB2Char, cabdetpedido[0].CAPEDIRE);
                DB2.AsignarParamProcAlmac("@PDOCOUSCR", iDB2DbType.iDB2VarChar, usuario);
                DB2.AsignarParamProcAlmac("@PENTICUID", iDB2DbType.iDB2Char, cabdetpedido[0].CAPEIDCL);
                DB2.AsignarParamProcAlmac("@PDCENTRAN", iDB2DbType.iDB2Char, codprovtrans);
                DB2.AsignarParamProcAlmac("@PDCENPUPATR", iDB2DbType.iDB2VarChar, ptopartida);
                DB2.AsignarParamProcAlmac("@PFECHTRAS", iDB2DbType.iDB2TimeStamp, DateTime.Now); //new DateTime(2016, 12, 1));  //DateTime.Today); //---TEMPORAL PARA PRUEBAS
                DB2.AsignarParamProcAlmac("@PTIPOPEDI", iDB2DbType.iDB2Numeric, cabdetpedido[0].CAPETIPO); //20180221 MOTIVO DEL PEDIDO
                DB2.AsignarParamProcAlmac("@PESTADEST", iDB2DbType.iDB2Numeric, estadest); //20180221 MOTIVO DEL PEDIDO

                DB2.AsignarParamSalidaProcAlmac("@PDOCOCUID", iDB2DbType.iDB2Numeric, 19);
                DB2.EjecutarProcedimientoAlmacenado();
                idpreguia = Convert.ToDecimal(DB2.ObtieneParametro("@PDOCOCUID"));

                int numitemdet = 0;
                    
                foreach (var item in cabdetpedido)
                {
                    numitemdet++;
                    comandoSql = new StringBuilder();
                    comandoSql.Append("FAELDAT.USP_PED_INSERTA_GUIA_DET"); //FAELDAT
                    DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
                    DB2.AsignarParamProcAlmac("@PDOCOCUID", iDB2DbType.iDB2Numeric, idpreguia);
                    DB2.AsignarParamProcAlmac("@PDOCOUSCR", iDB2DbType.iDB2VarChar, usuario);
                    DB2.AsignarParamProcAlmac("@PDDCOESAF", iDB2DbType.iDB2Numeric, 2); //2
                    DB2.AsignarParamProcAlmac("@PDDCODESC", iDB2DbType.iDB2VarChar, item.DEPEDSAR); //INVOCAR CL ANTES O DESPUES
                    if (numitemdet == 1)
                    {
                        DB2.AsignarParamProcAlmac("@PDDCOBLTS", iDB2DbType.iDB2Numeric, cabdetpedido[0].CAPENUBU); //ES BULTOS NO CONOS DE DONDE SALE
                        DB2.AsignarParamProcAlmac("@PDDCOPACN", iDB2DbType.iDB2Numeric, item.DEPEPEAT); //--EL MISMO neto, NO SE HA ESPECIFICADO acond
                        DB2.AsignarParamProcAlmac("@PDDCOPBRU", iDB2DbType.iDB2Numeric, item.DEPEPEBR + cabdetpedido[0].CAPETADE);
                    }
                    else
                    {
                        DB2.AsignarParamProcAlmac("@PDDCOBLTS", iDB2DbType.iDB2Numeric, 0); //ES BULTOS NO CONOS DE DONDE SALE
                        DB2.AsignarParamProcAlmac("@PDDCOPACN", iDB2DbType.iDB2Numeric, item.DEPEPEAT); //--EL MISMO neto, NO SE HA ESPECIFICADO acond
                        DB2.AsignarParamProcAlmac("@PDDCOPBRU", iDB2DbType.iDB2Numeric, item.DEPEPEBR);
                    }
                    DB2.AsignarParamProcAlmac("@PDDCOPNET", iDB2DbType.iDB2Numeric, item.DEPEPEAT);
                    DB2.AsignarParamProcAlmac("@PDDCOFACN", iDB2DbType.iDB2Numeric, 0);
                    DB2.AsignarParamProcAlmac("@PPDDCIDPI", iDB2DbType.iDB2Char, item.DEPECOAR);
                    DB2.AsignarParamProcAlmac("@PPDDCCANT", iDB2DbType.iDB2Numeric, item.DEPECAAT);
                    DB2.AsignarParamProcAlmac("@PPDDCPEDI", iDB2DbType.iDB2Char, item.DEPECONT);
                    DB2.AsignarParamProcAlmac("@PPRALIDAL", iDB2DbType.iDB2Numeric, item.DEPEALMA);
                    DB2.AsignarParamProcAlmac("@PPRALIDPA", iDB2DbType.iDB2Char, item.DEPEPART);

                    DB2.AsignarParamProcAlmac("@PCVTDSECU", iDB2DbType.iDB2Numeric, item.DEPESECU);

                    DB2.AsignarParamSalidaProcAlmac("@PDDCOCUID", iDB2DbType.iDB2Numeric, 19);
                    DB2.EjecutarProcedimientoAlmacenado();

                }
                vpar.VALSAL.Add(Convert.ToString(idpreguia));
                vpar.ESTOPE = true;
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
                vpar.MENERR = ErrorGenerico(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
            return vpar;
        }
        //public RESOPE GeneraPreguia(List<appWcfService.USP_OBTIENE_PEDIDO_CONSULTA_Result> cabdetpedido, string serie, string usuario, string codprovtrans, string estabpart)
        //{
        //    DataTable otrosDataTable;
        //    RESOPE vpar;
        //    vpar = new RESOPE() { ESTOPE = false };
        //    try
        //    {
        //        StringBuilder comandoSql;
        //        string ptopartida = "";
        //        decimal idpreguia;
        //        DB2.Conectar();

        //        //stock
        //        vpar.VALSAL = new List<string>();

        //        comandoSql = new StringBuilder();
        //        comandoSql.Append("COSTDAT.USP_OBTIENE_ESTABLECIMIENTO"); //COSTDAT
        //        DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
        //        DB2.AsignarParamProcAlmac("@PESTAESTA", iDB2DbType.iDB2Char, estabpart); //032
        //        otrosDataTable = DB2.EjecutarProcedimientoAlmacenado().Tables[0];
        //        if (!Util.TablaVacia(otrosDataTable))
        //        {
        //            DataRow row = otrosDataTable.Rows[0];
        //            ptopartida = Convert.ToString(row["ESTADIR1"]).Trim() + Convert.ToString(row["ESTADIR2"]).Trim() + " - " + Convert.ToString(row["ESTADIST"]).Trim() + " - " + Convert.ToString(row["ESTAPROV"]).Trim() + " - " + Convert.ToString(row["ESTADEPA"]).Trim();
        //        }

        //        comandoSql = new StringBuilder();
        //        comandoSql.Append("FAELDAT.USP_PED_INSERTA_GUIA_CAB"); //FAELDAT
        //        DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
        //        DB2.AsignarParamProcAlmac("@PDOCOIDES", iDB2DbType.iDB2Numeric, Constantes.ID_ESTADO_CREADO_PREGUIA); //7 creado
        //        DB2.AsignarParamProcAlmac("@PDOCOIDTD", iDB2DbType.iDB2Numeric, Constantes.ID_TIPO_DOC_GUIA); //3 TIPO GUIA
        //        DB2.AsignarParamProcAlmac("@PDOCOSRIE", iDB2DbType.iDB2Char, serie); //R007 
        //        DB2.AsignarParamProcAlmac("@PDOCOEMIS", iDB2DbType.iDB2Date, new DateTime(2016, 12, 1)); // DateTime.Today);
        //        DB2.AsignarParamProcAlmac("@PDOCOPBRU", iDB2DbType.iDB2Numeric, cabdetpedido.Sum(X => X.DEPEPEBR));
        //        DB2.AsignarParamProcAlmac("@PDOCONBTS", iDB2DbType.iDB2Numeric, cabdetpedido[0].CAPENUBU);
        //        DB2.AsignarParamProcAlmac("@PDOCOOBSE", iDB2DbType.iDB2VarChar, cabdetpedido[0].CAPENOTG);
        //        DB2.AsignarParamProcAlmac("@PDOCODIRC", iDB2DbType.iDB2VarChar, cabdetpedido[0].CAPEDIRE);
        //        DB2.AsignarParamProcAlmac("@PDOCOUSCR", iDB2DbType.iDB2VarChar, usuario);
        //        DB2.AsignarParamProcAlmac("@PENTICUID", iDB2DbType.iDB2Char, cabdetpedido[0].CAPEIDCL);
        //        DB2.AsignarParamProcAlmac("@PDCENTRAN", iDB2DbType.iDB2Char, codprovtrans);
        //        DB2.AsignarParamProcAlmac("@PDCENPUPATR", iDB2DbType.iDB2VarChar, ptopartida);
        //        DB2.AsignarParamProcAlmac("@PFECHTRAS", iDB2DbType.iDB2TimeStamp, new DateTime(2016, 12, 1));  //DateTime.Today); //---TEMPORAL PARA PRUEBAS

        //        DB2.AsignarParamSalidaProcAlmac("@PDOCOCUID", iDB2DbType.iDB2Numeric, 19);
        //        DB2.EjecutarProcedimientoAlmacenado();
        //        idpreguia = Convert.ToDecimal(DB2.ObtieneParametro("@PDOCOCUID"));

        //        foreach (var item in cabdetpedido)
        //        {
        //            comandoSql = new StringBuilder();
        //            comandoSql.Append("FAELDAT.USP_PED_INSERTA_GUIA_DET"); //FAELDAT
        //            DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);
        //            DB2.AsignarParamProcAlmac("@PDOCOCUID", iDB2DbType.iDB2Numeric, idpreguia);
        //            DB2.AsignarParamProcAlmac("@PDOCOUSCR", iDB2DbType.iDB2VarChar, usuario);
        //            DB2.AsignarParamProcAlmac("@PDDCOESAF", iDB2DbType.iDB2Numeric, 2); //2
        //            DB2.AsignarParamProcAlmac("@PDDCODESC", iDB2DbType.iDB2VarChar, item.DEPEDSAR); //INVOCAR CL ANTES O DESPUES
        //            DB2.AsignarParamProcAlmac("@PDDCOBLTS", iDB2DbType.iDB2Numeric, item.DEPECAAT); //ES BULTOS NO CONOS DE DONDE SALE
        //            DB2.AsignarParamProcAlmac("@PDDCOPACN", iDB2DbType.iDB2Numeric, item.DEPEPEBR); //--EL MISMO BRUTO, NO SE HA ESPECIFICADO acond
        //            DB2.AsignarParamProcAlmac("@PDDCOPBRU", iDB2DbType.iDB2Numeric, item.DEPEPEBR);
        //            DB2.AsignarParamProcAlmac("@PDDCOPNET", iDB2DbType.iDB2Numeric, item.DEPEPEAT);
        //            DB2.AsignarParamProcAlmac("@PDDCOFACN", iDB2DbType.iDB2Numeric, 0);
        //            DB2.AsignarParamProcAlmac("@PPDDCIDPI", iDB2DbType.iDB2Char, item.DEPECOAR);
        //            DB2.AsignarParamProcAlmac("@PPDDCCANT", iDB2DbType.iDB2Numeric, item.DEPECAAT);
        //            DB2.AsignarParamProcAlmac("@PPDDCPEDI", iDB2DbType.iDB2Char, item.DEPECONT);
        //            DB2.AsignarParamProcAlmac("@PPRALIDAL", iDB2DbType.iDB2Numeric, item.DEPEALMA);
        //            DB2.AsignarParamProcAlmac("@PPRALIDPA", iDB2DbType.iDB2Char, item.DEPEPART);

        //            DB2.AsignarParamSalidaProcAlmac("@PDDCOCUID", iDB2DbType.iDB2Numeric, 19);
        //            DB2.EjecutarProcedimientoAlmacenado();

        //        }

        //        vpar.ESTOPE = true;
        //    }
        //    catch (Exception ex)
        //    {
        //        Util.EscribeLog(ex.Message);
        //        vpar.MENERR = ErrorGenerico(ex.Message);
        //    }
        //    finally
        //    {
        //        DB2.Desconectar();
        //    }
        //    return vpar;
        //}

        /// <summary>
        /// 
        /// </summary>
        /// <param name="TipRsrva">Tipo de reserva, N, considerar solo 99999 o contratos S 
        /// I = Reserva de Insumos
        /// N = Reserva Normal
        /// S = Reserva para Atención de Stock</param>
        /// <param name="NoFolio">Número de Folio usar 0</param>
        /// <param name="Secuencia">Secuencia</param>
        /// <param name="Articulo">Artículo que se reserva</param>
        /// <param name="Partida">Partida que se reserva</param>
        /// <param name="Almacen">Almacén donde está la partida que se reserva</param>
        /// <param name="Destino">Destino de la reserva(pedido, partida o referencia de un usuario, usar usuario 6 caracteres</param>
        /// <param name="TpDest">Tipo de destino, usar temporalmente Z, se debe definir 
        /// P = Partida
        /// E = Pedido de exportación
        /// N = Pedido Nacional
        /// T = Pedido de Servicio a Terceros
        /// I = Pedido Interno
        /// S = Pedido de Stock
        /// Z = Reserva preventiva sin pedido</param>
        /// <param name="SecDest">Secuencia del ítem del pedido, en partidas es 01, en preventivas en 00, usar 0</param>
        /// <param name="ScPrdDst">Secuencia de producto intermedio donde se utilizará (nodo superior), usar 0</param>
        /// <param name="ScPrdAtn">Secuencia de producto intermedio origen, usar 0</param>
        /// <param name="Cantidad">Cantidad que se reserva, cantidad con 2 ultimos digitos parte decimal</param>
        /// <param name="TipAcci">Tipo de acción, usar siempre A insert o L anular o liiberar reserva
        /// A = Agregar Reserva
        /// L = Liberar Reserva
        /// M = Modificar Reserva
        /// E = Entregar o Atender Reserva
        /// R = Reconfirmar Reserva</param>
        public void generaReserva(bool conectado, string TipRsrva, string NoFolio, string Secuencia, string Articulo, string Partida, string Almacen, string Destino, string TpDest, string SecDest, string ScPrdDst, string ScPrdAtn, string Cantidad, string TipAcci)
        {
            try
            {

                if (!conectado)
                {
                    DB2.Conectar();
                }
                StringBuilder comandoSql = new StringBuilder();
                StringBuilder actreservSql; // = new StringBuilder();

                TipRsrva = TipRsrva.PadRight(1, ' ');
                NoFolio = NoFolio.PadLeft(5, '0').Substring(0,5);
                Secuencia = Secuencia.PadLeft(2, '0');
                Articulo = Articulo.PadRight(15, ' ');
                Partida = Partida.PadRight(6, ' ');
                Almacen = Almacen.PadLeft(3, '0');
                Destino = Destino.PadRight(6, ' ').Substring(0,6);
                TpDest = TpDest.PadRight(1, ' ');

                SecDest = SecDest.PadLeft(2, '0');
                ScPrdDst = ScPrdDst.PadLeft(3, '0');
                ScPrdAtn = ScPrdAtn.PadLeft(3, '0');
                Cantidad = Cantidad.PadLeft(9, '0');
                TipAcci = TipAcci.PadRight(1, ' ');

                actreservSql = new StringBuilder();
                actreservSql.Append("CALL INCAOBJ.ACTRESPP(");  //GMA003PP 20151130 PRUEBAS USUARIO
                actreservSql.Append("'").Append(TipRsrva).Append("', ");
                actreservSql.Append("'").Append(NoFolio).Append("', ");
                actreservSql.Append("'").Append(Secuencia).Append("', ");
                actreservSql.Append("'").Append(Articulo).Append("', ");
                actreservSql.Append("'").Append(Partida).Append("', ");
                actreservSql.Append("'").Append(Almacen).Append("', ");
                actreservSql.Append("'").Append(Destino).Append("', ");
                actreservSql.Append("'").Append(TpDest).Append("', ");
                actreservSql.Append("'").Append(SecDest).Append("', ");
                actreservSql.Append("'").Append(ScPrdDst).Append("', ");
                actreservSql.Append("'").Append(ScPrdAtn).Append("', ");
                actreservSql.Append("'").Append(Cantidad).Append("', ");
                actreservSql.Append("'").Append(TipAcci).Append("') ");

                //xselec = "call GEMAPRG.GMA003PP('"+cia +"','"+ allt(tcomp) +"','"+ allt(comprob) +"','"+ allt(fecha) +"','"+ m->articulo +"','"+ allt(m->almacen) +"','"+ allt(partida) +"','"+ allt(cantidad) +"','"+ total +"','"+ m->signo +"','"+ orides +"','"+ destino +"','"+ unidad +"','"+ item +"','" + estado +"')"

                DB2.CrearComando(actreservSql.ToString(), CommandType.Text);
                //PRUEBAS 
                DB2.EjecutarComando();
            }
            finally
            {
                if (!conectado)
                {
                    DB2.Desconectar();
                }
            }
        }

        /// <summary>
        /// 
        /// </summary>
        /// <param name="conectado"></param>
        /// <param name="articulo"></param>
        /// <param name="descripcion"></param>
        /// <param name="pedido"></param>
        /// <param name="tipoPedido"></param>
        /// <param name="secuencia"></param>
        /// <param name="cantidad"></param>
        /// <param name="accion"></param>
        /// <returns></returns>
        public string descripcionItem(bool conectado, string articulo, string descripcion, string pedido, string tipoPedido, string secuencia, string cantidad, string accion)
        {
            try
            {
                StringBuilder comandoSql;

                if (!conectado)
                {
                    DB2.Conectar();
                }

                if (pedido != "999999")
                {
                    DB2.CrearComando("FAELDAT.USP_PED_OBTIENE_SEC_CONTRATO", CommandType.StoredProcedure);
                    DB2.AsignarParamProcAlmac("@PCONTRATO", iDB2DbType.iDB2Char, pedido); //cod
                    DB2.AsignarParamProcAlmac("@PCVTDARTI", iDB2DbType.iDB2Char, articulo); //si
                    DB2.AsignarParamSalidaProcAlmac("@PCVTDSECU", iDB2DbType.iDB2Decimal, 2); //00
                    DB2.EjecutarProcedimientoAlmacenado();
                    if (DB2.ObtieneParametro("@PCVTDSECU") != DBNull.Value)
                    {
                        secuencia = Convert.ToString(DB2.ObtieneParametro("@PCVTDSECU")).Trim();
                    }
                }

                comandoSql = new StringBuilder();
                comandoSql.Append("FAELDAT.PR_FAEL_OBTENERDESCRIPCION"); //FAELDAT
                DB2.CrearComando(comandoSql.ToString(), CommandType.StoredProcedure);

                DB2.AsignarParamEntSalProcAlmac("@ART", iDB2DbType.iDB2VarChar, articulo.PadRight(15, ' ')); //cod
                DB2.AsignarParamEntSalProcAlmac("@DES", iDB2DbType.iDB2VarChar, descripcion.PadLeft(120, ' ')); //
                DB2.AsignarParamEntSalProcAlmac("@PED", iDB2DbType.iDB2VarChar, pedido.PadRight(6, '0')); //si
                DB2.AsignarParamEntSalProcAlmac("@TPD", iDB2DbType.iDB2VarChar, tipoPedido.PadLeft(1, '0')); //N
                DB2.AsignarParamEntSalProcAlmac("@SEC", iDB2DbType.iDB2VarChar, secuencia.PadLeft(2, '0')); //00
                DB2.AsignarParamEntSalProcAlmac("@CAN", iDB2DbType.iDB2VarChar, cantidad.PadLeft(5, '0')); //int
                DB2.AsignarParamEntSalProcAlmac("@ACC", iDB2DbType.iDB2VarChar, accion.PadLeft(1, ' ')); //3 o 1 si no hay pedido

                DB2.EjecutarProcedimientoAlmacenado();
                descripcion = Convert.ToString(DB2.ObtieneParametro("@DES")).Trim();

                return descripcion;

            }
            finally
            {
                if (!conectado)
                {
                    DB2.Desconectar();
                }
            }
        }

        //
        public void actualizaPROSAS(string folio, decimal secuencia, decimal pesoentregado, string estado)
        {
            try
            {
                DB2.Conectar();
                DB2.CrearComando("PRODDAT.USP_PED_ACTUALIZA_OSA", CommandType.StoredProcedure);
                DB2.AsignarParamProcAlmac("@POSASFOLI", iDB2DbType.iDB2Char, folio);
                DB2.AsignarParamProcAlmac("@POSASSECU", iDB2DbType.iDB2Numeric, secuencia);
                DB2.AsignarParamProcAlmac("@POSASCAEN", iDB2DbType.iDB2Decimal, pesoentregado); //-1 para no actualizar el campo y si actualizar estado
                DB2.AsignarParamProcAlmac("@POSASSTOS", iDB2DbType.iDB2Char, estado); //vacio cuando se envía pesoentregado
                DB2.EjecutarComando();
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
        }

        public void actualizaGMDEEM(string empaque, decimal secuencia, decimal cantidadrestante, decimal pesorestante, decimal stockcerobolsa, decimal estadobolsa)
        {
            try
            {
                DB2.Conectar();

                DB2.CrearComando("PRODDAT.USP_PED_ACTUALIZA_GMDEEM", CommandType.StoredProcedure);
                DB2.AsignarParamProcAlmac("@PDEEMCOEM", iDB2DbType.iDB2Char, empaque);
                DB2.AsignarParamProcAlmac("@PDEEMSECU", iDB2DbType.iDB2Numeric, secuencia);
                DB2.AsignarParamProcAlmac("@PDEEMCAST", iDB2DbType.iDB2Decimal, cantidadrestante);
                DB2.AsignarParamProcAlmac("@PDEEMPEST", iDB2DbType.iDB2Decimal, pesorestante);
                DB2.AsignarParamProcAlmac("@PDEEMSTCE", iDB2DbType.iDB2Numeric, stockcerobolsa); //-1 si no se actualizará EL CAMPO 
                DB2.AsignarParamProcAlmac("@PDEEMESBO", iDB2DbType.iDB2Numeric, estadobolsa);
                DB2.EjecutarComando();
            }
            catch (Exception ex)
            {
                Util.EscribeLog(ex.Message);
            }
            finally
            {
                DB2.Desconectar();
            }
        }



        private string ErrorGenerico(string exception)
        {
            if (OcultaErrorReal)
            {
                return Mensajes.MENSAJE_ERROR_GENERICO;
            }
            else
            {
                return exception;
            }
        }
    }
}
