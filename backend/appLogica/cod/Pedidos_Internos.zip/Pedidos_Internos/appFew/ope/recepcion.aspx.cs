﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using appConstantes;
using System.Data;
using appFew.appServicio;
using appWcfService;

namespace appFew.ope
{
    public partial class recepcion : System.Web.UI.Page
    {
        #region Variables
        private static ParametrosFe _ParametrosIni;
        private string Error_1 = string.Empty;
        private string Error_2 = string.Empty;
        private string url = string.Empty;
        private bool Cargando = false;
        USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result Selectedrow = new USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result(); //Guarda el item seleccionado
        List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> Listosas
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION] as List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>;
                if (dt == null)
                {
                    List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
                    dt = datos;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION] = value;
            }
        }
        decimal idosa;
        #endregion

        #region Eventos
        protected void Page_Load(object sender, EventArgs e)
        {

            _ParametrosIni = (ParametrosFe)Session["ParametrosFe"];

            if (Session["ParametrosFe"] == null)
            {
                Response.Redirect("../login.aspx?ReturnURL=" + Request.Url.AbsoluteUri);
                //Response.Redirect("../login.aspx");
            }
            else
            {

                try
                {
                    //ErrorLabel.Font.Bold = false;
                    //AsignaAtributos();
                    this.Form.DefaultButton = this.buscaButton.UniqueID;
                    if (!Page.IsPostBack)
                    {
                        //CargaDatosIniciales();
                        Listosas = null;
                        string folio = HttpContext.Current.Session[Constantes.FOLIO_SELECCIONADO_PLANTA] as string;
                        if (folio == null)
                        {
                            CargaDatosIniciales();
                        }
                        else
                        {
                            CargaFoliosUsuario();
                            tipfolDropDownList.SelectedValue = folio;
                            CargaOsasEmitidas();
                        }
                    }
                }
                catch (Exception ex)
                {
                    Error_2 = ex.Message.Replace(Environment.NewLine, "<BR>");
                    Error_1 = "Ha ocurrido un error en la pagina.";
                    url = "..//ErrorPage.aspx?Error_1=" + Error_1 + "&Error_2=" + Error_2;
                    Response.Redirect(url);
                }
            }
        }

        protected void tipfolDropDownList_SelectedIndexChanged(object sender, EventArgs e)
        {
            try
            {
                SetDataSourceDetalle(null);
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void seleccionarButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (pendientesGridView.Rows.Count > 0)
                {
                    if (OsasPendientes.Count > 0)
                    {
                        //foreach (GridViewRow row in pendientesGridView.Rows)
                        //{
                        //    if (row.RowType == DataControlRowType.DataRow)
                        //    {
                        //        string corrLiq = row.Cells[0].Text;
                        //        if (corrLiq != "")
                        //        {
                        //            USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result Osaseleccionada = OsasPendientes.Find(x => x.OSAROW == long.Parse(corrLiq));
                        //            CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                        //            if (chkRow.Checked)
                        //            {
                        //                listseleccionadas.Add(Osaseleccionada);
                        //            }
                        //        }
                        //    }
                        //}
                        //Listosas = listseleccionadas;
                        if (Listosas.Count > 1)
                        {
                            mensajelabel.Text = "¿Desea revisar las OSAs Marcadas?";
                            mensajemodal.Show();
                        }
                        else if (Listosas.Count == 1)
                        {
                            mensajelabel.Text = "¿Desea revisar esta OSA?";
                            mensajemodal.Show();
                        }
                        else
                        {
                            MostrarMensaje("Debe Marcar al menos una OSA para pasar a Revisión.");
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }


        private bool genera_pedido(PECAOS objpecaos)
        {
            IappServiceClient clt = null;
            bool result = false;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_PEDIDO_INTERNO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(Utils.Serialize(objpecaos));
                parEnt.Add(_ParametrosIni.Usuario);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0] != "0")
                    {
                        idosa = Decimal.Parse(resultado.VALSAL[0]);
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                    result = false;
                }
                result = resultado.ESTOPE;

                return result;
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
                return result;
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        protected void ActualizarButton_Click(object sender, EventArgs e)
        {
            SetDataSourceDetalle(null);
            Listosas = null;
            CargaOsasEmitidas();
        }

        //Grillas
        protected void pendientesGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void pendientesGridView_SelectedIndexChanging(object sender, GridViewSelectEventArgs e)
        {
            try
            {
                if (pendientesGridView.SelectedIndex != -1)
                {
                    GridViewRow previorow = pendientesGridView.Rows[pendientesGridView.SelectedIndex];
                    //nrow.BackColor = ColorTranslator.FromHtml("#A1DCF2");
                    previorow.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                    previorow.Attributes.Add("bgColor", "#FF9999");
                }
                GridViewRow nuevorow = pendientesGridView.Rows[e.NewSelectedIndex];

                //brow.BackColor = ColorTranslator.FromHtml("#FFFFFF");
                nuevorow.Attributes.Add("bgColor", "this.originalstyle");
                nuevorow.ToolTip = string.Empty;

            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        protected void pendientesGridView_SelectedIndexChanged(object sender, EventArgs e)
        {

            try
            {
                //Obtiene el item selecconado y llama el metodo para mostrar el detalle del item
                GridViewRow row = pendientesGridView.SelectedRow;
                List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> listseleccionadas = new List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
                listseleccionadas = Listosas;
                if (row != null)
                {
                    string corrLiq = row.Cells[0].Text;
                    //LENAR TABPAGES
                    List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> detConsumo = OsasPendientes;

                    if (detConsumo != null && detConsumo[0].OSAROW != -1)
                    {
                        Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                        CheckBox chkRow = (row.Cells[0].FindControl("cbSelect") as CheckBox);
                        if (chkRow.Checked)
                        {
                            if (!listseleccionadas.Contains(Selectedrow))
                            {
                                listseleccionadas.Add(Selectedrow);
                            }
                            Listosas = listseleccionadas;
                            eliminaDetalle = "1";
                            MuestraDetalleOsa();
                        }
                        else
                        {
                            listseleccionadas.Remove(Selectedrow);
                            Listosas = listseleccionadas;
                            eliminaDetalle = null;
                            MuestraDetalleOsaRemove(listseleccionadas);
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(ex.Message);
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
        }

        private void MuestraDetalleOsaRemove(List<appWcfService.USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> remove)
        {
            SetDataSourceDetalle(null);
            foreach (var item in remove)
            {
                CargaDetalleOsa(item.OSASFOLI.ToString());
                eliminaDetalle = "1";
            }
        }

        protected void pendientesGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(pendientesGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[4].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[2].Text = ConsumosExamen.Sum(x => x.MOVMCANT).ToString(Constantes.FORMATO_IMPORTE);
            //    e.Row.Cells[3].Text = ConsumosExamen.Sum(x => x.PORCENTAJE).ToString(Constantes.FORMATO_DECIMAL_0 + "1");
            //}
        }

        protected void detalleGridView_RowCreated(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == System.Web.UI.WebControls.DataControlRowType.DataRow)
            {
                // when mouse is over the row, save original color to new attribute, and change it to highlight color
                e.Row.Attributes.Add("onmouseover", "this.originalstyle=this.style.backgroundColor;this.style.backgroundColor='#FF9999'");

                // when mouse leaves the row, change the bg color to its original value   
                e.Row.Attributes.Add("onmouseout", "this.style.backgroundColor=this.originalstyle;");
            }
        }

        protected void detalleGridView_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType == DataControlRowType.DataRow)
            {
                if (!e.Row.Cells[0].Text.Equals("-1") && !e.Row.Cells[0].Text.Equals(""))
                {

                    e.Row.Attributes["onclick"] = Page.ClientScript.GetPostBackClientHyperlink(detalleGridView, "Select$" + e.Row.RowIndex);
                    e.Row.ToolTip = Mensajes.MENSAJE_CLIC_A_SELECCIONAR; //"Click to select this row.";
                }
                else
                {
                    e.Row.Cells[0].Text = "";
                    e.Row.Cells[3].Text = "";
                    e.Row.Cells[4].Text = "";
                    e.Row.Cells[5].Text = "";
                }
            }
            //else if (e.Row.RowType == DataControlRowType.Footer)
            //{
            //    e.Row.Cells[1].Text = "TOTAL";
            //    e.Row.Cells[3].Text = AsignacionExamen.Sum(x => x.ASIGCAPR).ToString(Constantes.FORMATO_IMPORTE);
            //}
        }

        protected void buscaButton_Click(object sender, EventArgs e)
        {
            try
            {
                if (buscarTextBox.Text.Trim().ToString() != "")
                {
                    SetDataSourceDetalle(null);
                    Listosas = null;
                }
                CargaOsasEmitidas();
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        //Ventana Modal
        protected void maceptarbutton_Click(object sender, EventArgs e)
        {
            if (Listosas.Count > 0)
            {
                try
                {
                    Session[Constantes.NOMBRE_SESION_OSA_SELECCIONADA_RECEPCION] = Listosas;
                    Session[Constantes.FOLIO_SELECCIONADO_PLANTA] = tipfolDropDownList.SelectedValue;

                    Response.Redirect("../ope/detalleplanta.aspx");
                }
                catch (Exception ex)
                {
                    MostrarMensaje(ex.Message);
                }
            }
        }

        protected void mcancelarbutton_Click(object sender, EventArgs e)
        {

        }
        #endregion

        #region Metodos

        private void CargaDatosIniciales()
        {
            InicializaDatos();
            CargaFoliosUsuario();
            CargaOsasEmitidas();
        }

        private void InicializaDatos()
        {
            //consumos
            SetDataSourceOsas(null);

            //asignacion
            SetDataSourceDetalle(null);
        }

        public void CargaFoliosUsuario()
        {

            IappServiceClient clt = null;
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.OBTIENE_TIPOS_FOLIO_USUARIO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(_ParametrosIni.Usuario);
                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        var firstitem = tipfolDropDownList.Items[0];
                        tipfolDropDownList.Items.Clear();
                        tipfolDropDownList.Items.Add(firstitem);

                        List<PEUSTF> datos = Funciones.Deserialize<List<PEUSTF>>(resultado.VALSAL[1]);
                        foreach (PEUSTF item in datos)
                        {
                            tipfolDropDownList.Items.Add(new ListItem(item.PETIFO.TIFODESC, item.PETIFO.TIFOCOFO.ToString()));
                        }
                    }
                }
                else
                {
                    MostrarMensaje(resultado.MENERR);
                }
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void SetDataSourceOsas(List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> _listaConsumos)
        {
            bool limpiaDet = false;
            if (_listaConsumos == null)
            {
                _listaConsumos = ObtienePendientesDefault();
                limpiaDet = true;
            }

            OsasPendientes = _listaConsumos;
            pendientesGridView.DataSource = OsasPendientes;
            pendientesGridView.DataBind();
            if (pendientesGridView.SelectedIndex == -1 || limpiaDet)
            {
                SetDataSourceDetalle(null);
            }
        }

        private void CargaOsasEmitidas()
        {
            IappServiceClient clt = null;

            try
            {
                if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
                {
                    SetDataSourceOsas(null);

                    return;
                }
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_OSAS_PENDIENTES_PLANTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado
                parEnt.Add(buscarTextBox.Text.ToString().Trim()); //valor de busqueda

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceOsas(datos);
                    }
                    else
                    {
                        SetDataSourceOsas(null);
                    }

                }
                else
                {
                    SetDataSourceOsas(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionConsumo();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        //private void CargaOsasPlanta()
        //{
        //    IappServiceClient clt = null;

        //    try
        //    {
        //        if (tipfolDropDownList.SelectedValue == Constantes.CODIGO_LISTA_SELECCIONE)
        //        {
        //            SetDataSourceOsas(null);

        //            return;
        //        }
        //        RESOPE resultado;
        //        clt = _ParametrosIni.IniciaNuevoCliente();

        //        //codigo de operacion
        //        PAROPE argumentos = new PAROPE();
        //        argumentos.CODOPE = CodigoOperacion.MUESTRA_OSAS_PENDIENTES_PLANTA;
        //        //asigna parametros entrada en orden
        //        List<string> parEnt = new List<string>();
        //        parEnt.Add(tipfolDropDownList.SelectedValue); //agregar estado

        //        argumentos.VALENT = parEnt.ToArray();
        //        resultado = clt.EjecutaOperacion(argumentos);
        //        if (resultado.ESTOPE)
        //        {
        //            if (resultado.VALSAL[0].Equals("1")) //encontrado
        //            {
        //                List<PECAOS> datos = Funciones.Deserialize<List<PECAOS>>(resultado.VALSAL[1]);

        //                //SetDataSourceOsas(datos);
        //            }
        //            else
        //            {
        //                SetDataSourceOsas(null);
        //            }

        //        }
        //        else
        //        {
        //            SetDataSourceOsas(null);

        //            MostrarMensaje(resultado.MENERR);
        //            //ErrorLabel.Font.Bold = true;
        //            //ErrorLabel.Text = resultado.MENERR;
        //        }
        //        //EstadoFinalBotonesNavegacionConsumo();
        //    }
        //    catch (Exception ex)
        //    {
        //        MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
        //    }
        //    finally
        //    {
        //        _ParametrosIni.FinalizaCliente(clt);
        //    }
        //}

        private void SetDataSourceDetalle(List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> _listaAsignacion)
        {
            List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> Detalles;
            if (_listaAsignacion == null)
            {
                _listaAsignacion = ObtieneDetalleDefault();
                DetalleOsaPendiente = _listaAsignacion;
            }
            else
            {
                if (Listosas.Count > 1 && eliminaDetalle != null)
                {
                    Detalles = DetalleOsaPendiente;
                    if (Detalles.FirstOrDefault(x => x.OSASFOLI == _listaAsignacion[0].OSASFOLI) == null)
                    {
                        Detalles.AddRange(_listaAsignacion);
                        DetalleOsaPendiente = Detalles;
                    }
                }
                else
                {
                    DetalleOsaPendiente = _listaAsignacion;
                }
            }
            detalleGridView.DataSource = DetalleOsaPendiente;
            detalleGridView.DataBind();
        }

        private void MuestraDetalleOsa()
        {
            //Obtiene el item selecconado y llama el metodo para mostrar el detalle del item
            GridViewRow row = pendientesGridView.SelectedRow;

            if (row != null)
            {
                string corrLiq = row.Cells[0].Text;
                //LENAR TABPAGES
                List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> detConsumo = OsasPendientes;

                if (detConsumo != null && detConsumo[0].OSAROW != -1)
                {
                    Selectedrow = detConsumo.Find(x => x.OSAROW == Convert.ToDecimal(corrLiq));
                    CargaDetalleOsa(Selectedrow.OSASFOLI.ToString());
                    //posOsaTextBox.Text = consumo.OSAROW.ToString();
                }
            }
            else
            {
                iddeHiddenFieldConsumo.Value = "";
            }
        }

        private void CargaDetalleOsa(string folio)
        {
            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.MUESTRA_DETALLE_OSA_PLANTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> datos = Funciones.Deserialize<List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>>(resultado.VALSAL[1]);

                        SetDataSourceDetalle(datos);
                    }
                    else
                    {
                        SetDataSourceDetalle(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }

        private void MostrarMensaje(string mensaje, bool noalert = false)
        {
            if (!noalert)
            {
                ScriptManager.RegisterStartupScript(up, up.GetType(), "myAlert", "alert('" + mensaje.Replace("<br>", " - ") + "');", true);
            }
            //ErrorLabel.Text = _ParametrosIni.ErrorGenerico(mensaje );
        }

        //Default
        private List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> ObtienePendientesDefault()
        {
            List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> datos = new List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
            datos.Add(new USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result() { OSAROW = -1 });
            return datos;
        }

        private List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> ObtieneDetalleDefault()
        {
            List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> datos = new List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>();
            datos.Add(new USP_OBTIENE_DETALLE_OSA_PLANTA_Result() { OSASSECU = -1 });
            return datos;
        }

        private List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> OsasPendientes
        {
            get
            {
                List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSAS_RECEPCION] as List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtienePendientesDefault();

                    OsasPendientes = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_LISTA_OSAS_RECEPCION] = value;
            }
        }

        private List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> DetalleOsaPendiente
        {
            get
            {
                List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result> dt = HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_RECEPCION] as List<USP_OBTIENE_DETALLE_OSA_PLANTA_Result>;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = ObtieneDetalleDefault();

                    DetalleOsaPendiente = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.NOMBRE_SESION_DETALLE_OSAS_RECEPCION] = value;
            }
        }

        private void buscarosa(string folio, string busqueda)
        {

            IappServiceClient clt = null;

            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.BUSCA_OSAS_PENDIENTES_PLANTA;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);
                parEnt.Add(busqueda);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        List<USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result> listabusqueda = Funciones.Deserialize<List<USP_BUSCA_OSAS_PENDIENTES_PLANTA_Result>>(resultado.VALSAL[1]);
                        List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result> listdatos = new List<USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result>();
                        foreach (var item in listabusqueda)
                        {
                            USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result obj = new USP_OBTIENE_OSAS_PENDIENTES_PLANTA_Result();
                            obj.OSAROW = item.OSAROW;
                            obj.OSASCIA = item.OSASCIA;
                            obj.OSASFOLI = item.OSASFOLI;
                            obj.PARTFEEF = item.PARTFEEF;
                            obj.OSASFEEM = item.OSASFEEM;
                            obj.OSASRESP = item.OSASRESP;
                            obj.CAOSIDCO = item.CAOSIDCO;
                            obj.CAOSPRIO = item.CAOSPRIO;
                            obj.CAOSIDES = item.CAOSIDES;

                            listdatos.Add(obj);
                        }

                        SetDataSourceOsas(listdatos);
                    }
                    else
                    {
                        SetDataSourceOsas(null);
                    }

                }
                else
                {
                    SetDataSourceDetalle(null);

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        private void GeneraOrdenTrabajo(string folio)
        {
            IappServiceClient clt = null;
            ORDENTRABAJO dtoOT = new ORDENTRABAJO();
            try
            {
                RESOPE resultado;
                clt = _ParametrosIni.IniciaNuevoCliente();

                //codigo de operacion
                PAROPE argumentos = new PAROPE();
                argumentos.CODOPE = CodigoOperacion.GENERA_ORDEN_TRABAJO;
                //asigna parametros entrada en orden
                List<string> parEnt = new List<string>();
                parEnt.Add(folio);

                argumentos.VALENT = parEnt.ToArray();
                resultado = clt.EjecutaOperacion(argumentos);
                if (resultado.ESTOPE)
                {
                    if (resultado.VALSAL[0].Equals("1")) //encontrado
                    {
                        dtoOT.OSASFOLI = folio;
                        dtoOT.datpart = Funciones.Deserialize<List<PRPART>>(resultado.VALSAL[1]);
                        dtoOT.obsepart = Funciones.Deserialize<List<PRPAOB>>(resultado.VALSAL[2]);
                        dtoOT.asigpart = Funciones.Deserialize<List<PRASIG>>(resultado.VALSAL[3]);
                        dtoOT.reqmat = Funciones.Deserialize<List<USP_PED_OBTIENE_PARTIDA_DE_OSAS_DE_PARTIDA_Result>>(resultado.VALSAL[4]);
                        if (folio.Substring(0, 1) == "5")
                        {
                            dtoOT.maqtint = Funciones.Deserialize<List<PRTMXR>>(resultado.VALSAL[5]);
                        }
                        else
                        {
                            dtoOT.maqtint = null;
                        }
                        HttpContext.Current.Session[Constantes.NOMBRE_SESION_ORDEN_TRABAJO] = dtoOT;

                        string tempscript = "javascript:window.open('../ope/formatodoc2.aspx')";
                        ScriptManager.RegisterStartupScript(up, up.GetType(), "OrdenTrabajo", tempscript, true);
                    }
                    else
                    {
                        MostrarMensaje(resultado.MENERR);
                    }
                }
                else
                {

                    MostrarMensaje(resultado.MENERR);
                    //ErrorLabel.Font.Bold = true;
                    //ErrorLabel.Text = resultado.MENERR;
                }
                //EstadoFinalBotonesNavegacionAsignacion();
            }
            catch (Exception ex)
            {
                MostrarMensaje(_ParametrosIni.ErrorGenerico(ex.Message));
            }
            finally
            {
                _ParametrosIni.FinalizaCliente(clt);
            }
        }
        #endregion

        protected void btnimprimir_Click(object sender, EventArgs e)
        {
            try
            {
                GridViewRow row = pendientesGridView.SelectedRow;
                if (row != null)
                {
                    string corrLiq = row.Cells[2].Text;
                    GeneraOrdenTrabajo(corrLiq);
                }
                //if (pendientesGridView.Rows.Count > 0)
                //{
                //    if (Listosas.Count == 1)
                //    {
                //        GeneraOrdenTrabajo(Listosas[0].OSASFOLI);
                //    }
                //    else
                //    {
                //        MostrarMensaje("Debe marcar solo una OSA");
                //    }
                //}
            }
            catch (Exception ex)
            {
                MostrarMensaje(ex.Message);
            }
        }

        private string eliminaDetalle
        {
            get
            {
                string dt = HttpContext.Current.Session[Constantes.MULTIPLE_DETALLE_RECEPCION] as string;
                if (dt == null)
                {
                    // Crear un DataTable y guarda la sesion
                    dt = null;

                    eliminaDetalle = dt;
                }
                return dt;
            }
            set
            {
                HttpContext.Current.Session[Constantes.MULTIPLE_DETALLE_RECEPCION] = value;
            }
        }

    }
}